# Correção de Erro: Invalid Hook Call

## Problema Identificado

**Erro:** `Invalid hook call. Hooks can only be called inside of the body of a function component.`

**Causa:** Hook `useData()` sendo chamado dentro de um handler `onClick` na linha 996 do arquivo `Emissao.tsx`

## Detalhes do Problema

### Antes da Correção

```typescript
// Linha 11 - Destructuring inicial
const { trips, companies, currentUser, addReservation, addLog, pixKeys, settings, addPixCharge } = useData();

// Linha 996 - ERRO: Hook chamado dentro de onClick
<button 
  onClick={() => {
    if (pixCharge) {
      const { updatePixCharge, updateReservation, reservations } = useData(); // ❌ VIOLAÇÃO
      updatePixCharge({ ...pixCharge, status: 'paid', paidAt: new Date().toISOString() });
      // ...
    }
  }}
>
  Confirmar Pagamento (Demo)
</button>
```

### O Que Aconteceu

1. O hook `useData()` foi chamado dentro de uma função aninhada (onClick handler)
2. Isso viola as **Regras dos Hooks** do React
3. Hooks só podem ser chamados:
   - No nível superior do componente
   - Dentro de outros hooks customizados
   - Nunca dentro de loops, condições ou funções aninhadas

## Solução Aplicada

### 1. Adicionar Variáveis ao Destructuring Inicial

```typescript
// Linha 11 - Adicionado updatePixCharge, updateReservation e reservations
const { 
  trips, 
  companies, 
  currentUser, 
  addReservation, 
  addLog, 
  pixKeys, 
  settings, 
  addPixCharge,
  updatePixCharge,      // ✅ Adicionado
  updateReservation,    // ✅ Adicionado
  reservations          // ✅ Adicionado
} = useData();
```

### 2. Remover Hook do onClick Handler

```typescript
// Linha 996 - CORRIGIDO: Hook removido do onClick
<button 
  onClick={() => {
    if (pixCharge) {
      // ✅ Agora usa as variáveis do escopo do componente
      updatePixCharge({ ...pixCharge, status: 'paid', paidAt: new Date().toISOString() });
      const res = reservations.find(r => r.codigo === pixCharge.reservationCode);
      if (res) {
        updateReservation({ 
          ...res, 
          paymentStatus: 'aprovado', 
          status: 'paga',
          updatedAt: new Date().toISOString(),
          history: [...res.history, { date: new Date().toISOString(), action: 'Pagamento Pix confirmado', user: currentUser?.name || '' }]
        });
      }
      setStep(6);
    }
  }}
>
  Confirmar Pagamento (Demo)
</button>
```

## Regras dos Hooks do React

### ✅ Regra 1: Apenas no Nível Superior

```typescript
// ❌ ERRADO
function Component() {
  if (condition) {
    const [state, setState] = useState(); // Hook dentro de condição
  }
}

// ✅ CORRETO
function Component() {
  const [state, setState] = useState(); // Hook no nível superior
  if (condition) {
    // Use state aqui
  }
}
```

### ✅ Regra 2: Apenas em Componentes React

```typescript
// ❌ ERRADO
function regularFunction() {
  const [state, setState] = useState(); // Hook fora de componente
}

// ✅ CORRETO
function Component() {
  const [state, setState] = useState(); // Hook dentro de componente
}
```

### ✅ Regra 3: Nunca em Loops ou Funções Aninhadas

```typescript
// ❌ ERRADO
function Component() {
  const handleClick = () => {
    const [state, setState] = useState(); // Hook em função aninhada
  };
}

// ✅ CORRETO
function Component() {
  const [state, setState] = useState(); // Hook no nível superior
  
  const handleClick = () => {
    setState(newValue); // Use o state aqui
  };
}
```

## Padrões Comuns que Causam Este Erro

### 1. Hook em Event Handler

```typescript
// ❌ ERRADO
<button onClick={() => {
  const data = useData(); // Hook em handler
  data.doSomething();
}}>

// ✅ CORRETO
const data = useData(); // Hook no nível superior
<button onClick={() => {
  data.doSomething(); // Usa a variável já disponível
}}>
```

### 2. Hook em Função Callback

```typescript
// ❌ ERRADO
useEffect(() => {
  const state = useState(); // Hook em callback
}, []);

// ✅ CORRETO
const [state, setState] = useState(); // Hook no nível superior
useEffect(() => {
  setState(newValue); // Usa o state já disponível
}, []);
```

### 3. Hook Condicional

```typescript
// ❌ ERRADO
function Component({ show }) {
  if (show) {
    const [state, setState] = useState(); // Hook condicional
  }
}

// ✅ CORRETO
function Component({ show }) {
  const [state, setState] = useState(); // Hook sempre chamado
  if (show) {
    // Use state aqui
  }
}
```

## Ferramentas de Debug

### ESLint Plugin React Hooks

```json
{
  "plugins": ["react-hooks"],
  "rules": {
    "react-hooks/rules-of-hooks": "error",
    "react-hooks/exhaustive-deps": "warn"
  }
}
```

### React DevTools

1. Instale a extensão React DevTools
2. Abra o console do navegador
3. O erro mostrará exatamente onde o hook foi chamado incorretamente

### TypeScript

O TypeScript pode detectar alguns problemas de hooks:
```bash
npm run typecheck
```

## Checklist de Prevenção

Antes de fazer commit, verifique:

- [ ] Todos os hooks estão no nível superior do componente
- [ ] Nenhum hook dentro de funções aninhadas (onClick, onChange, etc.)
- [ ] Nenhum hook dentro de loops ou condições
- [ ] Nenhum hook em callbacks (useEffect, setTimeout, etc.)
- [ ] ESLint com react-hooks plugin está ativo
- [ ] Build passa sem warnings
- [ ] Aplicação funciona sem erros no console

## Arquivos Corrigidos

### `/src/pages/Emissao.tsx`

**Mudanças:**
1. Adicionado `updatePixCharge`, `updateReservation` e `reservations` ao destructuring do `useData()` (linha 11)
2. Removida chamada `useData()` de dentro do onClick handler (linha 996)
3. Agora usa as variáveis já disponíveis no escopo do componente

**Resultado:**
- ✅ Sem violação das regras dos hooks
- ✅ Build bem-sucedido
- ✅ Funcionalidade de confirmação de pagamento funcionando
- ✅ Sem erros no console

## Lições Aprendidas

### 1. Sempre Declare Hooks no Topo

```typescript
function Component() {
  // ✅ Todos os hooks aqui
  const data = useData();
  const [state, setState] = useState();
  const navigate = useNavigate();
  
  // ❌ Nunca aqui
  // const handleClick = () => {
  //   const data = useData(); // ERRO!
  // };
}
```

### 2. Use Variáveis do Escopo

```typescript
// ✅ CORRETO
function Component() {
  const { updateData } = useData();
  
  const handleClick = () => {
    updateData(newValue); // Usa variável do escopo
  };
}
```

### 3. Verifique o Console

Sempre verifique o console do navegador durante o desenvolvimento. O React emite warnings e erros claros quando há problemas com hooks.

## Referências

- [React Docs: Rules of Hooks](https://react.dev/learn/rules-of-hooks)
- [React Docs: Hooks API Reference](https://react.dev/reference/react)
- [ESLint Plugin React Hooks](https://www.npmjs.com/package/eslint-plugin-react-hooks)

## Conclusão

O erro foi causado por uma violação das regras dos hooks do React. A solução foi:

1. Identificar onde o hook estava sendo chamado incorretamente
2. Mover o destructuring das variáveis necessárias para o topo do componente
3. Remover a chamada do hook de dentro do onClick handler
4. Usar as variáveis já disponíveis no escopo do componente

**Tempo de correção:** ~5 minutos  
**Impacto:** Crítico (aplicação não funcionava)  
**Prevenção:** Seguir as regras dos hooks e usar ESLint

**Status:** ✅ **RESOLVIDO** - Aplicação funcionando corretamente!
