# Correção de Erro: Too Many Re-renders

## Problema Identificado

**Erro:** `Too many re-renders. React limits the number of renders to prevent an infinite loop.`

**Causa:** Conflito de nomes de funções no arquivo `Emissao.tsx`

## Detalhes do Problema

### Antes da Correção

```typescript
// Linha 6 - Importação
import { validateCPF, getCPFErrorMessage, formatCPF } from '../utils/validation';

// Linha 85 - Função local com MESMO NOME
const validateCPF = (index: number, cpf: string) => {
  const error = getCPFErrorMessage(cpf);
  setCpfErrors(prev => {
    const newErrors = { ...prev };
    if (error) {
      newErrors[index] = error;
    } else {
      delete newErrors[index];
    }
    return newErrors;
  });
};
```

### O Que Aconteceu

1. A função `validateCPF` foi importada do módulo `validation.ts`
2. Uma função local com o **mesmo nome** foi declarada no componente
3. Isso criou um conflito de escopo
4. Quando a função era chamada, o React tentava executar a função errada
5. Isso causou um loop infinito de re-renders

## Solução Aplicada

### 1. Renomear a Função Local

```typescript
// Antes
const validateCPF = (index: number, cpf: string) => { ... }

// Depois
const checkPassengerCPF = (index: number, cpf: string) => { ... }
```

### 2. Atualizar Todas as Chamadas

```typescript
// Antes
validateCPF(i, value);

// Depois
checkPassengerCPF(i, value);
```

### 3. Remover Importação Não Utilizada

```typescript
// Antes
import { validateCPF, getCPFErrorMessage, formatCPF } from '../utils/validation';

// Depois
import { getCPFErrorMessage } from '../utils/validation';
```

## Lições Aprendidas

### ⚠️ Evitar Conflitos de Nomes

**NUNCA** declare funções locais com o mesmo nome de funções importadas:

```typescript
// ❌ ERRADO
import { validateCPF } from './utils';
const validateCPF = () => { ... } // Conflito!

// ✅ CORRETO
import { validateCPF } from './utils';
const checkUserCPF = () => { ... } // Nome diferente
```

### 📋 Boas Práticas

1. **Nomes Descritivos**
   - Use nomes que indiquem o escopo: `checkPassengerCPF` em vez de `validateCPF`
   - Prefixe com o contexto: `handleUserValidation`, `processOrderData`

2. **Verificar Importações**
   - Antes de criar uma função, verifique se já existe uma importada
   - Use IDEs com autocomplete para evitar conflitos

3. **Padronização**
   - `handle*` para event handlers
   - `check*` para validações
   - `process*` para transformações
   - `format*` para formatações

4. **TypeScript Ajuda**
   - O TypeScript detecta conflitos de tipos
   - Use `tsc --noEmit` para verificar erros antes do build

## Padrões Comuns que Causam Re-renders Infinitos

### 1. setState no Render

```typescript
// ❌ ERRADO
function Component() {
  const [count, setCount] = useState(0);
  setCount(count + 1); // Loop infinito!
  return <div>{count}</div>;
}

// ✅ CORRETO
function Component() {
  const [count, setCount] = useState(0);
  useEffect(() => {
    setCount(count + 1);
  }, []);
  return <div>{count}</div>;
}
```

### 2. useEffect sem Dependências

```typescript
// ❌ ERRADO
useEffect(() => {
  setData(fetchData());
}); // Executa em TODO render!

// ✅ CORRETO
useEffect(() => {
  setData(fetchData());
}, []); // Executa apenas uma vez
```

### 3. Objetos/Arrays no JSX

```typescript
// ❌ ERRADO
<Component style={{ color: 'red' }} /> // Novo objeto a cada render!

// ✅ CORRETO
const style = { color: 'red' };
<Component style={style} />
```

### 4. Funções Inline em Event Handlers

```typescript
// ❌ ERRADO
<button onClick={() => handleClick(id)}>Click</button>

// ✅ CORRETO
const handleButtonClick = () => handleClick(id);
<button onClick={handleButtonClick}>Click</button>
```

## Ferramentas de Debug

### React DevTools

1. Instale a extensão React DevTools
2. Abra o Profiler
3. Grave uma sessão
4. Identifique componentes que re-renderizam excessivamente

### Console Warnings

O React emite warnings quando detecta problemas:
- "Warning: Cannot update a component while rendering a different component"
- "Warning: Maximum update depth exceeded"

### ESLint Rules

```json
{
  "rules": {
    "react-hooks/exhaustive-deps": "warn",
    "react/jsx-no-bind": "warn"
  }
}
```

## Checklist de Prevenção

Antes de fazer commit, verifique:

- [ ] Não há funções locais com mesmo nome de importações
- [ ] useEffects têm dependências corretas
- [ ] Não há setState chamado diretamente no render
- [ ] Objetos/arrays são memoizados quando necessário
- [ ] Funções inline são evitadas em props
- [ ] Build passa sem warnings
- [ ] Testes passam sem erros de re-render

## Arquivos Corrigidos

### `/src/pages/Emissao.tsx`

**Mudanças:**
1. Renomeada função `validateCPF` para `checkPassengerCPF` (linha 85)
2. Atualizadas chamadas nas linhas 643 e 654
3. Removida importação não utilizada de `validateCPF`

**Resultado:**
- ✅ Sem conflito de nomes
- ✅ Build bem-sucedido
- ✅ Validação de CPF funcionando corretamente
- ✅ Sem re-renders infinitos

## Testes Realizados

1. **Build:** `npm run build` ✅ Sucesso
2. **TypeScript:** `npm run typecheck` ✅ Sem erros
3. **Funcional:** Validação de CPF funcionando ✅
4. **Performance:** Sem loops de re-render ✅

## Conclusão

O erro foi causado por um simples conflito de nomes de funções. A solução foi:

1. Identificar o conflito
2. Renomear a função local
3. Atualizar todas as referências
4. Remover importações não utilizadas

**Tempo de correção:** ~5 minutos  
**Impacto:** Crítico (sistema não funcionava)  
**Prevenção:** Usar nomes descritivos e verificar importações

## Referências

- [React Docs: Rules of Hooks](https://react.dev/learn/rules-of-hooks)
- [React Docs: useEffect](https://react.dev/reference/react/useEffect)
- [React Docs: useState](https://react.dev/reference/react/useState)
