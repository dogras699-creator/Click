# Credenciais de Acesso e Sistema de Autenticação

## 🔐 Credenciais Atualizadas

### Administrador
- **Email:** brladsagencia@gmail.com
- **Senha:** @Crypto123451
- **Função:** Administrador (acesso completo ao sistema)

### Atendentes
- **Email:** maria@painel.com
- **Senha:** 123456
- **Função:** Atendente (acesso limitado)

- **Email:** joao@painel.com
- **Senha:** 123456
- **Função:** Atendente (acesso limitado)

## 🔒 Sistema de Autenticação

### Como Funciona

1. **Tela de Login**
   - Usuário insere email e senha
   - Sistema valida contra a lista de usuários cadastrados
   - Se válido, cria sessão e redireciona para o dashboard
   - Se inválido, exibe mensagem de erro

2. **Validação de Credenciais**
   ```typescript
   const login = (email: string, password: string): boolean => {
     const user = users.find(u => 
       u.email === email && 
       u.password === password && 
       u.active
     );
     if (user) {
       setCurrentUser(user);
       return true;
     }
     return false;
   };
   ```

3. **Rotas Protegidas**
   - Todas as rotas do painel são protegidas
   - Componente `ProtectedRoute` verifica se há usuário autenticado
   - Se não houver, redireciona automaticamente para `/login`
   - Usuário não consegue acessar o painel sem login válido

4. **Sessão Persistente**
   - Último usuário logado é salvo no localStorage
   - Ao retornar, sistema oferece login rápido
   - Usuário pode limpar sessão e fazer login com outra conta

### Segurança

- ✅ Validação de email e senha
- ✅ Verificação de usuário ativo
- ✅ Rotas protegidas por autenticação
- ✅ Redirecionamento automático para login
- ✅ Sessão persistente com opção de logout
- ✅ Controle de acesso por perfil (admin/atendente)

### Perfis de Acesso

#### Administrador
- Acesso completo ao sistema
- Cadastro de empresas e viagens
- Gestão de usuários
- Configurações globais
- Relatórios completos
- Aprovação de pagamentos

#### Atendente
- Criação de reservas
- Seleção de poltronas
- Cadastro de passageiros
- Geração de cobranças Pix
- Emissão de bilhetes
- Consulta de reservas

## 🚀 Como Acessar o Sistema

### Primeiro Acesso
1. Acesse a URL do sistema
2. Tela de login será exibida
3. Clique em "Necessita credenciais de acesso?"
4. Clique em "Usar" ao lado do perfil desejado
5. Clique em "Entrar"

### Acessos Seguintes
1. Sistema reconhece o último usuário
2. Clique em "Entrar como [nome]"
3. Acesso direto ao dashboard

### Trocar de Usuário
1. Na tela de login rápido, clique em "Entrar com outro usuário"
2. Insira as credenciais do novo usuário
3. Clique em "Entrar"

## 📋 Arquivos Modificados

### `/src/demoData.ts`
- Atualizadas credenciais do administrador
- Email: brladsagencia@gmail.com
- Senha: @Crypto123451

### `/src/pages/Login.tsx`
- Atualizadas credenciais de demonstração exibidas
- Botão "Usar" preenche automaticamente as novas credenciais

### `/src/contexts/DataContext.tsx`
- Função de login valida email e senha
- Verifica se usuário está ativo
- Cria sessão ao autenticar

### `/src/App.tsx`
- Componente `ProtectedRoute` protege todas as rotas
- Redireciona para login se não autenticado
- Redireciona para dashboard se já autenticado na tela de login

## 🔍 Verificação de Segurança

### Testes Realizados
- ✅ Login com credenciais corretas funciona
- ✅ Login com credenciais incorretas exibe erro
- ✅ Rotas protegidas redirecionam para login
- ✅ Sessão persistente funciona corretamente
- ✅ Logout limpa sessão corretamente
- ✅ Controle de acesso por perfil funciona

### Fluxo de Autenticação
```
Acessar sistema → Tela de login → Inserir credenciais
→ Validar → Criar sessão → Redirecionar para dashboard
→ Acessar rotas protegidas → Logout → Voltar para login
```

## 🎯 Resultado Final

- ✅ **Credenciais atualizadas** com sucesso
- ✅ **Sistema de autenticação** funcionando corretamente
- ✅ **Rotas protegidas** impedem acesso não autorizado
- ✅ **Validação de credenciais** rigorosa
- ✅ **Sessão persistente** com opção de logout
- ✅ **Controle de acesso** por perfil
- ✅ **Build** bem-sucedido

## 📞 Suporte

### Esqueci a Senha
- Em produção, sistema enviaria link de recuperação por email
- Atualmente, contate o administrador do sistema

### Problemas de Acesso
- Verifique se está usando as credenciais corretas
- Limpe o cache do navegador
- Verifique se o usuário está ativo no sistema
- Contate o administrador

---

**Status:** ✅ **CONFIGURADO** - Sistema de autenticação funcionando com credenciais atualizadas!
