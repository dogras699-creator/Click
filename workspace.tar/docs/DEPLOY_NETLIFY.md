# 🚀 Guia de Deploy no Netlify

## 📋 Pré-requisitos

- ✅ Conta no Netlify (https://app.netlify.com/)
- ✅ Repositório Git (GitHub, GitLab ou Bitbucket)
- ✅ Node.js 18+ instalado localmente

---

## 🎯 Método 1: Deploy via Interface Netlify (Recomendado)

### Passo 1: Preparar o Repositório

1. Faça push do código para o GitHub/GitLab:
```bash
git add .
git commit -m "Preparar para deploy no Netlify"
git push origin main
```

### Passo 2: Conectar ao Netlify

1. Acesse https://app.netlify.com/
2. Clique em **"Add new site"** → **"Import an existing project"**
3. Escolha seu provedor Git (GitHub, GitLab, Bitbucket)
4. Selecione o repositório do projeto

### Passo 3: Configurar Build Settings

O Netlify detectará automaticamente as configurações do `netlify.toml`, mas verifique:

- **Build command:** `npm run build`
- **Publish directory:** `dist`
- **Node version:** `18`

### Passo 4: Deploy

1. Clique em **"Deploy site"**
2. Aguarde o build completar (2-3 minutos)
3. Seu site estará disponível em: `https://seu-site.netlify.app`

### Passo 5: Configurar Domínio Customizado (Opcional)

1. Vá em **"Domain settings"**
2. Clique em **"Add custom domain"**
3. Siga as instruções para configurar DNS

---

## 🎯 Método 2: Deploy via Netlify CLI

### Instalação

```bash
npm install -g netlify-cli
```

### Login

```bash
netlify login
```

### Deploy

```bash
# Build local
npm run build

# Deploy para produção
netlify deploy --prod
```

---

## 🎯 Método 3: Deploy Drag & Drop

### Passo 1: Build Local

```bash
npm run build
```

### Passo 2: Deploy Manual

1. Acesse https://app.netlify.com/drop
2. Arraste a pasta `dist` para a área de upload
3. Aguarde o deploy completar

---

## ⚙️ Configurações Importantes

### netlify.toml

O arquivo `netlify.toml` já está configurado com:

```toml
[build]
  command = "npm run build"
  publish = "dist"

[build.environment]
  NODE_VERSION = "18"

[[redirects]]
  from = "/*"
  to = "/index.html"
  status = 200
```

### Variáveis de Ambiente (Se Necessário)

Se precisar de variáveis de ambiente:

1. Vá em **"Site settings"** → **"Environment variables"**
2. Adicione as variáveis necessárias
3. Faça novo deploy

---

## 🔒 Segurança

### Headers de Segurança

O `netlify.toml` já configura headers de segurança:

- X-Frame-Options: DENY
- X-XSS-Protection: 1; mode=block
- X-Content-Type-Options: nosniff
- Referrer-Policy: strict-origin-when-cross-origin

### Cache de Assets

Assets estáticos são cacheados por 1 ano:

```toml
[[headers]]
  for = "/assets/*"
  [headers.values]
    Cache-Control = "public, max-age=31536000, immutable"
```

---

## 📊 Monitoramento

### Deploy Status

1. Acesse o dashboard do Netlify
2. Veja o status de cada deploy
3. Monitore logs de build

### Analytics

1. Vá em **"Analytics"**
2. Veja métricas de performance
3. Monitore uso de banda

---

## 🐛 Troubleshooting

### Problema: Build Falha

**Solução:**
```bash
# Limpar cache local
rm -rf node_modules dist
npm install
npm run build

# Verificar se há erros
npm run typecheck
```

### Problema: Rotas Não Funcionam

**Solução:**
- Verifique se o arquivo `public/_redirects` existe
- Verifique se o `netlify.toml` tem a configuração de redirects

### Problema: Assets Não Carregam

**Solução:**
```bash
# Verificar se o build foi gerado corretamente
ls -la dist/

# Verificar se os assets estão na pasta correta
ls -la dist/assets/
```

### Problema: CORS Errors

**Solução:**
Adicione no `netlify.toml`:

```toml
[[headers]]
  for = "/*"
  [headers.values]
    Access-Control-Allow-Origin = "*"
```

---

## 📈 Otimizações

### Code Splitting

O Vite já faz code splitting automaticamente. Para otimizar mais:

```typescript
// Usar lazy loading em rotas
const Dashboard = lazy(() => import('./pages/Dashboard'));
```

### Image Optimization

Use o plugin `vite-plugin-imagemin`:

```bash
npm install -D vite-plugin-imagemin
```

### Bundle Analysis

```bash
npm install -D rollup-plugin-visualizer
```

---

## 🎓 Recursos Úteis

### Documentação Netlify

- [Netlify Docs](https://docs.netlify.com/)
- [Netlify CLI](https://docs.netlify.com/cli/get-started/)
- [Netlify Functions](https://docs.netlify.com/functions/overview/)

### Deploy Contínuo

O Netlify faz deploy automático quando você faz push para:
- `main` → Produção
- `develop` → Preview
- Branches → Deploy previews

---

## ✅ Checklist de Deploy

- [ ] Código pushado para o repositório
- [ ] `netlify.toml` configurado
- [ ] `public/_redirects` criado
- [ ] Build local testado (`npm run build`)
- [ ] Site conectado ao Netlify
- [ ] Deploy realizado com sucesso
- [ ] Site testado em produção
- [ ] Domínio customizado configurado (opcional)
- [ ] HTTPS ativado (automático no Netlify)

---

## 🎉 Pronto!

Seu painel está pronto para deploy no Netlify!

**Próximos passos:**
1. Faça push do código
2. Conecte ao Netlify
3. Configure o deploy
4. Teste em produção

**Suporte:**
- Documentação: `/docs/`
- Problemas: Ver seção Troubleshooting
- Netlify Support: https://netlify.com/support

---

**Status:** ✅ **PRONTO PARA DEPLOY**
