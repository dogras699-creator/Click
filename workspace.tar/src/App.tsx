import React from 'react';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { DataProvider, useData } from './contexts/DataContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Emissao from './pages/Emissao';
import Reservations from './pages/Reservations';
import Trips from './pages/Trips';
import Companies from './pages/Companies';
import Clients from './pages/Clients';
import Payments from './pages/Payments';
import Tickets from './pages/Tickets';
import Reports from './pages/Reports';
import SettingsPage from './pages/Settings';

function ProtectedRoute({ children }: { children: React.ReactNode }) {
  const { currentUser } = useData();
  if (!currentUser) return <Navigate to="/login" replace />;
  return <>{children}</>;
}

function AppRoutes() {
  const { currentUser } = useData();

  return (
    <Routes>
      <Route path="/login" element={currentUser ? <Navigate to="/dashboard" replace /> : <Login />} />
      <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
        <Route index element={<Navigate to="/dashboard" replace />} />
        <Route path="dashboard" element={<Dashboard />} />
        <Route path="emissao" element={<Emissao />} />
        <Route path="reservas" element={<Reservations />} />
        <Route path="viagens" element={<Trips />} />
        <Route path="empresas" element={<Companies />} />
        <Route path="clientes" element={<Clients />} />
        <Route path="pagamentos" element={<Payments />} />
        <Route path="bilhetes" element={<Tickets />} />
        <Route path="relatorios" element={<Reports />} />
        <Route path="configuracoes" element={<SettingsPage />} />
      </Route>
      <Route path="*" element={<Navigate to="/dashboard" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <BrowserRouter>
      <DataProvider>
        <AppRoutes />
      </DataProvider>
    </BrowserRouter>
  );
}
