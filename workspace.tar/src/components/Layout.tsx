import React, { useState } from 'react';
import { useNavigate, useLocation, Outlet } from 'react-router-dom';
import { useData } from '../contexts/DataContext';
import {
  LayoutDashboard, Bus, MapPin, Ticket, Users, CreditCard,
  FileText, Settings, LogOut, Menu, X, ChevronRight, Building2
} from 'lucide-react';

export default function Layout() {
  const { currentUser, logout, settings } = useData();
  const navigate = useNavigate();
  const location = useLocation();
  const [sidebarOpen, setSidebarOpen] = useState(false);

  const menuItems = [
    { path: '/dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { path: '/emissao', label: 'Nova Emissão', icon: Ticket },
    { path: '/reservas', label: 'Reservas', icon: FileText },
    { path: '/bilhetes', label: 'Bilhetes', icon: Ticket },
    { path: '/viagens', label: 'Viagens', icon: Bus },
    { path: '/empresas', label: 'Empresas', icon: Building2 },
    { path: '/clientes', label: 'Clientes', icon: Users },
    { path: '/pagamentos', label: 'Pagamentos', icon: CreditCard },
    { path: '/relatorios', label: 'Relatórios', icon: MapPin },
    { path: '/configuracoes', label: 'Configurações', icon: Settings },
  ];

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="flex h-screen bg-gray-50">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div className="fixed inset-0 bg-black/50 z-40 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}

      {/* Sidebar */}
      <aside className={`fixed lg:static inset-y-0 left-0 z-50 w-64 bg-gradient-to-b from-purple-900 to-purple-800 text-white transform transition-transform duration-300 ${sidebarOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0'}`}>
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="p-4 border-b border-purple-700">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Bus className="w-7 h-7 text-purple-300" />
                <div>
                  <h1 className="font-bold text-sm leading-tight">{settings.nome}</h1>
                  <p className="text-xs text-purple-300">Painel de Controle</p>
                </div>
              </div>
              <button className="lg:hidden" onClick={() => setSidebarOpen(false)}>
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>



          {/* Navigation */}
          <nav className="flex-1 p-3 space-y-1 overflow-y-auto">
            {menuItems.map(item => {
              const Icon = item.icon;
              const isActive = location.pathname === item.path;
              return (
                <button
                  key={item.path}
                  onClick={() => { navigate(item.path); setSidebarOpen(false); }}
                  className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm transition-all ${isActive ? 'bg-white/15 text-white shadow-lg' : 'text-purple-200 hover:bg-white/10 hover:text-white'}`}
                >
                  <Icon className="w-4.5 h-4.5" />
                  <span>{item.label}</span>
                  {isActive && <ChevronRight className="w-4 h-4 ml-auto" />}
                </button>
              );
            })}
          </nav>

          {/* User info */}
          <div className="p-4 border-t border-purple-700">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 bg-purple-600 rounded-full flex items-center justify-center text-sm font-bold">
                {currentUser?.name.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{currentUser?.name}</p>
                <p className="text-xs text-purple-300 capitalize">{currentUser?.role === 'admin' ? 'Administrador' : 'Atendente'}</p>
              </div>
              <button onClick={handleLogout} className="p-1.5 hover:bg-white/10 rounded-lg transition-colors" title="Sair">
                <LogOut className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      </aside>

      {/* Main content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Top bar */}
        <header className="bg-white border-b border-gray-200 px-4 py-3 flex items-center gap-4 shadow-sm">
          <button className="lg:hidden p-2 hover:bg-gray-100 rounded-lg" onClick={() => setSidebarOpen(true)}>
            <Menu className="w-5 h-5" />
          </button>
          <div className="flex-1">
            <h2 className="text-lg font-semibold text-gray-800">
              {menuItems.find(i => i.path === location.pathname)?.label || 'Painel'}
            </h2>
          </div>
          <div className="flex items-center gap-2">
            <span className="text-xs text-gray-500 hidden sm:block">
              {new Date().toLocaleDateString('pt-BR', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
            </span>
          </div>
        </header>

        {/* Content */}
        <main className="flex-1 overflow-y-auto p-4 lg:p-6">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
