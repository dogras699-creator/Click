import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { User, Company, Trip, Reservation, AgencySettings, LogEntry, PixKey, PixCharge } from '../types';
import { demoUsers, demoCompanies, demoTrips, demoReservations, defaultAgencySettings, demoPixKeys } from '../demoData';

interface DataContextType {
  users: User[];
  companies: Company[];
  trips: Trip[];
  reservations: Reservation[];
  settings: AgencySettings;
  logs: LogEntry[];
  pixKeys: PixKey[];
  pixCharges: PixCharge[];
  currentUser: User | null;
  login: (email: string, password: string) => boolean;
  logout: () => void;
  addCompany: (company: Company) => void;
  updateCompany: (company: Company) => void;
  deleteCompany: (id: string) => void;
  addTrip: (trip: Trip) => void;
  updateTrip: (trip: Trip) => void;
  deleteTrip: (id: string) => void;
  addReservation: (reservation: Reservation) => void;
  updateReservation: (reservation: Reservation) => void;
  updateSettings: (settings: AgencySettings) => void;
  addUser: (user: User) => void;
  updateUser: (user: User) => void;
  addLog: (action: string, details: string) => void;
  getCompanyById: (id: string) => Company | undefined;
  getTripById: (id: string) => Trip | undefined;
  getReservationById: (id: string) => Reservation | undefined;
  addPixKey: (pixKey: PixKey) => void;
  updatePixKey: (pixKey: PixKey) => void;
  deletePixKey: (id: string) => void;
  setDefaultPixKey: (id: string) => void;
  addPixCharge: (charge: PixCharge) => void;
  updatePixCharge: (charge: PixCharge) => void;
  getPixKeyById: (id: string) => PixKey | undefined;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export function DataProvider({ children }: { children: ReactNode }) {
  // Verificar se precisa atualizar as credenciais do administrador
  const checkAndUpdateCredentials = () => {
    const savedUsers = localStorage.getItem('users');
    if (savedUsers) {
      const users = JSON.parse(savedUsers);
      const adminUser = users.find((u: User) => u.id === '1');
      
      // Se o admin existe mas tem credenciais antigas, atualizar
      if (adminUser && (adminUser.email !== 'brladsagencia@gmail.com' || adminUser.password !== '@Crypto123451')) {
        adminUser.email = 'brladsagencia@gmail.com';
        adminUser.password = '@Crypto123451';
        localStorage.setItem('users', JSON.stringify(users));
        return users;
      }
      return users;
    }
    return demoUsers;
  };

  const [users, setUsers] = useState<User[]>(() => {
    return checkAndUpdateCredentials();
  });

  const [companies, setCompanies] = useState<Company[]>(() => {
    const saved = localStorage.getItem('companies');
    return saved ? JSON.parse(saved) : demoCompanies;
  });

  const [trips, setTrips] = useState<Trip[]>(() => {
    const saved = localStorage.getItem('trips');
    return saved ? JSON.parse(saved) : demoTrips;
  });

  const [reservations, setReservations] = useState<Reservation[]>(() => {
    const saved = localStorage.getItem('reservations');
    return saved ? JSON.parse(saved) : demoReservations;
  });

  const [settings, setSettings] = useState<AgencySettings>(() => {
    const saved = localStorage.getItem('settings');
    return saved ? JSON.parse(saved) : defaultAgencySettings;
  });

  const [logs, setLogs] = useState<LogEntry[]>(() => {
    const saved = localStorage.getItem('logs');
    return saved ? JSON.parse(saved) : [];
  });

  const [pixKeys, setPixKeys] = useState<PixKey[]>(() => {
    const saved = localStorage.getItem('pixKeys');
    return saved ? JSON.parse(saved) : demoPixKeys;
  });

  const [pixCharges, setPixCharges] = useState<PixCharge[]>(() => {
    const saved = localStorage.getItem('pixCharges');
    return saved ? JSON.parse(saved) : [];
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const saved = localStorage.getItem('currentUser');
    return saved ? JSON.parse(saved) : null;
  });

  useEffect(() => { localStorage.setItem('users', JSON.stringify(users)); }, [users]);
  useEffect(() => { localStorage.setItem('companies', JSON.stringify(companies)); }, [companies]);
  useEffect(() => { localStorage.setItem('trips', JSON.stringify(trips)); }, [trips]);
  useEffect(() => { localStorage.setItem('reservations', JSON.stringify(reservations)); }, [reservations]);
  useEffect(() => { localStorage.setItem('settings', JSON.stringify(settings)); }, [settings]);
  useEffect(() => { localStorage.setItem('logs', JSON.stringify(logs)); }, [logs]);
  useEffect(() => { localStorage.setItem('pixKeys', JSON.stringify(pixKeys)); }, [pixKeys]);
  useEffect(() => { localStorage.setItem('pixCharges', JSON.stringify(pixCharges)); }, [pixCharges]);
  useEffect(() => {
    if (currentUser) localStorage.setItem('currentUser', JSON.stringify(currentUser));
    else localStorage.removeItem('currentUser');
  }, [currentUser]);

  const login = (email: string, password: string): boolean => {
    const user = users.find(u => u.email === email && u.password === password && u.active);
    if (user) {
      setCurrentUser(user);
      return true;
    }
    return false;
  };

  const logout = () => {
    setCurrentUser(null);
  };

  const addCompany = (company: Company) => setCompanies(prev => [...prev, company]);
  const updateCompany = (company: Company) => setCompanies(prev => prev.map(c => c.id === company.id ? company : c));
  const deleteCompany = (id: string) => setCompanies(prev => prev.filter(c => c.id !== id));

  const addTrip = (trip: Trip) => setTrips(prev => [...prev, trip]);
  const updateTrip = (trip: Trip) => setTrips(prev => prev.map(t => t.id === trip.id ? trip : t));
  const deleteTrip = (id: string) => setTrips(prev => prev.filter(t => t.id !== id));

  const addReservation = (reservation: Reservation) => setReservations(prev => [...prev, reservation]);
  const updateReservation = (reservation: Reservation) => setReservations(prev => prev.map(r => r.id === reservation.id ? reservation : r));

  const updateSettings = (s: AgencySettings) => setSettings(s);
  const addUser = (user: User) => setUsers(prev => [...prev, user]);
  const updateUser = (user: User) => setUsers(prev => prev.map(u => u.id === user.id ? user : u));

  const addLog = (action: string, details: string) => {
    const entry: LogEntry = {
      id: Date.now().toString(),
      userId: currentUser?.id || '',
      action,
      details,
      timestamp: new Date().toISOString()
    };
    setLogs(prev => [entry, ...prev]);
  };

  const getCompanyById = (id: string) => companies.find(c => c.id === id);
  const getTripById = (id: string) => trips.find(t => t.id === id);
  const getReservationById = (id: string) => reservations.find(r => r.id === id);

  const addPixKey = (pixKey: PixKey) => setPixKeys(prev => [...prev, pixKey]);
  const updatePixKey = (pixKey: PixKey) => setPixKeys(prev => prev.map(k => k.id === pixKey.id ? pixKey : k));
  const deletePixKey = (id: string) => setPixKeys(prev => prev.filter(k => k.id !== id));
  const setDefaultPixKey = (id: string) => {
    setPixKeys(prev => prev.map(k => ({ ...k, isDefault: k.id === id })));
  };
  const addPixCharge = (charge: PixCharge) => setPixCharges(prev => [...prev, charge]);
  const updatePixCharge = (charge: PixCharge) => setPixCharges(prev => prev.map(c => c.id === charge.id ? charge : c));
  const getPixKeyById = (id: string) => pixKeys.find(k => k.id === id);

  return (
    <DataContext.Provider value={{
      users, companies, trips, reservations, settings, logs, pixKeys, pixCharges, currentUser,
      login, logout, addCompany, updateCompany, deleteCompany,
      addTrip, updateTrip, deleteTrip, addReservation, updateReservation,
      updateSettings, addUser, updateUser, addLog,
      getCompanyById, getTripById, getReservationById,
      addPixKey, updatePixKey, deletePixKey, setDefaultPixKey,
      addPixCharge, updatePixCharge, getPixKeyById
    }}>
      {children}
    </DataContext.Provider>
  );
}

export function useData() {
  const context = useContext(DataContext);
  if (!context) throw new Error('useData must be used within DataProvider');
  return context;
}
