import { Company, Trip, User, Reservation, AgencySettings } from './types';
import { v4 as uuidv4 } from 'uuid';

export const defaultAgencySettings: AgencySettings = {
  nome: 'Painel de Emissão Rodoviária',
  razaoSocial: 'Agência Viagem Certa LTDA',
  cnpj: '12.345.678/0001-90',
  endereco: 'Av. Paulista, 1000 - Sala 501, São Paulo - SP',
  telefone: '(11) 3456-7890',
  email: 'contato@viagemcerta.com.br',
  sac: '0800 123 4567',
  horarioFuncionamento: 'Seg a Sex: 06h-22h | Sáb: 07h-18h'
};

export const demoUsers: User[] = [
  {
    id: '1',
    name: 'Administrador',
    email: 'brladsagencia@gmail.com',
    password: '@Crypto123451',
    role: 'admin',
    active: true,
    createdAt: '2024-01-01T00:00:00Z'
  },
  {
    id: '2',
    name: 'Maria Silva',
    email: 'maria@painel.com',
    password: '123456',
    role: 'attendant',
    active: true,
    createdAt: '2024-01-15T00:00:00Z'
  },
  {
    id: '3',
    name: 'João Santos',
    email: 'joao@painel.com',
    password: '123456',
    role: 'attendant',
    active: true,
    createdAt: '2024-02-01T00:00:00Z'
  }
];

export const demoCompanies: Company[] = [
  {
    id: 'c1',
    razaoSocial: 'Viação Águia Branca S.A.',
    nomeFantasia: 'Águia Branca',
    cnpj: '27.678.123/0001-45',
    telefone: '(27) 3333-4444',
    endereco: 'Av. Vitória, 500 - Vitória, ES',
    email: 'contato@aguiabranca.com.br',
    active: true
  },
  {
    id: 'c2',
    razaoSocial: 'Viação Cometa S.A.',
    nomeFantasia: 'Cometa',
    cnpj: '33.456.789/0001-12',
    telefone: '(11) 4000-5000',
    endereco: 'Rod. Pres. Dutra, Km 220 - São Paulo, SP',
    email: 'contato@cometa.com.br',
    active: true
  },
  {
    id: 'c3',
    razaoSocial: 'Viação Itapemirim S.A.',
    nomeFantasia: 'Itapemirim',
    cnpj: '16.789.012/0001-33',
    telefone: '(27) 3222-1111',
    endereco: 'Av. Beira Mar, 200 - Vitória, ES',
    email: 'contato@itapemirim.com.br',
    active: true
  },
  {
    id: 'c4',
    razaoSocial: 'Expresso Gardenia LTDA',
    nomeFantasia: 'Gardenia',
    cnpj: '45.123.678/0001-56',
    telefone: '(11) 2222-3333',
    endereco: 'Rua das Flores, 100 - Campinas, SP',
    email: 'contato@gardenia.com.br',
    active: true
  }
];

const today = new Date();
const formatDate = (d: Date) => d.toISOString().split('T')[0];
const addDays = (d: Date, n: number) => { const r = new Date(d); r.setDate(r.getDate() + n); return r; };

export const demoTrips: Trip[] = [
  {
    id: 't1',
    companyId: 'c1',
    nome: 'São Paulo - Vitória Expresso',
    origem: 'São Paulo - SP',
    destino: 'Vitória - ES',
    dataSaida: formatDate(today),
    horarioSaida: '08:00',
    dataChegada: formatDate(today),
    horarioChegada: '19:30',
    duracao: '11h30min',
    classe: 'executivo',
    linha: 'SP-VT-001',
    prefixo: 'AB-1001',
    numeroServico: '2024-0891',
    plataforma: '5',
    localEmbarque: 'Terminal Tietê - Plataforma 5',
    tarifa: 189.90,
    pedagio: 15.00,
    taxaEmbarque: 8.50,
    seguro: 5.00,
    outrasTaxas: 3.00,
    desconto: 0,
    valorTotal: 221.40,
    andares: 1,
    poltronas: 46,
    poltronasOcupadas: ['3', '7', '12', '18', '22', '25', '31', '35', '40'],
    poltronasBloqueadas: ['1', '2'],
    active: true
  },
  {
    id: 't2',
    companyId: 'c2',
    nome: 'Rio de Janeiro - São Paulo Leito',
    origem: 'Rio de Janeiro - RJ',
    destino: 'São Paulo - SP',
    dataSaida: formatDate(today),
    horarioSaida: '22:00',
    dataChegada: formatDate(addDays(today, 1)),
    horarioChegada: '06:30',
    duracao: '8h30min',
    classe: 'leito',
    linha: 'RJ-SP-002',
    prefixo: 'CM-2002',
    numeroServico: '2024-1234',
    plataforma: '3',
    localEmbarque: 'Rodoviária Novo Rio - Plataforma 3',
    tarifa: 259.90,
    pedagio: 22.00,
    taxaEmbarque: 12.00,
    seguro: 8.00,
    outrasTaxas: 5.00,
    desconto: 10.00,
    valorTotal: 296.90,
    andares: 2,
    poltronas: 56,
    poltronasOcupadas: ['5', '10', '15', '20', '28', '33', '38', '42', '48', '52'],
    poltronasBloqueadas: ['1', '2', '3', '4'],
    active: true
  },
  {
    id: 't3',
    companyId: 'c3',
    nome: 'Belo Horizonte - Rio de Janeiro Convencional',
    origem: 'Belo Horizonte - MG',
    destino: 'Rio de Janeiro - RJ',
    dataSaida: formatDate(addDays(today, 1)),
    horarioSaida: '07:00',
    dataChegada: formatDate(addDays(today, 1)),
    horarioChegada: '14:00',
    duracao: '7h00min',
    classe: 'convencional',
    linha: 'BH-RJ-003',
    prefixo: 'IT-3003',
    numeroServico: '2024-0567',
    plataforma: '7',
    localEmbarque: 'Terminal Rodoviário de BH - Plataforma 7',
    tarifa: 129.90,
    pedagio: 10.00,
    taxaEmbarque: 6.50,
    seguro: 4.00,
    outrasTaxas: 2.00,
    desconto: 0,
    valorTotal: 152.40,
    andares: 1,
    poltronas: 44,
    poltronasOcupadas: ['2', '8', '14', '19', '24', '30', '36', '41'],
    poltronasBloqueadas: [],
    active: true
  },
  {
    id: 't4',
    companyId: 'c4',
    nome: 'Campinas - Curitiba Semi-Leito',
    origem: 'Campinas - SP',
    destino: 'Curitiba - PR',
    dataSaida: formatDate(addDays(today, 1)),
    horarioSaida: '14:00',
    dataChegada: formatDate(addDays(today, 1)),
    horarioChegada: '22:30',
    duracao: '8h30min',
    classe: 'semi-leito',
    linha: 'CP-CT-004',
    prefixo: 'GD-4004',
    numeroServico: '2024-0789',
    plataforma: '2',
    localEmbarque: 'Terminal Central de Campinas - Plataforma 2',
    tarifa: 169.90,
    pedagio: 18.00,
    taxaEmbarque: 9.00,
    seguro: 6.00,
    outrasTaxas: 3.50,
    desconto: 5.00,
    valorTotal: 201.40,
    andares: 1,
    poltronas: 48,
    poltronasOcupadas: ['4', '9', '16', '21', '27', '32', '38', '43', '46'],
    poltronasBloqueadas: ['1', '2'],
    active: true
  },
  {
    id: 't5',
    companyId: 'c1',
    nome: 'São Paulo - Belo Horizonte Executivo',
    origem: 'São Paulo - SP',
    destino: 'Belo Horizonte - MG',
    dataSaida: formatDate(addDays(today, 2)),
    horarioSaida: '06:00',
    dataChegada: formatDate(addDays(today, 2)),
    horarioChegada: '14:30',
    duracao: '8h30min',
    classe: 'executivo',
    linha: 'SP-BH-005',
    prefixo: 'AB-5005',
    numeroServico: '2024-0345',
    plataforma: '8',
    localEmbarque: 'Terminal Tietê - Plataforma 8',
    tarifa: 159.90,
    pedagio: 14.00,
    taxaEmbarque: 7.50,
    seguro: 5.00,
    outrasTaxas: 2.50,
    desconto: 0,
    valorTotal: 188.90,
    andares: 1,
    poltronas: 46,
    poltronasOcupadas: ['5', '11', '17', '23', '29', '34', '39', '44'],
    poltronasBloqueadas: ['1', '2'],
    active: true
  },
  {
    id: 't6',
    companyId: 'c2',
    nome: 'São Paulo - Curitiba Leito',
    origem: 'São Paulo - SP',
    destino: 'Curitiba - PR',
    dataSaida: formatDate(addDays(today, 2)),
    horarioSaida: '23:00',
    dataChegada: formatDate(addDays(today, 3)),
    horarioChegada: '07:00',
    duracao: '8h00min',
    classe: 'leito',
    linha: 'SP-CT-006',
    prefixo: 'CM-6006',
    numeroServico: '2024-0678',
    plataforma: '4',
    localEmbarque: 'Terminal Barra Funda - Plataforma 4',
    tarifa: 219.90,
    pedagio: 20.00,
    taxaEmbarque: 11.00,
    seguro: 7.00,
    outrasTaxas: 4.00,
    desconto: 15.00,
    valorTotal: 246.90,
    andares: 2,
    poltronas: 52,
    poltronasOcupadas: ['3', '8', '13', '19', '25', '30', '37', '42', '47', '50'],
    poltronasBloqueadas: ['1', '2', '3', '4'],
    active: true
  }
];

export const demoReservations: Reservation[] = [
  {
    id: 'r1',
    codigo: 'RES-2024-001',
    localizador: 'ABC123',
    tripId: 't1',
    companyId: 'c1',
    passengers: [{
      id: 'p1',
      nomeCompleto: 'Carlos Eduardo Mendes',
      cpf: '123.456.789-00',
      dataNascimento: '1985-03-15',
      documento: 'RG 12.345.678-9',
      telefone: '(11) 98765-4321',
      email: 'carlos@email.com',
      poltrona: '15',
      localEmbarque: 'Terminal Tietê',
      localDesembarque: 'Terminal de Vitória'
    }],
    status: 'emitida',
    paymentStatus: 'aprovado',
    paymentMethod: 'Pix',
    observacoes: 'Passageiro solicitou embarque prioritário',
    atendenteId: '2',
    valorTotal: 221.40,
    tarifa: 189.90,
    pedagio: 15.00,
    taxaEmbarque: 8.50,
    seguro: 5.00,
    outrasTaxas: 3.00,
    desconto: 0,
    createdAt: '2024-12-01T10:30:00Z',
    updatedAt: '2024-12-01T10:45:00Z',
    history: [
      { date: '2024-12-01T10:30:00Z', action: 'Reserva criada', user: 'Maria Silva' },
      { date: '2024-12-01T10:40:00Z', action: 'Pagamento aprovado', user: 'Sistema' },
      { date: '2024-12-01T10:45:00Z', action: 'Bilhete emitido', user: 'Maria Silva' }
    ]
  },
  {
    id: 'r2',
    codigo: 'RES-2024-002',
    localizador: 'DEF456',
    tripId: 't2',
    companyId: 'c2',
    passengers: [{
      id: 'p2',
      nomeCompleto: 'Ana Paula Rodrigues',
      cpf: '987.654.321-00',
      dataNascimento: '1990-07-22',
      documento: 'RG 98.765.432-1',
      telefone: '(21) 91234-5678',
      email: 'ana@email.com',
      poltrona: '22',
      localEmbarque: 'Rodoviária Novo Rio',
      localDesembarque: 'Terminal Tietê'
    }],
    status: 'paga',
    paymentStatus: 'aprovado',
    paymentMethod: 'Pix',
    observacoes: '',
    atendenteId: '3',
    valorTotal: 296.90,
    tarifa: 259.90,
    pedagio: 22.00,
    taxaEmbarque: 12.00,
    seguro: 8.00,
    outrasTaxas: 5.00,
    desconto: 10.00,
    createdAt: '2024-12-02T14:00:00Z',
    updatedAt: '2024-12-02T14:20:00Z',
    history: [
      { date: '2024-12-02T14:00:00Z', action: 'Reserva criada', user: 'João Santos' },
      { date: '2024-12-02T14:20:00Z', action: 'Pagamento aprovado', user: 'Sistema' }
    ]
  },
  {
    id: 'r3',
    codigo: 'RES-2024-003',
    localizador: 'GHI789',
    tripId: 't3',
    companyId: 'c3',
    passengers: [
      {
        id: 'p3',
        nomeCompleto: 'Roberto Almeida',
        cpf: '456.789.123-00',
        dataNascimento: '1978-11-30',
        documento: 'RG 45.678.912-3',
        telefone: '(31) 99876-5432',
        email: 'roberto@email.com',
        poltrona: '10',
        localEmbarque: 'Terminal BH',
        localDesembarque: 'Rodoviária Novo Rio'
      },
      {
        id: 'p4',
        nomeCompleto: 'Fernanda Costa',
        cpf: '321.654.987-00',
        dataNascimento: '1982-05-18',
        documento: 'RG 32.165.498-7',
        telefone: '(31) 98765-1234',
        email: 'fernanda@email.com',
        poltrona: '11',
        localEmbarque: 'Terminal BH',
        localDesembarque: 'Rodoviária Novo Rio'
      }
    ],
    status: 'pendente',
    paymentStatus: 'aguardando',
    paymentMethod: 'Pix',
    observacoes: 'Dois passageiros - casal',
    atendenteId: '2',
    valorTotal: 304.80,
    tarifa: 259.80,
    pedagio: 20.00,
    taxaEmbarque: 13.00,
    seguro: 8.00,
    outrasTaxas: 4.00,
    desconto: 0,
    createdAt: '2024-12-03T09:00:00Z',
    updatedAt: '2024-12-03T09:00:00Z',
    history: [
      { date: '2024-12-03T09:00:00Z', action: 'Reserva criada', user: 'Maria Silva' }
    ]
  }
];

export function generateReservationCode(): string {
  const year = new Date().getFullYear();
  const num = Math.floor(Math.random() * 9000) + 1000;
  return `RES-${year}-${num}`;
}

export function generateLocator(): string {
  // Gera 12 dígitos numéricos (ex: 010010093017)
  let result = '';
  for (let i = 0; i < 12; i++) {
    result += Math.floor(Math.random() * 10).toString();
  }
  return result;
}

export function generateTicketNumber(): string {
  const num = Math.floor(Math.random() * 900000) + 100000;
  return `BLT-${num}`;
}

import { PixKey } from './types';

export const demoPixKeys: PixKey[] = [
  {
    id: 'pk1',
    agencyName: 'Agência Viagem Certa LTDA',
    keyType: 'cnpj',
    key: '12345678000190',
    holderName: 'Agência Viagem Certa LTDA',
    holderDocument: '12.345.678/0001-90',
    bank: 'Banco do Brasil',
    isDefault: true,
    active: true,
    createdAt: '2024-01-01T00:00:00Z'
  },
  {
    id: 'pk2',
    agencyName: 'Agência Viagem Certa LTDA',
    keyType: 'email',
    key: 'pagamentos@viagemcerta.com.br',
    holderName: 'Agência Viagem Certa LTDA',
    holderDocument: '12.345.678/0001-90',
    bank: 'Nubank',
    isDefault: false,
    active: true,
    createdAt: '2024-01-15T00:00:00Z'
  },
  {
    id: 'pk3',
    agencyName: 'Agência Viagem Certa LTDA',
    keyType: 'phone',
    key: '+5511987654321',
    holderName: 'Maria Silva',
    holderDocument: '123.456.789-00',
    bank: 'Itaú',
    isDefault: false,
    active: true,
    createdAt: '2024-02-01T00:00:00Z'
  }
];
