import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { Search, Users, UserPlus } from 'lucide-react';

export default function Clients() {
  const { reservations } = useData();
  const [filter, setFilter] = useState('');

  // Extract unique passengers from all reservations
  const allPassengers = reservations.flatMap(r => r.passengers.map(p => ({
    ...p,
    reservationCode: r.codigo,
    tripDate: r.createdAt
  })));

  // Deduplicate by CPF
  const uniqueClients = allPassengers.reduce((acc, p) => {
    if (!acc.find(c => c.cpf === p.cpf)) acc.push(p);
    return acc;
  }, [] as (typeof allPassengers[0])[]);

  const filtered = uniqueClients.filter(c =>
    c.nomeCompleto.toLowerCase().includes(filter.toLowerCase()) ||
    c.cpf.includes(filter) ||
    c.email.toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-800">Clientes</h2>
          <p className="text-sm text-gray-500">{uniqueClients.length} clientes cadastrados</p>
        </div>
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input value={filter} onChange={e => setFilter(e.target.value)} placeholder="Buscar por nome, CPF ou e-mail..." className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filtered.map((c, i) => (
          <div key={i} className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm hover:shadow-md transition">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-purple-100 rounded-full flex items-center justify-center">
                <span className="text-purple-700 font-bold text-sm">{c.nomeCompleto.charAt(0)}</span>
              </div>
              <div>
                <h3 className="font-medium text-gray-800">{c.nomeCompleto}</h3>
                <p className="text-xs text-gray-500">CPF: {c.cpf}</p>
              </div>
            </div>
            <div className="mt-3 space-y-1 text-sm text-gray-600">
              {c.telefone && <p>📞 {c.telefone}</p>}
              {c.email && <p>✉️ {c.email}</p>}
              {c.documento && <p>🪪 {c.documento}</p>}
            </div>
            <div className="mt-3 pt-3 border-t border-gray-100">
              <p className="text-xs text-gray-500">Última reserva: {new Date(c.tripDate).toLocaleDateString('pt-BR')}</p>
            </div>
          </div>
        ))}
      </div>

      {filtered.length === 0 && (
        <div className="text-center py-12">
          <Users className="w-12 h-12 text-gray-300 mx-auto mb-3" />
          <p className="text-gray-400">Nenhum cliente encontrado</p>
          <p className="text-sm text-gray-400 mt-1">Os clientes aparecem aqui após a primeira reserva</p>
        </div>
      )}
    </div>
  );
}
