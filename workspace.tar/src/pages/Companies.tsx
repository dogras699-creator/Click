import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { Company } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { Plus, Edit2, Trash2, X, Building2, Upload, Image as ImageIcon } from 'lucide-react';
import { formatPhone, formatCNPJ } from '../utils/masks';

export default function Companies() {
  const { companies, addCompany, updateCompany, deleteCompany, currentUser, addLog } = useData();
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Company | null>(null);
  const [form, setForm] = useState({ razaoSocial: '', nomeFantasia: '', cnpj: '', telefone: '', endereco: '', email: '', logo: '' });

  const isAdmin = currentUser?.role === 'admin';

  const openNew = () => {
    setForm({ razaoSocial: '', nomeFantasia: '', cnpj: '', telefone: '', endereco: '', email: '', logo: '' });
    setEditing(null);
    setShowModal(true);
  };

  const openEdit = (c: Company) => {
    setForm({ razaoSocial: c.razaoSocial, nomeFantasia: c.nomeFantasia, cnpj: c.cnpj, telefone: c.telefone, endereco: c.endereco, email: c.email, logo: c.logo || '' });
    setEditing(c);
    setShowModal(true);
  };

  const handleLogoUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Verificar tipo e tamanho
    if (!file.type.startsWith('image/')) {
      alert('Por favor, selecione um arquivo de imagem');
      return;
    }

    if (file.size > 2 * 1024 * 1024) { // 2MB
      alert('A imagem deve ter no máximo 2MB');
      return;
    }

    // Converter para base64
    const reader = new FileReader();
    reader.onloadend = () => {
      setForm({ ...form, logo: reader.result as string });
    };
    reader.readAsDataURL(file);
  };

  const handleSave = () => {
    if (!form.razaoSocial || !form.nomeFantasia || !form.cnpj) return;
    if (editing) {
      updateCompany({ ...editing, ...form });
      addLog('Empresa atualizada', form.nomeFantasia);
    } else {
      addCompany({ id: uuidv4(), ...form, active: true });
      addLog('Empresa cadastrada', form.nomeFantasia);
    }
    setShowModal(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Deseja realmente excluir esta empresa?')) {
      deleteCompany(id);
      addLog('Empresa excluída', id);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-800">Empresas de Ônibus</h2>
          <p className="text-sm text-gray-500">Gerencie as empresas parceiras</p>
        </div>
        {isAdmin && (
          <button onClick={openNew} className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700 transition flex items-center gap-2">
            <Plus className="w-4 h-4" /> Nova Empresa
          </button>
        )}
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {companies.map(c => (
          <div key={c.id} className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-3">
                {c.logo ? (
                  <img src={c.logo} alt={c.nomeFantasia} className="w-12 h-12 rounded-lg object-cover border border-gray-200" />
                ) : (
                  <div className="w-12 h-12 bg-purple-100 rounded-lg flex items-center justify-center">
                    <Building2 className="w-6 h-6 text-purple-600" />
                  </div>
                )}
                <div>
                  <h3 className="font-semibold text-gray-800">{c.nomeFantasia}</h3>
                  <p className="text-xs text-gray-500">{c.razaoSocial}</p>
                </div>
              </div>
              {isAdmin && (
                <div className="flex gap-1">
                  <button onClick={() => openEdit(c)} className="p-1.5 hover:bg-gray-100 rounded-lg"><Edit2 className="w-3.5 h-3.5 text-gray-500" /></button>
                  <button onClick={() => handleDelete(c.id)} className="p-1.5 hover:bg-red-50 rounded-lg"><Trash2 className="w-3.5 h-3.5 text-red-500" /></button>
                </div>
              )}
            </div>
            <div className="mt-4 space-y-1.5 text-sm">
              <p className="text-gray-600"><span className="text-gray-400">CNPJ:</span> {c.cnpj}</p>
              <p className="text-gray-600"><span className="text-gray-400">Tel:</span> {c.telefone}</p>
              <p className="text-gray-600"><span className="text-gray-400">Email:</span> {c.email}</p>
              <p className="text-gray-600 truncate"><span className="text-gray-400">End:</span> {c.endereco}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-lg font-semibold">{editing ? 'Editar Empresa' : 'Nova Empresa'}</h3>
              <button onClick={() => setShowModal(false)}><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              {/* Upload de Logo */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Logo da Empresa</label>
                <div className="flex items-start gap-4">
                  {/* Preview do logo */}
                  <div className="flex-shrink-0">
                    {form.logo ? (
                      <div className="relative group">
                        <img src={form.logo} alt="Logo" className="w-24 h-24 rounded-lg object-cover border-2 border-gray-200" />
                        <button
                          type="button"
                          onClick={() => setForm({ ...form, logo: '' })}
                          className="absolute -top-2 -right-2 w-6 h-6 bg-red-500 text-white rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      </div>
                    ) : (
                      <div className="w-24 h-24 bg-gray-100 rounded-lg border-2 border-dashed border-gray-300 flex items-center justify-center">
                        <ImageIcon className="w-8 h-8 text-gray-400" />
                      </div>
                    )}
                  </div>
                  
                  {/* Área de upload */}
                  <div className="flex-1">
                    <label className="flex flex-col items-center justify-center w-full h-24 border-2 border-gray-300 border-dashed rounded-lg cursor-pointer bg-gray-50 hover:bg-gray-100 transition-colors">
                      <div className="flex flex-col items-center justify-center pt-5 pb-6">
                        <Upload className="w-6 h-6 text-gray-500 mb-2" />
                        <p className="text-xs text-gray-500">
                          <span className="font-semibold text-purple-600">Clique para enviar</span>
                        </p>
                        <p className="text-xs text-gray-400 mt-1">PNG, JPG até 2MB</p>
                      </div>
                      <input
                        type="file"
                        className="hidden"
                        accept="image/*"
                        onChange={handleLogoUpload}
                      />
                    </label>
                    {form.logo && (
                      <p className="text-xs text-green-600 mt-2 flex items-center gap-1">
                        <span>✓</span> Logo carregado com sucesso
                      </p>
                    )}
                  </div>
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Razão Social *</label>
                <input value={form.razaoSocial} onChange={e => setForm({...form, razaoSocial: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nome Fantasia *</label>
                <input value={form.nomeFantasia} onChange={e => setForm({...form, nomeFantasia: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">CNPJ *</label>
                  <input 
                    value={form.cnpj} 
                    onChange={e => setForm({...form, cnpj: formatCNPJ(e.target.value)})} 
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" 
                    placeholder="00.000.000/0001-00"
                    maxLength={18}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Telefone</label>
                  <input 
                    value={form.telefone} 
                    onChange={e => setForm({...form, telefone: formatPhone(e.target.value)})} 
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" 
                    placeholder="(11) 99999-9999"
                    maxLength={15}
                  />
                </div>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">E-mail</label>
                <input type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Endereço</label>
                <input value={form.endereco} onChange={e => setForm({...form, endereco: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
              </div>
            </div>
            <div className="p-6 border-t border-gray-100 flex justify-end gap-3">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg text-sm font-medium">Cancelar</button>
              <button onClick={handleSave} className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700">Salvar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
