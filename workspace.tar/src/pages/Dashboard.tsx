import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../contexts/DataContext';
import {
  Ticket, Clock, CreditCard, DollarSign, AlertTriangle,
  TrendingUp, Bus, Users, FileText, Plus, BarChart3, ArrowRight
} from 'lucide-react';

export default function Dashboard() {
  const { reservations, trips, companies, currentUser, settings } = useData();
  const navigate = useNavigate();

  const totalEmitidas = reservations.filter(r => r.status === 'emitida').length;
  const pendentes = reservations.filter(r => r.status === 'pendente').length;
  const pagas = reservations.filter(r => r.paymentStatus === 'aprovado').length;
  const faturamento = reservations.filter(r => r.paymentStatus === 'aprovado').reduce((sum, r) => sum + r.valorTotal, 0);
  const canceladas = reservations.filter(r => r.status === 'cancelada').length;

  const upcomingTrips = trips.filter(t => {
    const tripDate = new Date(t.dataSaida + 'T' + t.horarioSaida);
    return tripDate > new Date();
  }).slice(0, 5);

  const shortcuts = [
    { label: 'Nova Emissão', icon: Plus, path: '/emissao', color: 'bg-purple-600' },
    { label: 'Viagens', icon: Bus, path: '/viagens', color: 'bg-blue-600' },
    { label: 'Reservas', icon: FileText, path: '/reservas', color: 'bg-green-600' },
    { label: 'Pagamentos', icon: CreditCard, path: '/pagamentos', color: 'bg-orange-600' },
    { label: 'Clientes', icon: Users, path: '/clientes', color: 'bg-pink-600' },
    { label: 'Relatórios', icon: BarChart3, path: '/relatorios', color: 'bg-indigo-600' },
  ];

  const stats = [
    { label: 'Passagens Emitidas', value: totalEmitidas, icon: Ticket, color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'Reservas Pendentes', value: pendentes, icon: Clock, color: 'text-orange-600', bg: 'bg-orange-50' },
    { label: 'Pagamentos Aprovados', value: pagas, icon: CreditCard, color: 'text-green-600', bg: 'bg-green-50' },
    { label: 'Faturamento', value: `R$ ${faturamento.toFixed(2)}`, icon: DollarSign, color: 'text-emerald-600', bg: 'bg-emerald-50' },
    { label: 'Viagens Ativas', value: trips.filter(t => t.active).length, icon: Bus, color: 'text-blue-600', bg: 'bg-blue-50' },
    { label: 'Canceladas', value: canceladas, icon: AlertTriangle, color: 'text-red-600', bg: 'bg-red-50' },
  ];

  return (
    <div className="space-y-6">
      {/* Welcome */}
      <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-2xl p-6 text-white">
        <h2 className="text-xl font-bold">Bom dia, {currentUser?.name}!</h2>
        <p className="text-purple-100 mt-1">Bem-vindo ao {settings.nome}</p>
        <div className="mt-4 flex flex-wrap gap-3">
          <button onClick={() => navigate('/emissao')} className="px-4 py-2 bg-white text-purple-700 rounded-lg font-medium text-sm hover:bg-purple-50 transition flex items-center gap-2">
            <Plus className="w-4 h-4" /> Nova Emissão
          </button>
          <button onClick={() => navigate('/reservas')} className="px-4 py-2 bg-white/20 text-white rounded-lg font-medium text-sm hover:bg-white/30 transition">
            Ver Reservas
          </button>
        </div>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
        {stats.map((stat, i) => {
          const Icon = stat.icon;
          return (
            <div key={i} className="bg-white rounded-xl p-4 shadow-sm border border-gray-100">
              <div className={`w-10 h-10 ${stat.bg} rounded-lg flex items-center justify-center mb-3`}>
                <Icon className={`w-5 h-5 ${stat.color}`} />
              </div>
              <p className="text-2xl font-bold text-gray-800">{stat.value}</p>
              <p className="text-xs text-gray-500 mt-1">{stat.label}</p>
            </div>
          );
        })}
      </div>

      {/* Shortcuts */}
      <div>
        <h3 className="text-lg font-semibold text-gray-800 mb-3">Atalhos Rápidos</h3>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {shortcuts.map((s, i) => {
            const Icon = s.icon;
            return (
              <button key={i} onClick={() => navigate(s.path)} className="flex flex-col items-center gap-2 p-4 bg-white rounded-xl border border-gray-100 hover:shadow-md hover:border-purple-200 transition-all group">
                <div className={`w-10 h-10 ${s.color} rounded-lg flex items-center justify-center text-white group-hover:scale-110 transition-transform`}>
                  <Icon className="w-5 h-5" />
                </div>
                <span className="text-xs font-medium text-gray-700">{s.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Upcoming trips */}
      <div className="bg-white rounded-xl shadow-sm border border-gray-100 overflow-hidden">
        <div className="p-4 border-b border-gray-100 flex items-center justify-between">
          <h3 className="font-semibold text-gray-800 flex items-center gap-2">
            <Clock className="w-5 h-5 text-purple-600" /> Próximos Embarques
          </h3>
          <button onClick={() => navigate('/reservas')} className="text-sm text-purple-600 hover:text-purple-700 font-medium flex items-center gap-1">
            Ver todos <ArrowRight className="w-3 h-3" />
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Passageiro</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Destino</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Data/Hora</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Poltrona</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {reservations.filter(r => r.status !== 'cancelada').slice(0, 5).map(r => {
                const trip = trips.find(t => t.id === r.tripId);
                return (
                  <tr key={r.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3 text-sm text-gray-800">{r.passengers[0]?.nomeCompleto}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{trip?.destino || '-'}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{trip ? `${trip.dataSaida} ${trip.horarioSaida}` : '-'}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{r.passengers[0]?.poltrona || '-'}</td>
                    <td className="px-4 py-3">
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        r.status === 'emitida' ? 'bg-green-100 text-green-700' :
                        r.status === 'paga' ? 'bg-blue-100 text-blue-700' :
                        r.status === 'pendente' ? 'bg-yellow-100 text-yellow-700' :
                        'bg-red-100 text-red-700'
                      }`}>
                        {r.status.charAt(0).toUpperCase() + r.status.slice(1)}
                      </span>
                    </td>
                  </tr>
                );
              })}
              {reservations.length === 0 && (
                <tr><td colSpan={5} className="px-4 py-8 text-center text-gray-400">Nenhuma reserva encontrada</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Companies overview */}
      <div className="grid md:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <TrendingUp className="w-5 h-5 text-purple-600" /> Empresas Cadastradas
          </h3>
          <div className="space-y-2">
            {companies.filter(c => c.active).map(c => (
              <div key={c.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-lg">
                <span className="text-sm font-medium text-gray-700">{c.nomeFantasia}</span>
                <span className="text-xs text-gray-500">{trips.filter(t => t.companyId === c.id).length} viagens</span>
              </div>
            ))}
          </div>
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-4">
          <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2">
            <BarChart3 className="w-5 h-5 text-purple-600" /> Resumo do Dia
          </h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Reservas hoje</span>
              <span className="text-sm font-bold text-gray-800">{reservations.length}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Faturamento</span>
              <span className="text-sm font-bold text-green-600">R$ {faturamento.toFixed(2)}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Comissão estimada</span>
              <span className="text-sm font-bold text-purple-600">R$ {(faturamento * 0.1).toFixed(2)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
