import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../contexts/DataContext';
import { Trip, Passenger, PixCharge } from '../types';
import { generateReservationCode, generateLocator } from '../demoData';
import { generatePixCode, generateQRCodeBase64 } from '../utils/pix';
import { formatPhone, formatCPF } from '../utils/masks';
import { Search, Bus, Armchair, User, FileText, CreditCard, ArrowLeft, ArrowRight, MapPin, Clock, QrCode, Copy, Check, Plus } from 'lucide-react';

export default function Emissao() {
  const navigate = useNavigate();
  const { trips, companies, currentUser, addReservation, addLog, pixKeys, settings, addPixCharge, updatePixCharge, updateReservation, reservations } = useData();
  const [step, setStep] = useState(1);
  const [searchForm, setSearchForm] = useState({ 
    origem: '', 
    destino: '', 
    dataIda: new Date().toISOString().split('T')[0], 
    dataVolta: '', 
    tipoViagem: 'ida' as 'ida' | 'ida-volta',
    classe: '', 
    passageiros: 1 
  });
  const [results, setResults] = useState<Trip[]>([]);
  const [returnResults, setReturnResults] = useState<Trip[]>([]);
  const [selectedTrip, setSelectedTrip] = useState<Trip | null>(null);
  const [selectedReturnTrip, setSelectedReturnTrip] = useState<Trip | null>(null);
  const [selectedSeats, setSelectedSeats] = useState<string[]>([]);
  const [passengers, setPassengers] = useState<Passenger[]>([]);
  const [observacoes, setObservacoes] = useState('');
  const [searched, setSearched] = useState(false);
  const [pixCharge, setPixCharge] = useState<PixCharge | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);

  const handleSearch = () => {
    setSearched(true);
    let filtered = trips.filter(t => t.active);
    if (searchForm.origem) filtered = filtered.filter(t => t.origem.toLowerCase().includes(searchForm.origem.toLowerCase()));
    if (searchForm.destino) filtered = filtered.filter(t => t.destino.toLowerCase().includes(searchForm.destino.toLowerCase()));
    if (searchForm.dataIda) filtered = filtered.filter(t => t.dataSaida === searchForm.dataIda);
    if (searchForm.classe) filtered = filtered.filter(t => t.classe === searchForm.classe);
    setResults(filtered);
    
    // Buscar volta se for ida e volta
    if (searchForm.tipoViagem === 'ida-volta' && searchForm.dataVolta) {
      let returnFiltered = trips.filter(t => t.active);
      if (searchForm.destino) returnFiltered = returnFiltered.filter(t => t.origem.toLowerCase().includes(searchForm.destino.toLowerCase()));
      if (searchForm.origem) returnFiltered = returnFiltered.filter(t => t.destino.toLowerCase().includes(searchForm.origem.toLowerCase()));
      if (searchForm.dataVolta) returnFiltered = returnFiltered.filter(t => t.dataSaida === searchForm.dataVolta);
      if (searchForm.classe) returnFiltered = returnFiltered.filter(t => t.classe === searchForm.classe);
      setReturnResults(returnFiltered);
    } else {
      setReturnResults([]);
    }
  };

  const selectTrip = (trip: Trip) => {
    setSelectedTrip(trip);
    setSelectedSeats([]);
    setStep(2);
  };

  const toggleSeat = (seat: string) => {
    if (selectedTrip?.poltronasOcupadas?.includes(seat) || selectedTrip?.poltronasBloqueadas?.includes(seat)) return;
    if (selectedSeats.includes(seat)) {
      setSelectedSeats(selectedSeats.filter(s => s !== seat));
    } else if (selectedSeats.length < searchForm.passageiros) {
      setSelectedSeats([...selectedSeats, seat]);
    }
  };

  const confirmSeats = () => {
    if (selectedSeats.length !== searchForm.passageiros) return;
    const initialPassengers: Passenger[] = selectedSeats.map(seat => ({
      id: Date.now().toString() + seat, nomeCompleto: '', cpf: '', dataNascimento: '',
      documento: '', telefone: '', email: '', poltrona: seat, localEmbarque: selectedTrip?.localEmbarque || '', localDesembarque: selectedTrip?.destino || ''
    }));
    setPassengers(initialPassengers);
    setStep(3);
  };

  const updatePassenger = (index: number, field: keyof Passenger, value: string) => {
    const updated = [...passengers];
    updated[index] = { ...updated[index], [field]: value };
    setPassengers(updated);
  };

  const validatePassengers = () => {
    return passengers.every(p => p.nomeCompleto && p.cpf);
  };

  // Gerar código único do bilhete
  const generateTicketCode = (reservationId: string): string => {
    const timestamp = Date.now().toString(36).toUpperCase();
    const random = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `BPE-${timestamp}-${random}`;
  };

  const confirmReservation = async () => {
    if (!selectedTrip || !currentUser) return;
    const reservation: any = {
      id: Date.now().toString(),
      codigo: generateReservationCode(),
      localizador: generateLocator(),
      tripId: selectedTrip.id,
      companyId: selectedTrip.companyId,
      passengers,
      status: 'pendente' as const,
      paymentStatus: 'aguardando' as const,
      paymentMethod: 'Pix',
      observacoes,
      atendenteId: currentUser.id,
      valorTotal: selectedTrip.valorTotal * passengers.length,
      tarifa: selectedTrip.tarifa * passengers.length,
      pedagio: selectedTrip.pedagio * passengers.length,
      taxaEmbarque: selectedTrip.taxaEmbarque * passengers.length,
      seguro: selectedTrip.seguro * passengers.length,
      outrasTaxas: selectedTrip.outrasTaxas * passengers.length,
      desconto: selectedTrip.desconto * passengers.length,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      history: [{ date: new Date().toISOString(), action: 'Reserva criada', user: currentUser.name }]
    };
    // Gerar código único do bilhete automaticamente
    const ticketCode = generateTicketCode(reservation.id);
    reservation.ticketCode = ticketCode;
    
    addReservation(reservation);
    addLog('Nova reserva criada', `${reservation.codigo} - ${passengers[0]?.nomeCompleto}`);
    addLog('Código do bilhete gerado', ticketCode);
    
    // Gerar Pix automaticamente
    const defaultKey = pixKeys.find(k => k.isDefault && k.active) || pixKeys[0];
    
    if (defaultKey) {
      const txid = `RES${Date.now().toString(36).toUpperCase()}`;
      const pixCode = generatePixCode({
        pixKey: defaultKey.key,
        merchantName: defaultKey.agencyName || settings.razaoSocial,
        merchantCity: 'SAO PAULO',
        amount: reservation.valorTotal,
        txid
      });
      
      const qrCodeBase64 = await generateQRCodeBase64(pixCode);
      
      const charge: PixCharge = {
        id: Date.now().toString() + '_pix',
        reservationId: reservation.id,
        pixKeyId: defaultKey.id,
        amount: reservation.valorTotal,
        description: `Pagamento reserva ${reservation.codigo} - ${passengers[0]?.nomeCompleto}`,
        pixCode,
        qrCodeBase64,
        status: 'pending',
        createdAt: new Date().toISOString(),
        expiresAt: new Date(Date.now() + 3600000).toISOString(),
        attendantId: currentUser.id,
        passengerName: passengers[0]?.nomeCompleto || '',
        reservationCode: reservation.codigo
      };
      
      addPixCharge(charge);
      setPixCharge(charge);
    }
    
    setStep(5);
  };

  const resetFlow = () => {
    setStep(1); setResults([]); setSelectedTrip(null); setSelectedSeats([]);
    setPassengers([]); setObservacoes(''); setSearched(false);
  };

  const steps = [
    { num: 1, label: 'Pesquisar', icon: Search },
    { num: 2, label: 'Poltronas', icon: Armchair },
    { num: 3, label: 'Passageiros', icon: User },
    { num: 4, label: 'Revisar', icon: FileText },
    { num: 5, label: 'Pagamento', icon: CreditCard },
    { num: 6, label: 'Concluído', icon: Check },
  ];

  return (
    <div className="space-y-6">
      {/* Steps indicator */}
      <div className="flex items-center justify-center gap-2 flex-wrap">
        {steps.map((s, i) => {
          const Icon = s.icon;
          const isActive = step === s.num;
          const isDone = step > s.num;
          return (
            <React.Fragment key={s.num}>
              <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full text-sm font-medium transition ${isActive ? 'bg-purple-600 text-white' : isDone ? 'bg-purple-100 text-purple-700' : 'bg-gray-100 text-gray-400'}`}>
                <Icon className="w-4 h-4" />
                <span className="hidden sm:inline">{s.label}</span>
                <span className="sm:hidden">{s.num}</span>
              </div>
              {i < steps.length - 1 && <div className={`w-8 h-0.5 ${step > s.num ? 'bg-purple-400' : 'bg-gray-200'}`} />}
            </React.Fragment>
          );
        })}
      </div>

      {/* Step 1: Search */}
      {step === 1 && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Pesquisar Viagem</h3>
            
            {/* Tipo de viagem */}
            <div className="mb-4">
              <label className="block text-sm font-medium text-gray-700 mb-2">Tipo de Viagem</label>
              <div className="flex gap-4">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="radio" 
                    name="tipoViagem" 
                    value="ida" 
                    checked={searchForm.tipoViagem === 'ida'}
                    onChange={e => setSearchForm({...searchForm, tipoViagem: e.target.value as 'ida' | 'ida-volta'})}
                    className="w-4 h-4 text-purple-600"
                  />
                  <span className="text-sm text-gray-700">Somente Ida</span>
                </label>
                <label className="flex items-center gap-2 cursor-pointer">
                  <input 
                    type="radio" 
                    name="tipoViagem" 
                    value="ida-volta" 
                    checked={searchForm.tipoViagem === 'ida-volta'}
                    onChange={e => setSearchForm({...searchForm, tipoViagem: e.target.value as 'ida' | 'ida-volta'})}
                    className="w-4 h-4 text-purple-600"
                  />
                  <span className="text-sm text-gray-700">Ida e Volta</span>
                </label>
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Origem</label>
                <input value={searchForm.origem} onChange={e => setSearchForm({...searchForm, origem: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" placeholder="Cidade de origem" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Destino</label>
                <input value={searchForm.destino} onChange={e => setSearchForm({...searchForm, destino: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" placeholder="Cidade de destino" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Data de Ida</label>
                <input type="date" value={searchForm.dataIda} onChange={e => setSearchForm({...searchForm, dataIda: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
              </div>
              {searchForm.tipoViagem === 'ida-volta' && (
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Data de Volta</label>
                  <input type="date" value={searchForm.dataVolta} onChange={e => setSearchForm({...searchForm, dataVolta: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" min={searchForm.dataIda} />
                </div>
              )}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Classe</label>
                <select value={searchForm.classe} onChange={e => setSearchForm({...searchForm, classe: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none">
                  <option value="">Todas</option>
                  <option value="convencional">Convencional</option>
                  <option value="executivo">Executivo</option>
                  <option value="semi-leito">Semi-Leito</option>
                  <option value="leito">Leito</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Passageiros</label>
                <input type="number" min={1} max={10} value={searchForm.passageiros} onChange={e => setSearchForm({...searchForm, passageiros: parseInt(e.target.value) || 1})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
              </div>
            </div>
            <button onClick={handleSearch} className="mt-4 px-6 py-2.5 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 transition flex items-center gap-2">
              <Search className="w-4 h-4" /> Pesquisar Viagens
            </button>
          </div>

          {searched && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-gray-800">{results.length} viagem(ns) encontrada(s)</h3>
              {results.map(trip => {
                const company = companies.find(c => c.id === trip.companyId);
                const disponivel = trip.poltronas - (trip.poltronasOcupadas?.length || 0) - (trip.poltronasBloqueadas?.length || 0);
                return (
                  <div key={trip.id} className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition">
                    <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-2">
                          {company?.logo ? (
                            <img src={company.logo} alt={company.nomeFantasia} className="w-6 h-6 rounded object-cover border border-gray-200" />
                          ) : (
                            <Bus className="w-4 h-4 text-purple-600" />
                          )}
                          <span className="font-semibold text-gray-800">{company?.nomeFantasia}</span>
                          <span className="px-2 py-0.5 bg-purple-100 text-purple-700 rounded-full text-xs capitalize">{trip.classe}</span>
                        </div>
                        <div className="flex items-center gap-4 text-sm text-gray-600">
                          <div className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{trip.origem}</div>
                          <span className="text-gray-300">→</span>
                          <div className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{trip.destino}</div>
                        </div>
                        <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                          <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{trip.horarioSaida} - {trip.horarioChegada}</span>
                          <span>Duração: {trip.duracao}</span>
                          <span>Plataforma: {trip.plataforma}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-4">
                        <div className="text-right">
                          <p className="text-2xl font-bold text-purple-700">R$ {trip.valorTotal.toFixed(2)}</p>
                          <p className="text-xs text-gray-500">{disponivel} poltronas disponíveis</p>
                        </div>
                        <button onClick={() => selectTrip(trip)} disabled={disponivel < searchForm.passageiros} className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition">
                          Selecionar
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
              {results.length === 0 && (
                <div className="text-center py-12 text-gray-400">
                  <Bus className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>Nenhuma viagem encontrada para os filtros selecionados.</p>
                </div>
              )}

              {/* Resultados de Volta */}
              {searchForm.tipoViagem === 'ida-volta' && returnResults.length > 0 && (
                <div className="mt-8">
                  <h3 className="text-lg font-semibold text-gray-800 mb-4">Viagens de Volta - {returnResults.length} encontrada(s)</h3>
                  {returnResults.map(trip => {
                    const company = companies.find(c => c.id === trip.companyId);
                    const disponivel = trip.poltronas - (trip.poltronasOcupadas?.length || 0) - (trip.poltronasBloqueadas?.length || 0);
                    return (
                      <div key={trip.id} className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition">
                        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                          <div className="flex-1">
                            <div className="flex items-center gap-2 mb-2">
                              {company?.logo ? (
                                <img src={company.logo} alt={company.nomeFantasia} className="w-6 h-6 rounded object-cover border border-gray-200" />
                              ) : (
                                <Bus className="w-4 h-4 text-blue-600" />
                              )}
                              <span className="font-semibold text-gray-800">{company?.nomeFantasia}</span>
                              <span className="px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full text-xs capitalize">{trip.classe}</span>
                              <span className="px-2 py-0.5 bg-orange-100 text-orange-700 rounded-full text-xs">VOLTA</span>
                            </div>
                            <div className="flex items-center gap-4 text-sm text-gray-600">
                              <div className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{trip.origem}</div>
                              <span className="text-gray-300">→</span>
                              <div className="flex items-center gap-1"><MapPin className="w-3.5 h-3.5" />{trip.destino}</div>
                            </div>
                            <div className="flex items-center gap-4 mt-2 text-sm text-gray-500">
                              <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" />{trip.horarioSaida} - {trip.horarioChegada}</span>
                              <span>Duração: {trip.duracao}</span>
                              <span>Plataforma: {trip.plataforma}</span>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <div className="text-right">
                              <p className="text-2xl font-bold text-blue-700">R$ {trip.valorTotal.toFixed(2)}</p>
                              <p className="text-xs text-gray-500">{disponivel} poltronas disponíveis</p>
                            </div>
                            <button onClick={() => { setSelectedReturnTrip(trip); }} disabled={disponivel < searchForm.passageiros} className="px-4 py-2 bg-blue-600 text-white rounded-lg text-sm font-medium hover:bg-blue-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition">
                              Selecionar Volta
                            </button>
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>
      )}

      {/* Step 2: Seat Selection */}
      {step === 2 && selectedTrip && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold">Seleção de Poltronas</h3>
                  <p className="text-sm text-purple-100 mt-1">{selectedTrip.nome}</p>
                  <p className="text-xs text-purple-200 mt-1">{selectedTrip.origem} → {selectedTrip.destino} | {selectedTrip.dataSaida} às {selectedTrip.horarioSaida}</p>
                </div>
                <button onClick={() => setStep(1)} className="text-sm text-white hover:bg-white/10 px-3 py-1.5 rounded-lg flex items-center gap-1 transition">
                  <ArrowLeft className="w-4 h-4" /> Voltar
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="grid lg:grid-cols-3 gap-6">
                {/* Bus Layout - 2/3 */}
                <div className="lg:col-span-2">
                  {/* Legend */}
                  <div className="flex flex-wrap gap-3 mb-4 p-3 bg-gray-50 rounded-lg border border-gray-200">
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 rounded-md bg-white border-2 border-emerald-400 shadow-sm"></div>
                      <span className="text-xs text-gray-700 font-medium">Livre</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 rounded-md bg-purple-600 border-2 border-purple-700 shadow-sm"></div>
                      <span className="text-xs text-gray-700 font-medium">Selecionada</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 rounded-md bg-red-400 border-2 border-red-500 shadow-sm"></div>
                      <span className="text-xs text-gray-700 font-medium">Ocupada</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-5 h-5 rounded-md bg-gray-300 border-2 border-gray-400 shadow-sm"></div>
                      <span className="text-xs text-gray-700 font-medium">Bloqueada</span>
                    </div>
                  </div>

                  {/* Bus Visual */}
                  <div className="flex flex-col lg:flex-row gap-6 justify-center">
                    {[...Array(selectedTrip.andares)].map((_, floor) => {
                      const poltronasPorAndar = selectedTrip.andares > 1 ? Math.ceil(selectedTrip.poltronas / 2) : selectedTrip.poltronas;
                      const linhas = Math.ceil(poltronasPorAndar / 4);
                      
                      return (
                        <div key={floor} className="space-y-3">
                          {selectedTrip.andares > 1 && (
                            <h4 className="text-center font-bold text-gray-700 text-sm uppercase tracking-wide">
                              {floor + 1}º Andar
                            </h4>
                          )}
                          
                          {/* Bus Container */}
                          <div className="relative mx-auto" style={{ width: '240px' }}>
                            {/* Bus body */}
                            <div className="bg-gradient-to-b from-slate-100 to-slate-200 rounded-t-[40px] rounded-b-2xl border-2 border-slate-400 shadow-lg p-3 pb-4">
                              
                              {/* Front of bus (driver area) */}
                              <div className="bg-slate-300 rounded-t-[35px] rounded-b-lg p-2 mb-3 border-b-2 border-slate-400">
                                <div className="flex items-center justify-between">
                                  <div className="flex items-center gap-1">
                                    <div className="w-3 h-3 bg-yellow-400 rounded-full border border-yellow-600"></div>
                                    <div className="w-3 h-3 bg-yellow-400 rounded-full border border-yellow-600"></div>
                                  </div>
                                  <div className="flex items-center gap-2">
                                    <div className="w-6 h-6 bg-slate-700 rounded-full flex items-center justify-center border-2 border-slate-800">
                                      <span className="text-[8px] text-white font-bold">⚙</span>
                                    </div>
                                    <span className="text-[10px] font-bold text-slate-700 uppercase">Frente</span>
                                  </div>
                                </div>
                              </div>

                              {/* Seats grid - 2 + aisle + 2 */}
                              <div className="space-y-1.5">
                                {Array.from({ length: linhas }, (_, rowIdx) => {
                                  const rowSeats: string[] = [];
                                  for (let col = 0; col < 4; col++) {
                                    const seatNumber = floor === 0 
                                      ? (rowIdx * 4 + col + 1).toString()
                                      : (poltronasPorAndar + rowIdx * 4 + col + 1).toString();
                                    if (parseInt(seatNumber) <= selectedTrip.poltronas) {
                                      rowSeats.push(seatNumber);
                                    }
                                  }
                                  if (rowSeats.length === 0) return null;
                                  
                                  return (
                                    <div key={rowIdx} className="grid grid-cols-[1fr_1fr_20px_1fr_1fr] gap-1 items-center">
                                      {/* Left side - 2 seats */}
                                      {rowSeats.slice(0, 2).map((seatNum) => {
                                        const isOccupied = selectedTrip.poltronasOcupadas?.includes(seatNum);
                                        const isBlocked = selectedTrip.poltronasBloqueadas?.includes(seatNum);
                                        const isSelected = selectedSeats.includes(seatNum);
                                        return (
                                          <button
                                            key={seatNum}
                                            onClick={() => toggleSeat(seatNum)}
                                            disabled={isOccupied || isBlocked}
                                            title={`Poltrona ${seatNum}${isOccupied ? ' - Ocupada' : isBlocked ? ' - Bloqueada' : isSelected ? ' - Selecionada' : ' - Livre'}`}
                                            className={`relative h-11 rounded-t-lg rounded-b-md text-[11px] font-bold flex flex-col items-center justify-center transition-all ${
                                              isSelected 
                                                ? 'bg-gradient-to-b from-purple-500 to-purple-700 text-white border-2 border-purple-800 shadow-md scale-105' 
                                                : isOccupied 
                                                ? 'bg-gradient-to-b from-red-300 to-red-400 text-red-900 border-2 border-red-500 cursor-not-allowed opacity-70' 
                                                : isBlocked 
                                                ? 'bg-gradient-to-b from-gray-300 to-gray-400 text-gray-600 border-2 border-gray-500 cursor-not-allowed opacity-60' 
                                                : 'bg-gradient-to-b from-white to-emerald-50 text-emerald-700 border-2 border-emerald-400 hover:from-emerald-100 hover:to-emerald-200 hover:scale-105 hover:shadow-md cursor-pointer'
                                            }`}
                                          >
                                            {isSelected && (
                                              <div className="absolute -top-1 -right-1 w-4 h-4 bg-white rounded-full flex items-center justify-center shadow">
                                                <span className="text-purple-600 text-[10px]">✓</span>
                                              </div>
                                            )}
                                            <span className="leading-none">{seatNum}</span>
                                          </button>
                                        );
                                      })}
                                      
                                      {/* Aisle (corredor) */}
                                      <div className="flex items-center justify-center">
                                        <div className="w-full h-1 bg-slate-300 rounded"></div>
                                      </div>
                                      
                                      {/* Right side - 2 seats */}
                                      {rowSeats.slice(2, 4).map((seatNum) => {
                                        const isOccupied = selectedTrip.poltronasOcupadas?.includes(seatNum);
                                        const isBlocked = selectedTrip.poltronasBloqueadas?.includes(seatNum);
                                        const isSelected = selectedSeats.includes(seatNum);
                                        return (
                                          <button
                                            key={seatNum}
                                            onClick={() => toggleSeat(seatNum)}
                                            disabled={isOccupied || isBlocked}
                                            title={`Poltrona ${seatNum}${isOccupied ? ' - Ocupada' : isBlocked ? ' - Bloqueada' : isSelected ? ' - Selecionada' : ' - Livre'}`}
                                            className={`relative h-11 rounded-t-lg rounded-b-md text-[11px] font-bold flex flex-col items-center justify-center transition-all ${
                                              isSelected 
                                                ? 'bg-gradient-to-b from-purple-500 to-purple-700 text-white border-2 border-purple-800 shadow-md scale-105' 
                                                : isOccupied 
                                                ? 'bg-gradient-to-b from-red-300 to-red-400 text-red-900 border-2 border-red-500 cursor-not-allowed opacity-70' 
                                                : isBlocked 
                                                ? 'bg-gradient-to-b from-gray-300 to-gray-400 text-gray-600 border-2 border-gray-500 cursor-not-allowed opacity-60' 
                                                : 'bg-gradient-to-b from-white to-emerald-50 text-emerald-700 border-2 border-emerald-400 hover:from-emerald-100 hover:to-emerald-200 hover:scale-105 hover:shadow-md cursor-pointer'
                                            }`}
                                          >
                                            {isSelected && (
                                              <div className="absolute -top-1 -right-1 w-4 h-4 bg-white rounded-full flex items-center justify-center shadow">
                                                <span className="text-purple-600 text-[10px]">✓</span>
                                              </div>
                                            )}
                                            <span className="leading-none">{seatNum}</span>
                                          </button>
                                        );
                                      })}
                                    </div>
                                  );
                                })}
                              </div>

                              {/* Back of bus */}
                              <div className="mt-3 pt-2 border-t-2 border-slate-300">
                                <div className="flex items-center justify-center gap-1">
                                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                                  <span className="text-[9px] text-slate-600 font-bold uppercase tracking-wider">Fundo</span>
                                  <div className="w-2 h-2 bg-red-500 rounded-full"></div>
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Sidebar - 1/3 */}
                <div className="lg:col-span-1">
                  <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl border border-purple-200 p-5 sticky top-4">
                    <h4 className="font-bold text-gray-800 mb-4 flex items-center gap-2">
                      <Armchair className="w-5 h-5 text-purple-600" />
                      Resumo da Seleção
                    </h4>

                    {/* Trip info */}
                    <div className="bg-white rounded-lg p-3 mb-4 border border-purple-100">
                      <p className="text-xs text-gray-500 uppercase font-bold mb-1">Viagem</p>
                      <p className="text-sm font-semibold text-gray-800">{selectedTrip.origem.split(' - ')[0]}</p>
                      <p className="text-xs text-gray-500">↓</p>
                      <p className="text-sm font-semibold text-gray-800">{selectedTrip.destino.split(' - ')[0]}</p>
                      <div className="mt-2 pt-2 border-t border-gray-100 flex justify-between text-xs">
                        <span className="text-gray-500">Data:</span>
                        <span className="font-medium text-gray-700">{selectedTrip.dataSaida}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-500">Horário:</span>
                        <span className="font-medium text-gray-700">{selectedTrip.horarioSaida}</span>
                      </div>
                      <div className="flex justify-between text-xs">
                        <span className="text-gray-500">Classe:</span>
                        <span className="font-medium text-gray-700 capitalize">{selectedTrip.classe}</span>
                      </div>
                    </div>

                    {/* Selected seats */}
                    <div className="mb-4">
                      <p className="text-xs text-gray-500 uppercase font-bold mb-2">Poltronas Selecionadas</p>
                      {selectedSeats.length === 0 ? (
                        <p className="text-xs text-gray-400 italic">Nenhuma poltrona selecionada</p>
                      ) : (
                        <div className="flex flex-wrap gap-2">
                          {selectedSeats.map((seat, idx) => (
                            <div key={seat} className="flex items-center gap-1 bg-purple-600 text-white px-2 py-1 rounded-md text-xs font-bold">
                              <span>#{idx + 1}</span>
                              <span className="bg-white text-purple-600 rounded px-1.5 py-0.5">{seat}</span>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>

                    {/* Counter */}
                    <div className="bg-white rounded-lg p-3 mb-4 border border-purple-100">
                      <div className="flex items-center justify-between">
                        <span className="text-xs text-gray-600">Selecionadas:</span>
                        <span className="text-lg font-bold text-purple-700">{selectedSeats.length}/{searchForm.passageiros}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2 mt-2 overflow-hidden">
                        <div 
                          className="bg-gradient-to-r from-purple-500 to-indigo-600 h-2 rounded-full transition-all duration-300"
                          style={{ width: `${(selectedSeats.length / searchForm.passageiros) * 100}%` }}
                        ></div>
                      </div>
                    </div>

                    {/* Price */}
                    <div className="bg-gradient-to-r from-purple-600 to-indigo-600 rounded-lg p-3 text-white mb-4">
                      <p className="text-xs uppercase font-bold opacity-90">Valor por passageiro</p>
                      <p className="text-2xl font-bold mt-1">R$ {selectedTrip.valorTotal.toFixed(2)}</p>
                      {selectedSeats.length > 0 && (
                        <p className="text-xs mt-1 opacity-90">Total: R$ {(selectedTrip.valorTotal * selectedSeats.length).toFixed(2)}</p>
                      )}
                    </div>

                    {/* Continue button */}
                    <button 
                      onClick={confirmSeats} 
                      disabled={selectedSeats.length !== searchForm.passageiros} 
                      className="w-full px-6 py-3 bg-purple-600 text-white rounded-lg font-bold hover:bg-purple-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition flex items-center justify-center gap-2 shadow-lg"
                    >
                      Continuar <ArrowRight className="w-4 h-4" />
                    </button>
                    {selectedSeats.length !== searchForm.passageiros && (
                      <p className="text-xs text-center text-gray-500 mt-2">
                        Selecione {searchForm.passageiros - selectedSeats.length} poltrona(s) restante(s)
                      </p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Step 3: Passengers */}
      {step === 3 && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-800">Dados dos Passageiros</h3>
              <button onClick={() => setStep(2)} className="text-sm text-purple-600 hover:text-purple-700 flex items-center gap-1">
                <ArrowLeft className="w-4 h-4" /> Voltar
              </button>
            </div>

            <div className="space-y-6">
              {passengers.map((p, i) => (
                <div key={i} className="border border-gray-200 rounded-lg p-4">
                  <h4 className="font-medium text-gray-700 mb-3">Passageiro {i + 1} - Poltrona {p.poltrona}</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Nome Completo *</label>
                      <input value={p.nomeCompleto} onChange={e => updatePassenger(i, 'nomeCompleto', e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">CPF *</label>
                      <input 
                        value={formatCPF(p.cpf)}
                        onChange={e => {
                          const value = e.target.value.replace(/\D/g, '').slice(0, 11);
                          updatePassenger(i, 'cpf', value);
                        }}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none"
                        placeholder="000.000.000-00"
                        maxLength={14}
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Data Nascimento</label>
                      <input type="date" value={p.dataNascimento} onChange={e => updatePassenger(i, 'dataNascimento', e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Documento (RG)</label>
                      <input value={p.documento} onChange={e => updatePassenger(i, 'documento', e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none" />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">Telefone</label>
                      <input 
                        value={formatPhone(p.telefone)}
                        onChange={e => {
                          const value = e.target.value.replace(/\D/g, '').slice(0, 11);
                          updatePassenger(i, 'telefone', value);
                        }}
                        className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none"
                        placeholder="(11) 99999-9999"
                        maxLength={15}
                      />
                    </div>
                    <div>
                      <label className="block text-xs font-medium text-gray-600 mb-1">E-mail</label>
                      <input type="email" value={p.email} onChange={e => updatePassenger(i, 'email', e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none" />
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-4">
              <label className="block text-sm font-medium text-gray-700 mb-1">Observações</label>
              <textarea value={observacoes} onChange={e => setObservacoes(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none" rows={2} placeholder="Observações internas..." />
            </div>

            <div className="mt-6 flex justify-end">
              <button onClick={confirmReservation} disabled={!validatePassengers()} className="px-6 py-2.5 bg-purple-600 text-white rounded-lg font-medium hover:bg-purple-700 disabled:bg-gray-300 disabled:cursor-not-allowed transition flex items-center gap-2">
                Revisar Reserva <ArrowRight className="w-4 h-4" />
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Step 4: Review */}
      {step === 4 && selectedTrip && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-800">Revisão da Reserva</h3>
              <button onClick={() => setStep(3)} className="text-sm text-purple-600 hover:text-purple-700 flex items-center gap-1">
                <ArrowLeft className="w-4 h-4" /> Voltar
              </button>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div className="p-4 bg-purple-50 rounded-lg">
                  <h4 className="font-medium text-purple-800 mb-2">Viagem</h4>
                  <p className="text-sm text-purple-700">{selectedTrip.nome}</p>
                  <p className="text-sm text-purple-600">{companies.find(c => c.id === selectedTrip.companyId)?.nomeFantasia}</p>
                  <p className="text-sm text-purple-600 mt-1">{selectedTrip.origem} → {selectedTrip.destino}</p>
                  <p className="text-sm text-purple-600">{selectedTrip.dataSaida} às {selectedTrip.horarioSaida}</p>
                  <p className="text-sm text-purple-600">Classe: <span className="capitalize">{selectedTrip.classe}</span></p>
                  <p className="text-sm text-purple-600">Linha: {selectedTrip.linha} | Prefixo: {selectedTrip.prefixo}</p>
                  <p className="text-sm text-purple-600">Plataforma: {selectedTrip.plataforma}</p>
                </div>

                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium text-gray-800 mb-2">Passageiros</h4>
                  {passengers.map((p, i) => (
                    <div key={i} className="text-sm text-gray-600 py-1 border-b border-gray-200 last:border-0">
                      <span className="font-medium">{p.nomeCompleto}</span> - Poltrona {p.poltrona} - CPF: {p.cpf}
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <div className="p-4 bg-gray-50 rounded-lg">
                  <h4 className="font-medium text-gray-800 mb-3">Valores</h4>
                  <div className="space-y-2 text-sm">
                    <div className="flex justify-between"><span className="text-gray-600">Tarifa ({passengers.length}x)</span><span>R$ {(selectedTrip.tarifa * passengers.length).toFixed(2)}</span></div>
                    <div className="flex justify-between"><span className="text-gray-600">Pedágio</span><span>R$ {(selectedTrip.pedagio * passengers.length).toFixed(2)}</span></div>
                    <div className="flex justify-between"><span className="text-gray-600">Taxa de Embarque</span><span>R$ {(selectedTrip.taxaEmbarque * passengers.length).toFixed(2)}</span></div>
                    <div className="flex justify-between"><span className="text-gray-600">Seguro</span><span>R$ {(selectedTrip.seguro * passengers.length).toFixed(2)}</span></div>
                    <div className="flex justify-between"><span className="text-gray-600">Outras Taxas</span><span>R$ {(selectedTrip.outrasTaxas * passengers.length).toFixed(2)}</span></div>
                    {selectedTrip.desconto > 0 && <div className="flex justify-between text-green-600"><span>Desconto</span><span>- R$ {(selectedTrip.desconto * passengers.length).toFixed(2)}</span></div>}
                    <div className="border-t pt-2 mt-2 flex justify-between font-bold text-lg">
                      <span>Total</span><span className="text-purple-700">R$ {(selectedTrip.valorTotal * passengers.length).toFixed(2)}</span>
                    </div>
                  </div>
                </div>

                {observacoes && (
                  <div className="p-4 bg-yellow-50 rounded-lg">
                    <h4 className="font-medium text-yellow-800 mb-1">Observações</h4>
                    <p className="text-sm text-yellow-700">{observacoes}</p>
                  </div>
                )}
              </div>
            </div>

            <div className="mt-6 flex justify-end">
              <button onClick={confirmReservation} className="px-6 py-3 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition flex items-center gap-2 text-lg">
                <CreditCard className="w-5 h-5" /> Confirmar Reserva
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Step 5: Payment with Pix - Finalização da Compra */}
      {step === 5 && selectedTrip && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
            {/* Header */}
            <div className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white p-5">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-xl font-bold">Finalizar Compra</h3>
                  <p className="text-sm text-purple-100 mt-1">Pagamento via Pix</p>
                </div>
                <button onClick={() => setStep(4)} className="text-sm text-white hover:bg-white/10 px-3 py-1.5 rounded-lg flex items-center gap-1 transition">
                  <ArrowLeft className="w-4 h-4" /> Voltar
                </button>
              </div>
            </div>

            <div className="p-6">
              <div className="grid lg:grid-cols-2 gap-6">
                {/* Lado Esquerdo: QR Code e Pix */}
                <div className="space-y-4">
                  {/* Valor em destaque */}
                  <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl p-5 border border-purple-200 text-center">
                    <p className="text-xs text-purple-600 font-bold uppercase">Valor a Pagar</p>
                    <p className="text-4xl font-bold text-purple-700 mt-2">R$ {(selectedTrip.valorTotal * passengers.length).toFixed(2)}</p>
                    <p className="text-sm text-gray-600 mt-2">{passengers.length} passageiro(s) • Poltrona(s): {selectedSeats.join(', ')}</p>
                  </div>

                  {/* QR Code */}
                  <div className="flex justify-center">
                    {pixCharge?.qrCodeBase64 ? (
                      <div className="p-4 bg-white border-2 border-gray-200 rounded-xl shadow-sm">
                        <img src={pixCharge.qrCodeBase64} alt="QR Code Pix" className="w-56 h-56" />
                      </div>
                    ) : (
                      <div className="w-56 h-56 bg-gray-100 border-2 border-dashed border-gray-300 rounded-xl flex items-center justify-center">
                        <QrCode className="w-20 h-20 text-gray-400" />
                      </div>
                    )}
                  </div>

                  {/* Pix Copia e Cola */}
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Pix Copia e Cola</label>
                    <div className="flex gap-2">
                      <input readOnly value={pixCharge?.pixCode || ''} className="flex-1 px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-xs font-mono text-gray-600" />
                      <button 
                        onClick={() => {
                          if (pixCharge) {
                            navigator.clipboard.writeText(pixCharge.pixCode);
                            setCopiedCode(true);
                            setTimeout(() => setCopiedCode(false), 3000);
                          }
                        }}
                        className={`px-4 py-2 rounded-lg flex items-center gap-1 text-sm font-medium transition ${
                          copiedCode ? 'bg-green-100 text-green-700' : 'bg-purple-100 text-purple-700 hover:bg-purple-200'
                        }`}
                      >
                        {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                        {copiedCode ? 'Copiado!' : 'Copiar'}
                      </button>
                    </div>
                  </div>

                  {/* Botões de Enviar */}
                  <div className="grid grid-cols-2 gap-3">
                    <button 
                      onClick={() => {
                        if (pixCharge) {
                          const msg = encodeURIComponent(
                            `🚌 *Pagamento de Passagem*\n\n` +
                            `*Reserva:* ${pixCharge.reservationCode}\n` +
                            `*Valor:* R$ ${pixCharge.amount.toFixed(2)}\n` +
                            `*Passageiro:* ${pixCharge.passengerName}\n` +
                            `*Viagem:* ${selectedTrip.origem} → ${selectedTrip.destino}\n` +
                            `*Data:* ${selectedTrip.dataSaida} às ${selectedTrip.horarioSaida}\n` +
                            `*Poltrona(s):* ${selectedSeats.join(', ')}\n\n` +
                            `*Pix Copia e Cola:*\n${pixCharge.pixCode}\n\n` +
                            `⚠️ Efetue o pagamento e envie o comprovante.`
                          );
                          window.open(`https://wa.me/?text=${msg}`, '_blank');
                        }
                      }}
                      className="px-4 py-3 bg-green-600 text-white rounded-lg font-medium hover:bg-green-700 transition flex items-center justify-center gap-2"
                    >
                      <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 24 24">
                        <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.334.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.334 11.893-11.892a11.821 11.821 0 00-3.48-8.413z"/>
                      </svg>
                      Enviar WhatsApp
                    </button>
                    <button 
                      onClick={() => {
                        if (pixCharge) {
                          const subject = encodeURIComponent(`Pagamento Reserva ${pixCharge.reservationCode}`);
                          const body = encodeURIComponent(
                            `Pagamento de Passagem\n\n` +
                            `Reserva: ${pixCharge.reservationCode}\n` +
                            `Valor: R$ ${pixCharge.amount.toFixed(2)}\n` +
                            `Passageiro: ${pixCharge.passengerName}\n` +
                            `Viagem: ${selectedTrip.origem} → ${selectedTrip.destino}\n` +
                            `Data: ${selectedTrip.dataSaida} às ${selectedTrip.horarioSaida}\n` +
                            `Poltrona(s): ${selectedSeats.join(', ')}\n\n` +
                            `Pix Copia e Cola:\n${pixCharge.pixCode}\n\n` +
                            `Efetue o pagamento e envie o comprovante.`
                          );
                          window.open(`mailto:?subject=${subject}&body=${body}`, '_blank');
                        }
                      }}
                      className="px-4 py-3 bg-blue-600 text-white rounded-lg font-medium hover:bg-blue-700 transition flex items-center justify-center gap-2"
                    >
                      <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" />
                      </svg>
                      Enviar E-mail
                    </button>
                  </div>


                </div>

                {/* Lado Direito: Resumo e Ações */}
                <div className="space-y-4">
                  {/* Resumo da Reserva */}
                  <div className="bg-white border border-gray-200 rounded-xl p-4">
                    <h4 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
                      <FileText className="w-4 h-4 text-purple-600" />
                      Resumo da Reserva
                    </h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Código:</span>
                        <span className="font-mono font-medium text-gray-800">{pixCharge?.reservationCode}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Viagem:</span>
                        <span className="font-medium text-gray-800">{selectedTrip.nome}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Empresa:</span>
                        <span className="font-medium text-gray-800">{companies.find(c => c.id === selectedTrip.companyId)?.nomeFantasia}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Origem:</span>
                        <span className="font-medium text-gray-800">{selectedTrip.origem}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Destino:</span>
                        <span className="font-medium text-gray-800">{selectedTrip.destino}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Data/Hora:</span>
                        <span className="font-medium text-gray-800">{selectedTrip.dataSaida} {selectedTrip.horarioSaida}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Classe:</span>
                        <span className="font-medium text-gray-800 capitalize">{selectedTrip.classe}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Plataforma:</span>
                        <span className="font-medium text-gray-800">{selectedTrip.plataforma}</span>
                      </div>
                    </div>
                  </div>

                  {/* Passageiros */}
                  <div className="bg-white border border-gray-200 rounded-xl p-4">
                    <h4 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
                      <User className="w-4 h-4 text-purple-600" />
                      Passageiros
                    </h4>
                    <div className="space-y-2">
                      {passengers.map((p, i) => (
                        <div key={i} className="flex items-center justify-between text-sm p-2 bg-gray-50 rounded">
                          <div>
                            <p className="font-medium text-gray-800">{p.nomeCompleto}</p>
                            <p className="text-xs text-gray-500">CPF: {p.cpf.replace(/(\d{3})(\d{3})(\d{3})(\d{2})/, '$1.$2.$3-$4')}</p>
                          </div>
                          <div className="bg-purple-600 text-white px-2 py-1 rounded text-xs font-bold">
                            Poltrona {p.poltrona}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  {/* Informações do Pix */}
                  <div className="bg-white border border-gray-200 rounded-xl p-4">
                    <h4 className="font-bold text-gray-800 mb-3 flex items-center gap-2">
                      <CreditCard className="w-4 h-4 text-purple-600" />
                      Informações do Pagamento
                    </h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-gray-500">Método:</span>
                        <span className="font-medium text-gray-800">Pix</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Status:</span>
                        <span className="px-2 py-0.5 bg-yellow-100 text-yellow-700 rounded-full text-xs font-medium">Aguardando</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-gray-500">Expira em:</span>
                        <span className="font-medium text-gray-800">
                          {pixCharge ? new Date(pixCharge.expiresAt).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }) : '-'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Botões de Ação */}
                  <div className="space-y-3">
                    {/* Confirmar Pagamento */}
                    <button 
                      onClick={() => {
                        if (pixCharge) {
                          updatePixCharge({ ...pixCharge, status: 'paid', paidAt: new Date().toISOString() });
                          const res = reservations.find(r => r.codigo === pixCharge.reservationCode);
                          if (res) {
                            updateReservation({ 
                              ...res, 
                              paymentStatus: 'aprovado', 
                              status: 'paga',
                              updatedAt: new Date().toISOString(),
                              history: [...res.history, { date: new Date().toISOString(), action: 'Pagamento Pix confirmado', user: currentUser?.name || '' }]
                            });
                          }
                          setStep(6);
                        }
                      }}
                      className="w-full px-6 py-3 bg-green-600 text-white rounded-lg font-bold hover:bg-green-700 transition flex items-center justify-center gap-2 shadow-lg"
                    >
                      <Check className="w-5 h-5" />
                      Confirmar Pagamento
                    </button>

                    <button onClick={resetFlow} className="w-full px-6 py-3 border border-gray-300 text-gray-700 rounded-lg font-medium hover:bg-gray-50 transition">
                      Cancelar e Nova Emissão
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Step 6: Sucesso - Compra Finalizada */}
      {step === 6 && selectedTrip && (
        <div className="space-y-6">
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="bg-gradient-to-r from-green-500 to-emerald-600 text-white p-8 text-center">
              <div className="w-20 h-20 bg-white/20 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-10 h-10 text-white" />
              </div>
              <h3 className="text-2xl font-bold">Compra Finalizada com Sucesso!</h3>
              <p className="text-green-100 mt-2">Pagamento confirmado via Pix</p>
            </div>

            <div className="p-6">
              <div className="max-w-2xl mx-auto space-y-6">
                {/* Resumo Final */}
                <div className="bg-gradient-to-br from-purple-50 to-indigo-50 rounded-xl p-6 border border-purple-200">
                  <h4 className="font-bold text-gray-800 mb-4 text-center">Detalhes da Compra</h4>
                  <div className="grid grid-cols-2 gap-4 text-sm">
                    <div>
                      <p className="text-gray-500">Código da Reserva</p>
                      <p className="font-mono font-bold text-gray-800">{pixCharge?.reservationCode}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Valor Pago</p>
                      <p className="font-bold text-purple-700 text-lg">R$ {(selectedTrip.valorTotal * passengers.length).toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Viagem</p>
                      <p className="font-medium text-gray-800">{selectedTrip.origem} → {selectedTrip.destino}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Data/Hora</p>
                      <p className="font-medium text-gray-800">{selectedTrip.dataSaida} {selectedTrip.horarioSaida}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Passageiro(s)</p>
                      <p className="font-medium text-gray-800">{passengers.map(p => p.nomeCompleto).join(', ')}</p>
                    </div>
                    <div>
                      <p className="text-gray-500">Poltrona(s)</p>
                      <p className="font-medium text-gray-800">{selectedSeats.join(', ')}</p>
                    </div>
                  </div>
                </div>

                {/* Próximos Passos */}
                <div className="bg-white border border-gray-200 rounded-xl p-6">
                  <h4 className="font-bold text-gray-800 mb-4">Próximos Passos</h4>
                  <div className="space-y-3">
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <Check className="w-4 h-4 text-green-600" />
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">Pagamento confirmado</p>
                        <p className="text-sm text-gray-500">Sua reserva está confirmada no sistema</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 bg-purple-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-xs font-bold text-purple-600">2</span>
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">Emitir Bilhete Eletrônico</p>
                        <p className="text-sm text-gray-500">Gere o BPE (Bilhete de Passagem Eletrônico) para o passageiro</p>
                      </div>
                    </div>
                    <div className="flex items-start gap-3">
                      <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center flex-shrink-0">
                        <span className="text-xs font-bold text-gray-600">3</span>
                      </div>
                      <div>
                        <p className="font-medium text-gray-800">Enviar ao Cliente</p>
                        <p className="text-sm text-gray-500">Envie o bilhete por WhatsApp ou e-mail</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Ações */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <button 
                    onClick={() => navigate('/bilhetes')}
                    className="px-6 py-3 bg-purple-600 text-white rounded-lg font-bold hover:bg-purple-700 transition flex items-center justify-center gap-2"
                  >
                    <FileText className="w-5 h-5" />
                    Emitir Bilhete
                  </button>
                  <button 
                    onClick={resetFlow}
                    className="px-6 py-3 border-2 border-purple-600 text-purple-600 rounded-lg font-bold hover:bg-purple-50 transition flex items-center justify-center gap-2"
                  >
                    <Plus className="w-5 h-5" />
                    Nova Emissão
                  </button>
                </div>

                <button 
                  onClick={() => navigate('/dashboard')}
                  className="w-full px-6 py-3 text-gray-600 hover:bg-gray-50 rounded-lg font-medium transition"
                >
                  Voltar ao Dashboard
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
