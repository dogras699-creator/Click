import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../contexts/DataContext';
import { User } from '../types';
import { Bus, Eye, EyeOff, AlertCircle, LogIn, User as UserIcon, Lock } from 'lucide-react';

export default function Login() {
  const { login, users } = useData();
  const navigate = useNavigate();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [showRecovery, setShowRecovery] = useState(false);
  const [savedUser, setSavedUser] = useState<User | null>(null);
  const [showCredentials, setShowCredentials] = useState(false);

  // Verificar se há usuário salvo
  useEffect(() => {
    const savedUserJson = localStorage.getItem('lastUser');
    if (savedUserJson) {
      try {
        const userData = JSON.parse(savedUserJson);
        const user = users.find(u => u.id === userData.id && u.active);
        if (user) {
          setSavedUser(user);
          setEmail(user.email);
        }
      } catch (e) {
        console.error('Erro ao carregar usuário salvo:', e);
      }
    }
  }, [users]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!email || !password) {
      setError('Preencha todos os campos');
      return;
    }
    const success = login(email, password);
    if (success) {
      // Salvar último usuário logado
      const user = users.find(u => u.email === email);
      if (user) {
        localStorage.setItem('lastUser', JSON.stringify({ id: user.id }));
      }
      navigate('/dashboard');
    } else {
      setError('E-mail ou senha inválidos');
    }
  };

  const handleQuickLogin = () => {
    if (savedUser) {
      // Login rápido com senha salva
      const success = login(savedUser.email, savedUser.password);
      if (success) {
        localStorage.setItem('lastUser', JSON.stringify({ id: savedUser.id }));
        navigate('/dashboard');
      }
    }
  };

  const handleClearSavedUser = () => {
    localStorage.removeItem('lastUser');
    setSavedUser(null);
    setEmail('');
    setPassword('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-900 via-purple-800 to-indigo-900 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-white/10 backdrop-blur-sm rounded-2xl mb-4">
            <Bus className="w-8 h-8 text-white" />
          </div>
          <h1 className="text-2xl font-bold text-white">Painel de Emissão Rodoviária</h1>
          <p className="text-purple-200 text-sm mt-1">Sistema de gerenciamento de passagens</p>

        </div>

        {/* Login form */}
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          {savedUser ? (
            <>
              {/* Acesso Salvo */}
              <div className="text-center mb-6">
                <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-3">
                  <span className="text-2xl font-bold text-purple-600">{savedUser.name.charAt(0)}</span>
                </div>
                <h2 className="text-xl font-semibold text-gray-800">Bem-vindo de volta!</h2>
                <p className="text-sm text-gray-500 mt-1">{savedUser.name}</p>
                <p className="text-xs text-gray-400 capitalize">{savedUser.role === 'admin' ? 'Administrador' : 'Atendente'}</p>
              </div>

              {/* Quick Login Button */}
              <button
                onClick={handleQuickLogin}
                className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-colors shadow-lg shadow-purple-200 flex items-center justify-center gap-2 mb-3"
              >
                <LogIn className="w-5 h-5" />
                Entrar como {savedUser.name.split(' ')[0]}
              </button>

              {/* Divider */}
              <div className="relative my-4">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-gray-200"></div>
                </div>
                <div className="relative flex justify-center text-xs">
                  <span className="px-2 bg-white text-gray-500">OU</span>
                </div>
              </div>

              {/* Login com outro usuário */}
              <button
                onClick={handleClearSavedUser}
                className="w-full py-2.5 border border-gray-300 hover:bg-gray-50 text-gray-700 font-medium rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <UserIcon className="w-4 h-4" />
                Entrar com outro usuário
              </button>
            </>
          ) : (
            <>
              <h2 className="text-xl font-semibold text-gray-800 mb-6">Acesse sua conta</h2>
              
              {error && (
                <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded-lg flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-500 flex-shrink-0" />
                  <p className="text-sm text-red-600">{error}</p>
                </div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">E-mail</label>
                  <input
                    type="email"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition"
                    placeholder="seu@email.com"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Senha</label>
                  <div className="relative">
                    <input
                      type={showPassword ? 'text' : 'password'}
                      value={password}
                      onChange={e => setPassword(e.target.value)}
                      className="w-full px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none transition pr-10"
                      placeholder="••••••"
                    />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <button type="submit" className="w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white font-medium rounded-lg transition-colors shadow-lg shadow-purple-200">
                  Entrar
                </button>
              </form>

              <button onClick={() => setShowRecovery(!showRecovery)} className="mt-4 text-sm text-purple-600 hover:text-purple-700 font-medium">
                Esqueceu a senha?
              </button>

              {showRecovery && (
                <div className="mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg">
                  <p className="text-sm text-blue-700">Em produção, um link de recuperação seria enviado ao e-mail cadastrado.</p>
                </div>
              )}

              {/* Botão para limpar cache */}
              <button
                onClick={() => {
                  localStorage.clear();
                  window.location.reload();
                }}
                className="mt-4 w-full text-xs text-gray-400 hover:text-gray-600 transition-colors"
              >
                Limpar cache e recarregar
              </button>
            </>
          )}

          {/* Credenciais de acesso - ocultas por padrão */}
          <div className="mt-6 pt-6 border-t border-gray-200">
            {!showCredentials ? (
              <button 
                onClick={() => setShowCredentials(true)}
                className="w-full text-center text-xs text-gray-400 hover:text-gray-600 transition-colors flex items-center justify-center gap-1"
              >
                <Lock className="w-3 h-3" />
                <span>Necessita credenciais de acesso?</span>
              </button>
            ) : (
              <div>
                <div className="flex items-center justify-between mb-3">
                  <p className="text-xs text-gray-500 font-medium">Credenciais de acesso:</p>
                  <button 
                    onClick={() => setShowCredentials(false)}
                    className="text-xs text-gray-400 hover:text-gray-600"
                  >
                    Ocultar
                  </button>
                </div>
                <div className="space-y-2 text-xs">
                  <div className="flex justify-between items-center p-2 bg-gray-50 rounded-lg">
                    <div>
                      <span className="font-medium text-gray-700">Admin:</span>
                      <span className="text-gray-500 ml-1 font-mono">brladsagencia@gmail.com</span>
                    </div>
                    <button 
                      onClick={() => {
                        setEmail('brladsagencia@gmail.com');
                        setPassword('@Crypto123451');
                      }}
                      className="px-2 py-1 text-purple-600 hover:bg-purple-50 rounded text-xs font-medium"
                    >
                      Usar
                    </button>
                  </div>
                  <div className="flex justify-between items-center p-2 bg-gray-50 rounded-lg">
                    <div>
                      <span className="font-medium text-gray-700">Atendente:</span>
                      <span className="text-gray-500 ml-1 font-mono">maria@painel.com</span>
                    </div>
                    <button 
                      onClick={() => {
                        setEmail('maria@painel.com');
                        setPassword('123456');
                      }}
                      className="px-2 py-1 text-purple-600 hover:bg-purple-50 rounded text-xs font-medium"
                    >
                      Usar
                    </button>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-xs text-purple-300 mt-6">
          © 2024 Painel de Emissão Rodoviária - Todos os direitos reservados
        </p>
      </div>
    </div>
  );
}
