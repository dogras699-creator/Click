import React, { useState, useEffect } from 'react';
import { useData } from '../contexts/DataContext';
import { PixKey, PixCharge } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { generatePixCode, generateQRCodeBase64, validatePixKey, maskPixKey } from '../utils/pix';
import { formatPhone, formatCNPJ, formatCPF } from '../utils/masks';
import {
  Key, Plus, Edit2, Trash2, X, Copy, Check, Share2, Eye,
  Clock, CheckCircle, XCircle, AlertCircle, QrCode, Filter,
  DollarSign, Star, Shield, RefreshCw, Send
} from 'lucide-react';

export default function Payments() {
  const { 
    pixKeys, pixCharges, reservations, settings, currentUser,
    addPixKey, updatePixKey, deletePixKey, setDefaultPixKey,
    addPixCharge, updatePixCharge, addLog
  } = useData();

  const [activeTab, setActiveTab] = useState<'charges' | 'keys' | 'generate'>('charges');
  const [showKeyModal, setShowKeyModal] = useState(false);
  const [showChargeModal, setShowChargeModal] = useState(false);
  const [showChargeDetail, setShowChargeDetail] = useState<string | null>(null);
  const [editingKey, setEditingKey] = useState<PixKey | null>(null);
  const [copiedCode, setCopiedCode] = useState(false);
  const [selectedReservationId, setSelectedReservationId] = useState('');

  // Filtros
  const [filterStatus, setFilterStatus] = useState('');
  const [filterDateFrom, setFilterDateFrom] = useState('');
  const [filterDateTo, setFilterDateTo] = useState('');
  const [filterSearch, setFilterSearch] = useState('');

  // Formulário de chave Pix
  const [keyForm, setKeyForm] = useState({
    agencyName: settings.razaoSocial,
    keyType: 'cpf' as PixKey['keyType'],
    key: '',
    holderName: '',
    holderDocument: '',
    bank: '',
    active: true
  });

  // Formulário de cobrança
  const [chargeForm, setChargeForm] = useState({
    pixKeyId: '',
    amount: 0,
    description: ''
  });

  const [generatedCharge, setGeneratedCharge] = useState<PixCharge | null>(null);

  // Stats
  const pendingCharges = pixCharges.filter(c => c.status === 'pending');
  const paidCharges = pixCharges.filter(c => c.status === 'paid');
  const cancelledCharges = pixCharges.filter(c => c.status === 'cancelled' || c.status === 'expired');
  const totalReceived = paidCharges.reduce((sum, c) => sum + c.amount, 0);

  const pendingReservations = reservations.filter(r => r.paymentStatus === 'aguardando' && r.status !== 'cancelada');

  // Filtrar cobranças
  const filteredCharges = pixCharges.filter(c => {
    if (filterStatus && c.status !== filterStatus) return false;
    if (filterDateFrom && c.createdAt < filterDateFrom) return false;
    if (filterDateTo && c.createdAt > filterDateTo + 'T23:59:59') return false;
    if (filterSearch) {
      const search = filterSearch.toLowerCase();
      return c.reservationCode.toLowerCase().includes(search) ||
        c.passengerName.toLowerCase().includes(search) ||
        c.id.toLowerCase().includes(search);
    }
    return true;
  });

  // Selecionar chave padrão automaticamente
  useEffect(() => {
    if (!chargeForm.pixKeyId && pixKeys.length > 0) {
      const defaultKey = pixKeys.find(k => k.isDefault && k.active);
      if (defaultKey) {
        setChargeForm(prev => ({ ...prev, pixKeyId: defaultKey.id }));
      } else if (pixKeys[0]) {
        setChargeForm(prev => ({ ...prev, pixKeyId: pixKeys[0].id }));
      }
    }
  }, [pixKeys, chargeForm.pixKeyId]);

  // Preencher valor ao selecionar reserva
  useEffect(() => {
    if (selectedReservationId) {
      const res = reservations.find(r => r.id === selectedReservationId);
      if (res) {
        setChargeForm(prev => ({
          ...prev,
          amount: res.valorTotal,
          description: `Pagamento reserva ${res.codigo} - ${res.passengers[0]?.nomeCompleto}`
        }));
      }
    }
  }, [selectedReservationId, reservations]);

  // Handlers de chave Pix
  const openNewKey = () => {
    setKeyForm({
      agencyName: settings.razaoSocial,
      keyType: 'cpf',
      key: '',
      holderName: '',
      holderDocument: '',
      bank: '',
      active: true
    });
    setEditingKey(null);
    setShowKeyModal(true);
  };

  const openEditKey = (key: PixKey) => {
    setKeyForm({
      agencyName: key.agencyName,
      keyType: key.keyType,
      key: key.key,
      holderName: key.holderName,
      holderDocument: key.holderDocument,
      bank: key.bank || '',
      active: key.active
    });
    setEditingKey(key);
    setShowKeyModal(true);
  };

  const handleSaveKey = () => {
    const validation = validatePixKey(keyForm.keyType, keyForm.key);
    if (!validation.valid) {
      alert(validation.message);
      return;
    }
    if (!keyForm.holderName || !keyForm.holderDocument) {
      alert('Preencha todos os campos obrigatórios');
      return;
    }

    if (editingKey) {
      updatePixKey({ ...editingKey, ...keyForm });
      addLog('Chave Pix atualizada', keyForm.key);
    } else {
      const newKey: PixKey = {
        id: uuidv4(),
        ...keyForm,
        isDefault: pixKeys.length === 0,
        createdAt: new Date().toISOString()
      };
      addPixKey(newKey);
      addLog('Chave Pix cadastrada', keyForm.key);
    }
    setShowKeyModal(false);
  };

  const handleDeleteKey = (id: string) => {
    if (confirm('Deseja realmente excluir esta chave Pix?')) {
      deletePixKey(id);
      addLog('Chave Pix excluída', id);
    }
  };

  const handleSetDefault = (id: string) => {
    setDefaultPixKey(id);
    addLog('Chave Pix definida como padrão', id);
  };

  // Gerar cobrança Pix
  const handleGenerateCharge = async () => {
    if (!chargeForm.pixKeyId || chargeForm.amount <= 0) {
      alert('Selecione uma chave Pix e informe o valor');
      return;
    }

    const pixKey = pixKeys.find(k => k.id === chargeForm.pixKeyId);
    if (!pixKey) return;

    const reservation = selectedReservationId ? reservations.find(r => r.id === selectedReservationId) : null;

    // Gerar código Pix EMV/BR Code
    const txid = `RES${Date.now().toString(36).toUpperCase()}`;
    const pixCode = generatePixCode({
      pixKey: pixKey.key,
      merchantName: pixKey.agencyName || settings.razaoSocial,
      merchantCity: 'SAO PAULO',
      amount: chargeForm.amount,
      txid
    });

    // Gerar QR Code
    const qrCodeBase64 = await generateQRCodeBase64(pixCode);

    const charge: PixCharge = {
      id: uuidv4(),
      reservationId: selectedReservationId || '',
      pixKeyId: pixKey.id,
      amount: chargeForm.amount,
      description: chargeForm.description || `Cobrança Pix`,
      pixCode,
      qrCodeBase64,
      status: 'pending',
      createdAt: new Date().toISOString(),
      expiresAt: new Date(Date.now() + 3600000).toISOString(), // 1 hora
      attendantId: currentUser?.id || '',
      passengerName: reservation?.passengers[0]?.nomeCompleto || 'Avulso',
      reservationCode: reservation?.codigo || `AVULSO-${Date.now().toString(36).toUpperCase()}`
    };

    addPixCharge(charge);
    addLog('Cobrança Pix gerada', `R$ ${charge.amount.toFixed(2)} - ${charge.reservationCode}`);
    setGeneratedCharge(charge);
    setShowChargeModal(false);
  };

  // Simular aprovação de pagamento
  const handleSimulatePayment = (chargeId: string) => {
    const charge = pixCharges.find(c => c.id === chargeId);
    if (!charge) return;

    updatePixCharge({
      ...charge,
      status: 'paid',
      paidAt: new Date().toISOString()
    });

    addLog('Pagamento Pix aprovado', charge.reservationCode);
    setGeneratedCharge(null);
  };

  const handleCancelCharge = (chargeId: string) => {
    const charge = pixCharges.find(c => c.id === chargeId);
    if (!charge) return;
    updatePixCharge({ ...charge, status: 'cancelled' });
    addLog('Cobrança Pix cancelada', charge.reservationCode);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 3000);
  };

  const getKeyTypeLabel = (type: string) => {
    const map: Record<string, string> = {
      cpf: 'CPF',
      cnpj: 'CNPJ',
      email: 'E-mail',
      phone: 'Telefone',
      random: 'Chave Aleatória'
    };
    return map[type] || type;
  };

  const getStatusBadge = (status: string) => {
    const map: Record<string, { bg: string; text: string; label: string; icon: any }> = {
      pending: { bg: 'bg-yellow-100', text: 'text-yellow-700', label: 'Aguardando', icon: Clock },
      paid: { bg: 'bg-green-100', text: 'text-green-700', label: 'Pago', icon: CheckCircle },
      expired: { bg: 'bg-gray-100', text: 'text-gray-700', label: 'Expirado', icon: XCircle },
      cancelled: { bg: 'bg-red-100', text: 'text-red-700', label: 'Cancelado', icon: XCircle },
      error: { bg: 'bg-red-100', text: 'text-red-700', label: 'Erro', icon: AlertCircle },
    };
    const s = map[status] || map.pending;
    const Icon = s.icon;
    return (
      <span className={`inline-flex items-center gap-1 px-2 py-1 rounded-full text-xs font-medium ${s.bg} ${s.text}`}>
        <Icon className="w-3 h-3" /> {s.label}
      </span>
    );
  };

  const detailCharge = generatedCharge ? generatedCharge : (showChargeDetail ? pixCharges.find(c => c.id === showChargeDetail) : null);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-800">Pagamentos Pix</h2>
          <p className="text-sm text-gray-500">Gerencie chaves Pix e cobranças</p>
        </div>
        <div className="flex gap-2">
          <button onClick={() => setActiveTab('generate')} className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700 flex items-center gap-2">
            <QrCode className="w-4 h-4" /> Gerar Cobrança
          </button>
          {currentUser?.role === 'admin' && (
            <button onClick={openNewKey} className="px-4 py-2 border border-purple-600 text-purple-600 rounded-lg text-sm font-medium hover:bg-purple-50 flex items-center gap-2">
              <Key className="w-4 h-4" /> Cadastrar Chave
            </button>
          )}
        </div>
      </div>



      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-yellow-100 rounded-lg flex items-center justify-center">
              <Clock className="w-5 h-5 text-yellow-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-800">{pendingCharges.length}</p>
              <p className="text-xs text-gray-500">Aguardando</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
              <CheckCircle className="w-5 h-5 text-green-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-800">{paidCharges.length}</p>
              <p className="text-xs text-gray-500">Aprovados</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center">
              <XCircle className="w-5 h-5 text-red-600" />
            </div>
            <div>
              <p className="text-2xl font-bold text-gray-800">{cancelledCharges.length}</p>
              <p className="text-xs text-gray-500">Cancelados</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
              <DollarSign className="w-5 h-5 text-purple-600" />
            </div>
            <div>
              <p className="text-xl font-bold text-gray-800">R$ {totalReceived.toFixed(2)}</p>
              <p className="text-xs text-gray-500">Total Recebido</p>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 bg-gray-100 p-1 rounded-lg">
        <button onClick={() => setActiveTab('charges')} className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition ${activeTab === 'charges' ? 'bg-white text-purple-700 shadow-sm' : 'text-gray-600 hover:text-gray-800'}`}>
          Histórico de Cobranças
        </button>
        <button onClick={() => setActiveTab('keys')} className={`flex-1 px-4 py-2 rounded-md text-sm font-medium transition ${activeTab === 'keys' ? 'bg-white text-purple-700 shadow-sm' : 'text-gray-600 hover:text-gray-800'}`}>
          Chaves Pix ({pixKeys.length})
        </button>
      </div>

      {/* Tab: Histórico de Cobranças */}
      {activeTab === 'charges' && (
        <div className="space-y-4">
          {/* Filtros */}
          <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
            <div className="flex items-center gap-2 mb-3">
              <Filter className="w-4 h-4 text-gray-500" />
              <span className="text-sm font-medium text-gray-700">Filtros</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
              <input value={filterSearch} onChange={e => setFilterSearch(e.target.value)} placeholder="Buscar reserva, passageiro..." className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none" />
              <select value={filterStatus} onChange={e => setFilterStatus(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
                <option value="">Todos os status</option>
                <option value="pending">Aguardando</option>
                <option value="paid">Pago</option>
                <option value="expired">Expirado</option>
                <option value="cancelled">Cancelado</option>
              </select>
              <input type="date" value={filterDateFrom} onChange={e => setFilterDateFrom(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none" placeholder="Data início" />
              <input type="date" value={filterDateTo} onChange={e => setFilterDateTo(e.target.value)} className="px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none" placeholder="Data fim" />
            </div>
          </div>

          {/* Tabela de cobranças */}
          <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Cobrança</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Reserva</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Cliente</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Valor</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Chave Pix</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Data</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ações</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-100">
                  {filteredCharges.map(c => {
                    const pixKey = pixKeys.find(k => k.id === c.pixKeyId);
                    return (
                      <tr key={c.id} className="hover:bg-gray-50">
                        <td className="px-4 py-3">
                          <p className="text-xs font-mono text-gray-800">{c.id.substring(0, 8)}</p>
                        </td>
                        <td className="px-4 py-3 text-sm text-gray-700">{c.reservationCode}</td>
                        <td className="px-4 py-3 text-sm text-gray-700">{c.passengerName}</td>
                        <td className="px-4 py-3 text-sm font-medium text-gray-800">R$ {c.amount.toFixed(2)}</td>
                        <td className="px-4 py-3 text-xs text-gray-600">
                          {pixKey ? `${getKeyTypeLabel(pixKey.keyType)}: ${maskPixKey(pixKey.keyType, pixKey.key)}` : '-'}
                        </td>
                        <td className="px-4 py-3 text-xs text-gray-600">{new Date(c.createdAt).toLocaleString('pt-BR')}</td>
                        <td className="px-4 py-3">{getStatusBadge(c.status)}</td>
                        <td className="px-4 py-3">
                          <div className="flex gap-1">
                            <button onClick={() => setShowChargeDetail(c.id)} className="p-1.5 hover:bg-gray-100 rounded" title="Ver detalhes">
                              <Eye className="w-3.5 h-3.5 text-gray-500" />
                            </button>
                            {c.status === 'pending' && (
                              <button onClick={() => handleSimulatePayment(c.id)} className="p-1.5 hover:bg-green-50 rounded" title="Simular pagamento">
                                <CheckCircle className="w-3.5 h-3.5 text-green-600" />
                              </button>
                            )}
                            {c.status === 'pending' && (
                              <button onClick={() => handleCancelCharge(c.id)} className="p-1.5 hover:bg-red-50 rounded" title="Cancelar">
                                <XCircle className="w-3.5 h-3.5 text-red-500" />
                              </button>
                            )}
                          </div>
                        </td>
                      </tr>
                    );
                  })}
                  {filteredCharges.length === 0 && (
                    <tr><td colSpan={8} className="px-4 py-8 text-center text-gray-400">Nenhuma cobrança encontrada</td></tr>
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Tab: Chaves Pix */}
      {activeTab === 'keys' && (
        <div className="space-y-4">
          {pixKeys.length === 0 ? (
            <div className="bg-white rounded-xl border border-gray-100 p-8 text-center">
              <Key className="w-12 h-12 text-gray-300 mx-auto mb-3" />
              <p className="text-gray-500">Nenhuma chave Pix cadastrada</p>
              <p className="text-sm text-gray-400 mt-1">Cadastre uma chave para começar a receber pagamentos</p>
              {currentUser?.role === 'admin' && (
                <button onClick={openNewKey} className="mt-4 px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700">
                  Cadastrar Chave Pix
                </button>
              )}
            </div>
          ) : (
            <div className="grid gap-4 md:grid-cols-2">
              {pixKeys.map(key => (
                <div key={key.id} className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm hover:shadow-md transition relative">
                  {key.isDefault && (
                    <div className="absolute top-3 right-3">
                      <span className="inline-flex items-center gap-1 px-2 py-0.5 bg-purple-100 text-purple-700 rounded-full text-xs font-medium">
                        <Star className="w-3 h-3" /> Padrão
                      </span>
                    </div>
                  )}
                  <div className="flex items-start gap-3">
                    <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center flex-shrink-0">
                      <Key className="w-5 h-5 text-purple-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-gray-800">{key.agencyName}</p>
                      <p className="text-xs text-gray-500 mt-0.5">{getKeyTypeLabel(key.keyType)}</p>
                      <p className="text-sm font-mono text-gray-700 mt-1 truncate">{maskPixKey(key.keyType, key.key)}</p>
                      <p className="text-xs text-gray-500 mt-1">Titular: {key.holderName}</p>
                      {key.bank && <p className="text-xs text-gray-500">Banco: {key.bank}</p>}
                      <div className="flex items-center gap-2 mt-2">
                        <span className={`px-2 py-0.5 rounded-full text-xs ${key.active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                          {key.active ? 'Ativa' : 'Inativa'}
                        </span>
                      </div>
                    </div>
                  </div>
                  {currentUser?.role === 'admin' && (
                    <div className="flex gap-1 mt-3 pt-3 border-t border-gray-100">
                      {!key.isDefault && (
                        <button onClick={() => handleSetDefault(key.id)} className="flex-1 px-2 py-1.5 text-xs font-medium text-purple-600 hover:bg-purple-50 rounded-lg flex items-center justify-center gap-1">
                          <Star className="w-3 h-3" /> Definir Padrão
                        </button>
                      )}
                      <button onClick={() => openEditKey(key)} className="flex-1 px-2 py-1.5 text-xs font-medium text-gray-600 hover:bg-gray-50 rounded-lg flex items-center justify-center gap-1">
                        <Edit2 className="w-3 h-3" /> Editar
                      </button>
                      <button onClick={() => handleDeleteKey(key.id)} className="flex-1 px-2 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 rounded-lg flex items-center justify-center gap-1">
                        <Trash2 className="w-3 h-3" /> Excluir
                      </button>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Modal: Cadastrar/Editar Chave Pix */}
      {showKeyModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-lg font-semibold">{editingKey ? 'Editar Chave Pix' : 'Cadastrar Chave Pix'}</h3>
              <button onClick={() => setShowKeyModal(false)}><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nome da Agência *</label>
                <input value={keyForm.agencyName} onChange={e => setKeyForm({...keyForm, agencyName: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Tipo de Chave *</label>
                <select value={keyForm.keyType} onChange={e => setKeyForm({...keyForm, keyType: e.target.value as PixKey['keyType'], key: ''})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none">
                  <option value="cpf">CPF</option>
                  <option value="cnpj">CNPJ</option>
                  <option value="email">E-mail</option>
                  <option value="phone">Telefone</option>
                  <option value="random">Chave Aleatória (EVP)</option>
                </select>
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Chave Pix * 
                  <span className="text-xs text-gray-500 ml-2">
                    {keyForm.keyType === 'cpf' && '(11 dígitos)'}
                    {keyForm.keyType === 'cnpj' && '(14 dígitos)'}
                    {keyForm.keyType === 'email' && '(exemplo@email.com)'}
                    {keyForm.keyType === 'phone' && '(com DDD)'}
                    {keyForm.keyType === 'random' && '(32 caracteres alfanuméricos)'}
                  </span>
                </label>
                <input 
                  value={
                    keyForm.keyType === 'cpf' ? formatCPF(keyForm.key) :
                    keyForm.keyType === 'cnpj' ? formatCNPJ(keyForm.key) :
                    keyForm.keyType === 'phone' ? formatPhone(keyForm.key) :
                    keyForm.key
                  }
                  onChange={e => {
                    let value = e.target.value;
                    if (keyForm.keyType === 'cpf') {
                      value = value.replace(/\D/g, '').slice(0, 11);
                    } else if (keyForm.keyType === 'cnpj') {
                      value = value.replace(/\D/g, '').slice(0, 14);
                    } else if (keyForm.keyType === 'phone') {
                      value = value.replace(/\D/g, '').slice(0, 11);
                    }
                    setKeyForm({...keyForm, key: value});
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none font-mono"
                  placeholder={
                    keyForm.keyType === 'cpf' ? '000.000.000-00' :
                    keyForm.keyType === 'cnpj' ? '00.000.000/0001-00' :
                    keyForm.keyType === 'email' ? 'email@exemplo.com' :
                    keyForm.keyType === 'phone' ? '(11) 99999-9999' :
                    'Chave aleatória de 32 caracteres'
                  }
                  maxLength={
                    keyForm.keyType === 'cpf' ? 14 :
                    keyForm.keyType === 'cnpj' ? 18 :
                    keyForm.keyType === 'phone' ? 15 :
                    keyForm.keyType === 'email' ? 100 :
                    32
                  }
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nome do Titular *</label>
                <input value={keyForm.holderName} onChange={e => setKeyForm({...keyForm, holderName: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">CPF/CNPJ do Titular *</label>
                <input 
                  value={keyForm.holderDocument.length <= 11 ? formatCPF(keyForm.holderDocument) : formatCNPJ(keyForm.holderDocument)}
                  onChange={e => {
                    const value = e.target.value.replace(/\D/g, '').slice(0, 14);
                    setKeyForm({...keyForm, holderDocument: value});
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none"
                  placeholder="000.000.000-00 ou 00.000.000/0001-00"
                  maxLength={18}
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Banco/Instituição (opcional)</label>
                <input value={keyForm.bank} onChange={e => setKeyForm({...keyForm, bank: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
              </div>
              <div className="flex items-center gap-2">
                <input type="checkbox" id="active" checked={keyForm.active} onChange={e => setKeyForm({...keyForm, active: e.target.checked})} className="w-4 h-4 text-purple-600" />
                <label htmlFor="active" className="text-sm text-gray-700">Chave ativa</label>
              </div>
            </div>
            <div className="p-6 border-t border-gray-100 flex justify-end gap-3">
              <button onClick={() => setShowKeyModal(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg text-sm font-medium">Cancelar</button>
              <button onClick={handleSaveKey} className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700">Salvar</button>
            </div>
          </div>
        </div>
      )}

      {/* Modal: Gerar Cobrança */}
      {showChargeModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-lg font-semibold">Gerar Cobrança Pix</h3>
              <button onClick={() => setShowChargeModal(false)}><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              {pixKeys.length === 0 ? (
                <div className="text-center py-4">
                  <AlertCircle className="w-10 h-10 text-orange-400 mx-auto mb-2" />
                  <p className="text-sm text-gray-600">Cadastre uma chave Pix primeiro</p>
                  <button onClick={() => { setShowChargeModal(false); openNewKey(); }} className="mt-3 px-4 py-2 bg-purple-600 text-white rounded-lg text-sm">
                    Cadastrar Chave
                  </button>
                </div>
              ) : (
                <>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Reserva (opcional)</label>
                    <select value={selectedReservationId} onChange={e => setSelectedReservationId(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none">
                      <option value="">Nenhuma (cobrança avulsa)</option>
                      {pendingReservations.map(r => (
                        <option key={r.id} value={r.id}>{r.codigo} - {r.passengers[0]?.nomeCompleto} - R$ {r.valorTotal.toFixed(2)}</option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Chave Pix *</label>
                    <select value={chargeForm.pixKeyId} onChange={e => setChargeForm({...chargeForm, pixKeyId: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none">
                      {pixKeys.filter(k => k.active).map(k => (
                        <option key={k.id} value={k.id}>
                          {k.isDefault ? '⭐ ' : ''}{getKeyTypeLabel(k.keyType)}: {maskPixKey(k.keyType, k.key)} - {k.agencyName}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Valor da Cobrança (R$) *</label>
                    <input type="number" step="0.01" min="0.01" value={chargeForm.amount || ''} onChange={e => setChargeForm({...chargeForm, amount: parseFloat(e.target.value) || 0})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none text-lg font-bold" />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Descrição</label>
                    <input value={chargeForm.description} onChange={e => setChargeForm({...chargeForm, description: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" placeholder="Identificação da cobrança" />
                  </div>
                </>
              )}
            </div>
            {pixKeys.length > 0 && (
              <div className="p-6 border-t border-gray-100 flex justify-end gap-3">
                <button onClick={() => setShowChargeModal(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg text-sm font-medium">Cancelar</button>
                <button onClick={handleGenerateCharge} className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700 flex items-center gap-2">
                  <QrCode className="w-4 h-4" /> Gerar Pix
                </button>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Modal: Detalhes da Cobrança / QR Code */}
      {detailCharge && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-lg font-semibold">Cobrança Pix</h3>
              <button onClick={() => { setShowChargeDetail(null); setGeneratedCharge(null); }}><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              {/* Valor */}
              <div className="text-center">
                <p className="text-3xl font-bold text-purple-700">R$ {detailCharge.amount.toFixed(2)}</p>
                <p className="text-sm text-gray-500 mt-1">{detailCharge.description}</p>
              </div>

              {/* QR Code */}
              <div className="flex justify-center">
                {detailCharge.qrCodeBase64 ? (
                  <div className="p-4 bg-white border-2 border-gray-200 rounded-xl">
                    <img src={detailCharge.qrCodeBase64} alt="QR Code Pix" className="w-56 h-56" />
                  </div>
                ) : (
                  <div className="w-56 h-56 bg-gray-100 border-2 border-dashed border-gray-300 rounded-xl flex items-center justify-center">
                    <QrCode className="w-16 h-16 text-gray-400" />
                  </div>
                )}
              </div>

              {/* Status */}
              <div className="flex justify-center">
                {getStatusBadge(detailCharge.status)}
              </div>

              {/* Informações */}
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-500">Reserva:</span>
                  <span className="font-medium text-gray-800">{detailCharge.reservationCode}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Passageiro:</span>
                  <span className="font-medium text-gray-800">{detailCharge.passengerName}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-500">Criado em:</span>
                  <span className="text-gray-700">{new Date(detailCharge.createdAt).toLocaleString('pt-BR')}</span>
                </div>
                {detailCharge.paidAt && (
                  <div className="flex justify-between">
                    <span className="text-gray-500">Pago em:</span>
                    <span className="text-green-600 font-medium">{new Date(detailCharge.paidAt).toLocaleString('pt-BR')}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span className="text-gray-500">Expira em:</span>
                  <span className="text-gray-700">{new Date(detailCharge.expiresAt).toLocaleString('pt-BR')}</span>
                </div>
              </div>

              {/* Pix Copia e Cola */}
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Pix Copia e Cola</label>
                <div className="flex gap-2">
                  <input readOnly value={detailCharge.pixCode} className="flex-1 px-3 py-2 bg-gray-50 border border-gray-200 rounded-lg text-xs font-mono text-gray-600" />
                  <button onClick={() => copyToClipboard(detailCharge.pixCode)} className={`px-3 py-2 rounded-lg flex items-center gap-1 text-sm font-medium transition ${copiedCode ? 'bg-green-100 text-green-700' : 'bg-purple-100 text-purple-700 hover:bg-purple-200'}`}>
                    {copiedCode ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
                    {copiedCode ? 'Copiado!' : 'Copiar'}
                  </button>
                </div>
              </div>

              {/* Chave utilizada */}
              {(() => {
                const key = pixKeys.find(k => k.id === detailCharge.pixKeyId);
                return key ? (
                  <div className="p-3 bg-gray-50 rounded-lg">
                    <p className="text-xs text-gray-500">Chave Pix utilizada</p>
                    <p className="text-sm font-medium text-gray-700">{getKeyTypeLabel(key.keyType)}: {maskPixKey(key.keyType, key.key)}</p>
                    <p className="text-xs text-gray-500">{key.agencyName} - {key.holderName}</p>
                  </div>
                ) : null;
              })()}



              {/* Actions */}
              <div className="flex gap-3">
                {detailCharge.status === 'pending' && (
                  <button onClick={() => handleSimulatePayment(detailCharge.id)} className="flex-1 px-4 py-2.5 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 flex items-center justify-center gap-2">
                    <CheckCircle className="w-4 h-4" /> Simular Pagamento
                  </button>
                )}
                <button onClick={() => {
                  const msg = encodeURIComponent(`💰 Cobrança Pix - R$ ${detailCharge.amount.toFixed(2)}\n\nReserva: ${detailCharge.reservationCode}\nPassageiro: ${detailCharge.passengerName}\n\nPix Copia e Cola:\n${detailCharge.pixCode}`);
                  window.open(`https://wa.me/?text=${msg}`, '_blank');
                }} className="flex-1 px-4 py-2.5 border border-gray-300 rounded-lg text-sm font-medium text-gray-700 hover:bg-gray-50 flex items-center justify-center gap-2">
                  <Send className="w-4 h-4" /> Compartilhar
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Floating Generate Button */}
      {!showChargeModal && !generatedCharge && (
        <button onClick={() => setShowChargeModal(true)} className="fixed bottom-6 right-6 w-14 h-14 bg-purple-600 text-white rounded-full shadow-lg hover:bg-purple-700 flex items-center justify-center transition-transform hover:scale-110 z-40">
          <Plus className="w-6 h-6" />
        </button>
      )}
    </div>
  );
}
