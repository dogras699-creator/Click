import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { BarChart3, Download, Calendar, Filter, TrendingUp, Users, DollarSign, Bus } from 'lucide-react';

export default function Reports() {
  const { reservations, trips, companies, users } = useData();
  const [dateFrom, setDateFrom] = useState('');
  const [dateTo, setDateTo] = useState('');
  const [companyFilter, setCompanyFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');

  const filtered = reservations.filter(r => {
    if (dateFrom && r.createdAt < dateFrom) return false;
    if (dateTo && r.createdAt > dateTo + 'T23:59:59') return false;
    if (companyFilter && r.companyId !== companyFilter) return false;
    if (statusFilter && r.status !== statusFilter) return false;
    return true;
  });

  const totalVendas = filtered.filter(r => r.paymentStatus === 'aprovado').reduce((s, r) => s + r.valorTotal, 0);
  const totalEmitidas = filtered.filter(r => r.status === 'emitida').length;
  const totalCanceladas = filtered.filter(r => r.status === 'cancelada').length;
  const totalReservas = filtered.length;

  // Top destinations
  const destCount: Record<string, number> = {};
  filtered.forEach(r => {
    const trip = trips.find(t => t.id === r.tripId);
    if (trip) destCount[trip.destino] = (destCount[trip.destino] || 0) + 1;
  });
  const topDestinos = Object.entries(destCount).sort((a, b) => b[1] - a[1]).slice(0, 5);

  // Top companies
  const compCount: Record<string, number> = {};
  filtered.forEach(r => {
    const comp = companies.find(c => c.id === r.companyId);
    if (comp) compCount[comp.nomeFantasia] = (compCount[comp.nomeFantasia] || 0) + 1;
  });
  const topEmpresas = Object.entries(compCount).sort((a, b) => b[1] - a[1]).slice(0, 5);

  // Attendant performance
  const attCount: Record<string, { count: number; total: number }> = {};
  filtered.forEach(r => {
    const user = users.find(u => u.id === r.atendenteId);
    if (user) {
      if (!attCount[user.name]) attCount[user.name] = { count: 0, total: 0 };
      attCount[user.name].count++;
      if (r.paymentStatus === 'aprovado') attCount[user.name].total += r.valorTotal;
    }
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-gray-800">Relatórios</h2>
          <p className="text-sm text-gray-500">Análise de vendas e desempenho</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
        <h3 className="font-medium text-gray-700 mb-3 flex items-center gap-2"><Filter className="w-4 h-4" /> Filtros</h3>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
          <div>
            <label className="block text-xs text-gray-500 mb-1">Data Início</label>
            <input type="date" value={dateFrom} onChange={e => setDateFrom(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none" />
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">Data Fim</label>
            <input type="date" value={dateTo} onChange={e => setDateTo(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none" />
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">Empresa</label>
            <select value={companyFilter} onChange={e => setCompanyFilter(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
              <option value="">Todas</option>
              {companies.map(c => <option key={c.id} value={c.id}>{c.nomeFantasia}</option>)}
            </select>
          </div>
          <div>
            <label className="block text-xs text-gray-500 mb-1">Status</label>
            <select value={statusFilter} onChange={e => setStatusFilter(e.target.value)} className="w-full px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 outline-none">
              <option value="">Todos</option>
              <option value="pendente">Pendente</option>
              <option value="paga">Paga</option>
              <option value="emitida">Emitida</option>
              <option value="cancelada">Cancelada</option>
            </select>
          </div>
        </div>
      </div>

      {/* Summary cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center"><DollarSign className="w-5 h-5 text-purple-600" /></div>
            <div>
              <p className="text-xl font-bold text-gray-800">R$ {totalVendas.toFixed(2)}</p>
              <p className="text-xs text-gray-500">Faturamento</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center"><BarChart3 className="w-5 h-5 text-blue-600" /></div>
            <div>
              <p className="text-xl font-bold text-gray-800">{totalReservas}</p>
              <p className="text-xs text-gray-500">Total Reservas</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center"><TrendingUp className="w-5 h-5 text-green-600" /></div>
            <div>
              <p className="text-xl font-bold text-gray-800">{totalEmitidas}</p>
              <p className="text-xs text-gray-500">Emitidas</p>
            </div>
          </div>
        </div>
        <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-red-100 rounded-lg flex items-center justify-center"><Users className="w-5 h-5 text-red-600" /></div>
            <div>
              <p className="text-xl font-bold text-gray-800">{totalCanceladas}</p>
              <p className="text-xs text-gray-500">Canceladas</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Top destinations */}
        <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
          <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2"><Bus className="w-4 h-4 text-purple-600" /> Destinos Mais Vendidos</h3>
          <div className="space-y-2">
            {topDestinos.map(([dest, count], i) => (
              <div key={dest} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 bg-purple-100 text-purple-700 rounded-full text-xs flex items-center justify-center font-bold">{i + 1}</span>
                  <span className="text-sm text-gray-700">{dest}</span>
                </div>
                <span className="text-sm font-medium text-gray-800">{count}</span>
              </div>
            ))}
            {topDestinos.length === 0 && <p className="text-sm text-gray-400">Sem dados</p>}
          </div>
        </div>

        {/* Top companies */}
        <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
          <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2"><Bus className="w-4 h-4 text-blue-600" /> Empresas Mais Vendidas</h3>
          <div className="space-y-2">
            {topEmpresas.map(([name, count], i) => (
              <div key={name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-5 bg-blue-100 text-blue-700 rounded-full text-xs flex items-center justify-center font-bold">{i + 1}</span>
                  <span className="text-sm text-gray-700">{name}</span>
                </div>
                <span className="text-sm font-medium text-gray-800">{count}</span>
              </div>
            ))}
            {topEmpresas.length === 0 && <p className="text-sm text-gray-400">Sem dados</p>}
          </div>
        </div>

        {/* Attendant performance */}
        <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
          <h3 className="font-semibold text-gray-800 mb-3 flex items-center gap-2"><Users className="w-4 h-4 text-green-600" /> Desempenho dos Atendentes</h3>
          <div className="space-y-3">
            {Object.entries(attCount).map(([name, data]) => (
              <div key={name} className="p-2 bg-gray-50 rounded-lg">
                <p className="text-sm font-medium text-gray-700">{name}</p>
                <div className="flex justify-between text-xs text-gray-500 mt-1">
                  <span>{data.count} reservas</span>
                  <span className="text-green-600 font-medium">R$ {data.total.toFixed(2)}</span>
                </div>
                <div className="mt-1 h-1.5 bg-gray-200 rounded-full overflow-hidden">
                  <div className="h-full bg-green-500 rounded-full" style={{ width: `${Math.min(100, (data.total / Math.max(totalVendas, 1)) * 100)}%` }} />
                </div>
              </div>
            ))}
            {Object.keys(attCount).length === 0 && <p className="text-sm text-gray-400">Sem dados</p>}
          </div>
        </div>
      </div>

      {/* Export */}
      <div className="flex justify-end gap-3">
        <button className="px-4 py-2 border border-gray-300 rounded-lg text-sm font-medium text-gray-600 hover:bg-gray-50 flex items-center gap-2">
          <Download className="w-4 h-4" /> Exportar PDF
        </button>
        <button className="px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 flex items-center gap-2">
          <Download className="w-4 h-4" /> Exportar Excel
        </button>
      </div>
    </div>
  );
}
