import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { Reservation } from '../types';
import { Search, Eye, X, Edit2, Ban, FileText, Clock, CheckCircle, XCircle, AlertCircle, Trash2, CheckSquare, Square, Filter, Download, Send } from 'lucide-react';

export default function Reservations() {
  const { reservations, trips, companies, users, updateReservation, currentUser, addLog } = useData();
  const [filter, setFilter] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [selectedRes, setSelectedRes] = useState<Reservation | null>(null);
  const [showDetail, setShowDetail] = useState(false);
  const [selectedReservations, setSelectedReservations] = useState<string[]>([]);
  const [showConfirmModal, setShowConfirmModal] = useState<{ show: boolean; action: string; reservations: string[] }>({ show: false, action: '', reservations: [] });

  const filtered = reservations.filter(r => {
    const matchStatus = !statusFilter || r.status === statusFilter;
    const matchText = !filter || r.codigo.toLowerCase().includes(filter.toLowerCase()) ||
      r.passengers.some(p => p.nomeCompleto.toLowerCase().includes(filter.toLowerCase())) ||
      r.localizador.toLowerCase().includes(filter.toLowerCase());
    return matchStatus && matchText;
  });

  // Seleção de reservas
  const toggleSelectReservation = (id: string) => {
    setSelectedReservations(prev => 
      prev.includes(id) ? prev.filter(r => r !== id) : [...prev, id]
    );
  };

  const toggleSelectAll = () => {
    if (selectedReservations.length === filtered.length) {
      setSelectedReservations([]);
    } else {
      setSelectedReservations(filtered.map(r => r.id));
    }
  };

  // Ações individuais
  const handleCancel = (r: Reservation) => {
    setShowConfirmModal({ show: true, action: 'cancel', reservations: [r.id] });
  };

  const handleApprovePayment = (r: Reservation) => {
    setShowConfirmModal({ show: true, action: 'approve', reservations: [r.id] });
  };

  const handleEmit = (r: Reservation) => {
    updateReservation({ ...r, status: 'emitida', updatedAt: new Date().toISOString(), history: [...r.history, { date: new Date().toISOString(), action: 'Bilhete emitido', user: currentUser?.name || '' }] });
    addLog('Bilhete emitido', r.codigo);
  };

  const handleDelete = (r: Reservation) => {
    setShowConfirmModal({ show: true, action: 'delete', reservations: [r.id] });
  };

  // Ações em lote
  const handleBatchApprove = () => {
    setShowConfirmModal({ show: true, action: 'approve', reservations: selectedReservations });
  };

  const handleBatchCancel = () => {
    setShowConfirmModal({ show: true, action: 'cancel', reservations: selectedReservations });
  };

  // Confirmar ação
  const confirmAction = () => {
    const { action, reservations: resIds } = showConfirmModal;
    
    resIds.forEach(resId => {
      const r = reservations.find(res => res.id === resId);
      if (!r) return;

      if (action === 'cancel') {
        updateReservation({ 
          ...r, 
          status: 'cancelada', 
          updatedAt: new Date().toISOString(), 
          history: [...r.history, { date: new Date().toISOString(), action: 'Reserva cancelada', user: currentUser?.name || '' }] 
        });
        addLog('Reserva cancelada', r.codigo);
      } else if (action === 'approve') {
        updateReservation({ 
          ...r, 
          paymentStatus: 'aprovado', 
          status: 'paga', 
          updatedAt: new Date().toISOString(), 
          history: [...r.history, { date: new Date().toISOString(), action: 'Pagamento aprovado', user: currentUser?.name || '' }]
        });
        addLog('Pagamento aprovado', r.codigo);
      } else if (action === 'delete') {
        updateReservation({ 
          ...r, 
          status: 'cancelada', 
          updatedAt: new Date().toISOString(), 
          history: [...r.history, { date: new Date().toISOString(), action: 'Reserva removida', user: currentUser?.name || '' }] 
        });
        addLog('Reserva removida', r.codigo);
      }
    });

    setSelectedReservations([]);
    setShowConfirmModal({ show: false, action: '', reservations: [] });
  };

  const getStatusBadge = (status: string) => {
    const map: Record<string, { bg: string; text: string; label: string; icon: any }> = {
      pendente: { bg: 'bg-yellow-100', text: 'text-yellow-700', label: 'Pendente', icon: Clock },
      confirmada: { bg: 'bg-blue-100', text: 'text-blue-700', label: 'Confirmada', icon: CheckCircle },
      paga: { bg: 'bg-indigo-100', text: 'text-indigo-700', label: 'Paga', icon: CheckCircle },
      emitida: { bg: 'bg-green-100', text: 'text-green-700', label: 'Emitida', icon: FileText },
      cancelada: { bg: 'bg-red-100', text: 'text-red-700', label: 'Cancelada', icon: XCircle },
    };
    const s = map[status] || map.pendente;
    const Icon = s.icon;
    return (
      <span className={`inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium ${s.bg} ${s.text}`}>
        <Icon className="w-3 h-3" />
        {s.label}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Gerenciar Reservas</h2>
          <p className="text-sm text-gray-500 mt-1">{reservations.length} reservas no sistema</p>
        </div>
      </div>

      {/* Filters */}
      <div className="bg-white rounded-xl border border-gray-100 p-4 shadow-sm">
        <div className="flex items-center gap-2 mb-3">
          <Filter className="w-4 h-4 text-gray-500" />
          <span className="text-sm font-medium text-gray-700">Filtros</span>
        </div>
        <div className="flex flex-col sm:flex-row gap-3">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input 
              value={filter} 
              onChange={e => setFilter(e.target.value)} 
              placeholder="Buscar por código, passageiro ou localizador..." 
              className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" 
            />
          </div>
          <select 
            value={statusFilter} 
            onChange={e => setStatusFilter(e.target.value)} 
            className="px-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none"
          >
            <option value="">Todos os status</option>
            <option value="pendente">Pendente</option>
            <option value="paga">Paga</option>
            <option value="emitida">Emitida</option>
            <option value="cancelada">Cancelada</option>
          </select>
        </div>
      </div>

      {/* Batch Actions Bar */}
      {selectedReservations.length > 0 && (
        <div className="bg-purple-50 border border-purple-200 rounded-xl p-4 shadow-sm">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <CheckSquare className="w-5 h-5 text-purple-600" />
              <span className="text-sm font-medium text-purple-900">
                {selectedReservations.length} reserva(s) selecionada(s)
              </span>
            </div>
            <div className="flex flex-wrap gap-2">
              <button 
                onClick={handleBatchApprove}
                className="px-4 py-2 bg-green-600 text-white rounded-lg text-sm font-medium hover:bg-green-700 transition flex items-center gap-2"
              >
                <CheckCircle className="w-4 h-4" />
                Aprovar Selecionadas
              </button>
              <button 
                onClick={handleBatchCancel}
                className="px-4 py-2 bg-red-600 text-white rounded-lg text-sm font-medium hover:bg-red-700 transition flex items-center gap-2"
              >
                <Ban className="w-4 h-4" />
                Cancelar Selecionadas
              </button>
              <button 
                onClick={() => setSelectedReservations([])}
                className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg text-sm font-medium hover:bg-gray-300 transition"
              >
                Limpar Seleção
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Table */}
      <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-left">
                  <input 
                    type="checkbox" 
                    checked={filtered.length > 0 && selectedReservations.length === filtered.length}
                    onChange={toggleSelectAll}
                    className="w-4 h-4 text-purple-600 rounded focus:ring-2 focus:ring-purple-500"
                  />
                </th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Código</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Passageiro</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Viagem</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Data</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Valor</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Pagamento</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map(r => {
                const trip = trips.find(t => t.id === r.tripId);
                const isSelected = selectedReservations.includes(r.id);
                return (
                  <tr key={r.id} className={`transition-colors ${isSelected ? 'bg-purple-50' : 'hover:bg-gray-50'}`}>
                    <td className="px-4 py-3">
                      <input 
                        type="checkbox" 
                        checked={isSelected}
                        onChange={() => toggleSelectReservation(r.id)}
                        className="w-4 h-4 text-purple-600 rounded focus:ring-2 focus:ring-purple-500"
                      />
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm font-semibold text-gray-800">{r.codigo}</p>
                      <p className="text-xs text-gray-500 font-mono">{r.localizador}</p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm font-medium text-gray-700">{r.passengers[0]?.nomeCompleto}</p>
                      <p className="text-xs text-gray-500">{r.passengers.length} passageiro(s)</p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm text-gray-700">{trip ? `${trip.origem.split(' - ')[0]} → ${trip.destino.split(' - ')[0]}` : '-'}</p>
                      <p className="text-xs text-gray-500">{trip?.linha || '-'}</p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm text-gray-700">{trip?.dataSaida || '-'}</p>
                      <p className="text-xs text-gray-500">{trip?.horarioSaida || '-'}</p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm font-bold text-gray-800">R$ {r.valorTotal.toFixed(2)}</p>
                    </td>
                    <td className="px-4 py-3">{getStatusBadge(r.status)}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center gap-1 text-xs font-medium ${
                        r.paymentStatus === 'aprovado' ? 'text-green-600' : 
                        r.paymentStatus === 'aguardando' ? 'text-yellow-600' : 
                        'text-red-600'
                      }`}>
                        {r.paymentStatus === 'aprovado' && <CheckCircle className="w-3 h-3" />}
                        {r.paymentStatus === 'aguardando' && <Clock className="w-3 h-3" />}
                        {r.paymentStatus === 'aprovado' ? 'Aprovado' : r.paymentStatus === 'aguardando' ? 'Aguardando' : r.paymentStatus}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        {/* Visualizar */}
                        <button 
                          onClick={() => { setSelectedRes(r); setShowDetail(true); }} 
                          className="p-2 hover:bg-blue-50 rounded-lg transition-colors group" 
                          title="Visualizar reserva"
                        >
                          <Eye className="w-4 h-4 text-gray-400 group-hover:text-blue-600" />
                        </button>

                        {/* Aprovar Pagamento */}
                        {r.status === 'pendente' && r.paymentStatus === 'aguardando' && (
                          <button 
                            onClick={() => handleApprovePayment(r)} 
                            className="p-2 hover:bg-green-50 rounded-lg transition-colors group" 
                            title="Aprovar pagamento"
                          >
                            <CheckCircle className="w-4 h-4 text-gray-400 group-hover:text-green-600" />
                          </button>
                        )}

                        {/* Emitir Bilhete */}
                        {r.status === 'paga' && (
                          <button 
                            onClick={() => handleEmit(r)} 
                            className="p-2 hover:bg-indigo-50 rounded-lg transition-colors group" 
                            title="Emitir bilhete"
                          >
                            <FileText className="w-4 h-4 text-gray-400 group-hover:text-indigo-600" />
                          </button>
                        )}

                        {/* Cancelar/Remover */}
                        {r.status !== 'cancelada' && (
                          <button 
                            onClick={() => handleCancel(r)} 
                            className="p-2 hover:bg-red-50 rounded-lg transition-colors group" 
                            title="Cancelar reserva"
                          >
                            <Ban className="w-4 h-4 text-gray-400 group-hover:text-red-600" />
                          </button>
                        )}

                        {/* Remover (apenas canceladas) */}
                        {r.status === 'cancelada' && (
                          <button 
                            onClick={() => handleDelete(r)} 
                            className="p-2 hover:bg-red-50 rounded-lg transition-colors group" 
                            title="Remover reserva"
                          >
                            <Trash2 className="w-4 h-4 text-gray-400 group-hover:text-red-600" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {filtered.length === 0 && (
                <tr>
                  <td colSpan={9} className="px-4 py-12 text-center">
                    <div className="flex flex-col items-center gap-2">
                      <Search className="w-12 h-12 text-gray-300" />
                      <p className="text-gray-500 font-medium">Nenhuma reserva encontrada</p>
                      <p className="text-sm text-gray-400">Tente ajustar os filtros de busca</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      {showDetail && selectedRes && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between sticky top-0 bg-white z-10">
              <h3 className="text-lg font-semibold">Detalhes da Reserva</h3>
              <button onClick={() => setShowDetail(false)}><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500">Código</p>
                  <p className="font-medium text-gray-800">{selectedRes.codigo}</p>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500">Localizador</p>
                  <p className="font-medium text-gray-800">{selectedRes.localizador}</p>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500">Status</p>
                  <div className="mt-1">{getStatusBadge(selectedRes.status)}</div>
                </div>
                <div className="p-3 bg-gray-50 rounded-lg">
                  <p className="text-xs text-gray-500">Pagamento</p>
                  <p className="font-medium text-gray-800">{selectedRes.paymentMethod} - {selectedRes.paymentStatus}</p>
                </div>
              </div>

              <div className="p-3 bg-purple-50 rounded-lg">
                <p className="text-xs text-purple-600 mb-1">Viagem</p>
                {(() => { const trip = trips.find(t => t.id === selectedRes.tripId); const company = companies.find(c => c.id === selectedRes.companyId); return trip ? (
                  <div className="text-sm text-purple-800">
                    <p className="font-medium">{trip.nome}</p>
                    <p>{company?.nomeFantasia} - {trip.origem} → {trip.destino}</p>
                    <p>{trip.dataSaida} às {trip.horarioSaida} | Classe: {trip.classe}</p>
                    <p>Linha: {trip.linha} | Plataforma: {trip.plataforma}</p>
                  </div>
                ) : null; })()}
              </div>

              <div>
                <h4 className="font-medium text-gray-700 mb-2">Passageiros</h4>
                {selectedRes.passengers.map((p, i) => (
                  <div key={i} className="p-3 border border-gray-200 rounded-lg mb-2">
                    <p className="font-medium text-gray-800">{p.nomeCompleto}</p>
                    <p className="text-sm text-gray-600">CPF: {p.cpf} | Poltrona: {p.poltrona}</p>
                    <p className="text-sm text-gray-600">Tel: {p.telefone} | Email: {p.email}</p>
                  </div>
                ))}
              </div>

              <div className="p-3 bg-gray-50 rounded-lg">
                <h4 className="font-medium text-gray-700 mb-2">Valores</h4>
                <div className="text-sm space-y-1">
                  <div className="flex justify-between"><span>Tarifa:</span><span>R$ {selectedRes.tarifa.toFixed(2)}</span></div>
                  <div className="flex justify-between"><span>Pedágio:</span><span>R$ {selectedRes.pedagio.toFixed(2)}</span></div>
                  <div className="flex justify-between"><span>Taxa Embarque:</span><span>R$ {selectedRes.taxaEmbarque.toFixed(2)}</span></div>
                  <div className="flex justify-between"><span>Seguro:</span><span>R$ {selectedRes.seguro.toFixed(2)}</span></div>
                  <div className="flex justify-between font-bold border-t pt-1 mt-1"><span>Total:</span><span className="text-purple-700">R$ {selectedRes.valorTotal.toFixed(2)}</span></div>
                </div>
              </div>

              {selectedRes.observacoes && (
                <div className="p-3 bg-yellow-50 rounded-lg">
                  <p className="text-xs text-yellow-700 font-medium">Observações</p>
                  <p className="text-sm text-yellow-800">{selectedRes.observacoes}</p>
                </div>
              )}

              <div>
                <h4 className="font-medium text-gray-700 mb-2">Histórico</h4>
                <div className="space-y-2">
                  {selectedRes.history.map((h, i) => (
                    <div key={i} className="flex items-center gap-2 text-sm">
                      <Clock className="w-3.5 h-3.5 text-gray-400" />
                      <span className="text-gray-500">{new Date(h.date).toLocaleString('pt-BR')}</span>
                      <span className="text-gray-700">{h.action}</span>
                      <span className="text-gray-400">({h.user})</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-gray-100 flex justify-end gap-3">
              <button onClick={() => setShowDetail(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg text-sm font-medium">Fechar</button>
            </div>
          </div>
        </div>
      )}

      {/* Confirmation Modal */}
      {showConfirmModal.show && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md">
            <div className="p-6 border-b border-gray-100">
              <div className="flex items-center gap-3">
                {showConfirmModal.action === 'approve' && (
                  <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                    <CheckCircle className="w-6 h-6 text-green-600" />
                  </div>
                )}
                {showConfirmModal.action === 'cancel' && (
                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                    <Ban className="w-6 h-6 text-red-600" />
                  </div>
                )}
                {showConfirmModal.action === 'delete' && (
                  <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                    <Trash2 className="w-6 h-6 text-red-600" />
                  </div>
                )}
                <div>
                  <h3 className="text-lg font-semibold text-gray-800">
                    {showConfirmModal.action === 'approve' && 'Aprovar Pagamento'}
                    {showConfirmModal.action === 'cancel' && 'Cancelar Reserva'}
                    {showConfirmModal.action === 'delete' && 'Remover Reserva'}
                  </h3>
                  <p className="text-sm text-gray-500">
                    {showConfirmModal.reservations.length} reserva(s) selecionada(s)
                  </p>
                </div>
              </div>
            </div>
            <div className="p-6">
              <p className="text-sm text-gray-700 mb-4">
                {showConfirmModal.action === 'approve' && 'Deseja aprovar o pagamento desta(s) reserva(s)? Esta ação não pode ser desfeita.'}
                {showConfirmModal.action === 'cancel' && 'Deseja cancelar esta(s) reserva(s)? Esta ação não pode ser desfeita.'}
                {showConfirmModal.action === 'delete' && 'Deseja remover permanentemente esta(s) reserva(s)? Esta ação não pode ser desfeita.'}
              </p>
              <div className="p-3 bg-yellow-50 border border-yellow-200 rounded-lg">
                <p className="text-xs text-yellow-700">
                  <strong>Atenção:</strong> Esta ação será registrada no histórico do sistema.
                </p>
              </div>
            </div>
            <div className="p-6 border-t border-gray-100 flex justify-end gap-3">
              <button 
                onClick={() => setShowConfirmModal({ show: false, action: '', reservations: [] })} 
                className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg text-sm font-medium"
              >
                Cancelar
              </button>
              <button 
                onClick={confirmAction}
                className={`px-4 py-2 rounded-lg text-sm font-medium text-white ${
                  showConfirmModal.action === 'approve' ? 'bg-green-600 hover:bg-green-700' :
                  showConfirmModal.action === 'cancel' ? 'bg-red-600 hover:bg-red-700' :
                  'bg-red-600 hover:bg-red-700'
                }`}
              >
                {showConfirmModal.action === 'approve' && 'Aprovar'}
                {showConfirmModal.action === 'cancel' && 'Cancelar Reserva'}
                {showConfirmModal.action === 'delete' && 'Remover'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
