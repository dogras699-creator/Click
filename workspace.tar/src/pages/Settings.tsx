import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { User } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { Settings, Save, Users, Plus, X, Edit2, Building2, Shield } from 'lucide-react';
import { formatPhone, formatCNPJ, formatSAC } from '../utils/masks';

export default function SettingsPage() {
  const { settings, updateSettings, users, addUser, updateUser, currentUser, addLog } = useData();
  const [form, setForm] = useState(settings);
  const [saved, setSaved] = useState(false);
  const [showUserModal, setShowUserModal] = useState(false);
  const [editingUser, setEditingUser] = useState<User | null>(null);
  const [userForm, setUserForm] = useState({ name: '', email: '', password: '', role: 'attendant' as 'admin' | 'attendant' });

  const isAdmin = currentUser?.role === 'admin';

  const handleSave = () => {
    updateSettings(form);
    addLog('Configurações atualizadas', form.nome);
    setSaved(true);
    setTimeout(() => setSaved(false), 3000);
  };

  const handleSaveUser = () => {
    if (!userForm.name || !userForm.email || !userForm.password) return;
    if (editingUser) {
      updateUser({ ...editingUser, ...userForm });
      addLog('Usuário atualizado', userForm.name);
    } else {
      addUser({ id: uuidv4(), ...userForm, active: true, createdAt: new Date().toISOString() });
      addLog('Usuário cadastrado', userForm.name);
    }
    setShowUserModal(false);
    setEditingUser(null);
    setUserForm({ name: '', email: '', password: '', role: 'attendant' });
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-800">Configurações</h2>
        <p className="text-sm text-gray-500">Gerencie as configurações do sistema</p>
      </div>

      {saved && (
        <div className="p-3 bg-green-50 border border-green-200 rounded-lg text-sm text-green-700">
          ✓ Configurações salvas com sucesso!
        </div>
      )}

      {/* Agency settings */}
      <div className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm">
        <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <Building2 className="w-5 h-5 text-purple-600" /> Dados da Agência
        </h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Nome do Sistema</label>
            <input value={form.nome} onChange={e => setForm({...form, nome: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Razão Social</label>
            <input value={form.razaoSocial} onChange={e => setForm({...form, razaoSocial: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">CNPJ</label>
            <input 
              value={form.cnpj} 
              onChange={e => setForm({...form, cnpj: formatCNPJ(e.target.value)})} 
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none"
              placeholder="00.000.000/0001-00"
              maxLength={18}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Telefone</label>
            <input 
              value={form.telefone} 
              onChange={e => setForm({...form, telefone: formatPhone(e.target.value)})} 
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none"
              placeholder="(11) 99999-9999"
              maxLength={15}
            />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">E-mail</label>
            <input type="email" value={form.email} onChange={e => setForm({...form, email: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">SAC</label>
            <input 
              value={form.sac} 
              onChange={e => setForm({...form, sac: formatSAC(e.target.value)})} 
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none"
              placeholder="0800 123 4567 ou (11) 99999-9999"
              maxLength={15}
            />
          </div>
          <div className="md:col-span-2">
            <label className="block text-sm font-medium text-gray-700 mb-1">Endereço</label>
            <input value={form.endereco} onChange={e => setForm({...form, endereco: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">Horário de Funcionamento</label>
            <input value={form.horarioFuncionamento} onChange={e => setForm({...form, horarioFuncionamento: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
          </div>
        </div>
        <button onClick={handleSave} className="mt-4 px-6 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700 flex items-center gap-2">
          <Save className="w-4 h-4" /> Salvar Configurações
        </button>
      </div>

      {/* User management */}
      {isAdmin && (
        <div className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm">
          <div className="flex items-center justify-between mb-4">
            <h3 className="font-semibold text-gray-800 flex items-center gap-2">
              <Users className="w-5 h-5 text-purple-600" /> Usuários do Sistema
            </h3>
            <button onClick={() => { setEditingUser(null); setUserForm({ name: '', email: '', password: '', role: 'attendant' }); setShowUserModal(true); }} className="px-3 py-1.5 bg-purple-600 text-white rounded-lg text-sm flex items-center gap-1">
              <Plus className="w-3.5 h-3.5" /> Novo Usuário
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50">
                <tr>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Nome</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">E-mail</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Perfil</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                  <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-100">
                {users.map(u => (
                  <tr key={u.id} className="hover:bg-gray-50">
                    <td className="px-4 py-2 text-sm font-medium text-gray-800">{u.name}</td>
                    <td className="px-4 py-2 text-sm text-gray-600">{u.email}</td>
                    <td className="px-4 py-2"><span className={`px-2 py-0.5 rounded-full text-xs font-medium ${u.role === 'admin' ? 'bg-purple-100 text-purple-700' : 'bg-blue-100 text-blue-700'}`}>{u.role === 'admin' ? 'Administrador' : 'Atendente'}</span></td>
                    <td className="px-4 py-2"><span className={`px-2 py-0.5 rounded-full text-xs ${u.active ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{u.active ? 'Ativo' : 'Inativo'}</span></td>
                    <td className="px-4 py-2">
                      <button onClick={() => { setEditingUser(u); setUserForm({ name: u.name, email: u.email, password: u.password, role: u.role }); setShowUserModal(true); }} className="p-1 hover:bg-gray-100 rounded">
                        <Edit2 className="w-3.5 h-3.5 text-gray-500" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* System info */}
      <div className="bg-white rounded-xl border border-gray-100 p-6 shadow-sm">
        <h3 className="font-semibold text-gray-800 mb-4 flex items-center gap-2">
          <Shield className="w-5 h-5 text-purple-600" /> Informações do Sistema
        </h3>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div className="p-3 bg-gray-50 rounded-lg">
            <p className="text-gray-500">Versão</p>
            <p className="font-medium text-gray-800">1.0.0</p>
          </div>
          <div className="p-3 bg-gray-50 rounded-lg">
            <p className="text-gray-500">Ambiente</p>
            <p className="font-medium text-green-600">Produção</p>
          </div>
          <div className="p-3 bg-gray-50 rounded-lg">
            <p className="text-gray-500">Armazenamento</p>
            <p className="font-medium text-gray-800">LocalStorage</p>
          </div>
          <div className="p-3 bg-gray-50 rounded-lg">
            <p className="text-gray-500">LGPD</p>
            <p className="font-medium text-green-600">Conforme</p>
          </div>
        </div>
      </div>

      {/* User modal */}
      {showUserModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-md">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between">
              <h3 className="text-lg font-semibold">{editingUser ? 'Editar Usuário' : 'Novo Usuário'}</h3>
              <button onClick={() => setShowUserModal(false)}><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Nome</label>
                <input value={userForm.name} onChange={e => setUserForm({...userForm, name: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">E-mail</label>
                <input type="email" value={userForm.email} onChange={e => setUserForm({...userForm, email: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Senha</label>
                <input type="password" value={userForm.password} onChange={e => setUserForm({...userForm, password: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Perfil</label>
                <select value={userForm.role} onChange={e => setUserForm({...userForm, role: e.target.value as 'admin' | 'attendant'})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none">
                  <option value="attendant">Atendente</option>
                  <option value="admin">Administrador</option>
                </select>
              </div>
            </div>
            <div className="p-6 border-t border-gray-100 flex justify-end gap-3">
              <button onClick={() => setShowUserModal(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg text-sm">Cancelar</button>
              <button onClick={handleSaveUser} className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700">Salvar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
