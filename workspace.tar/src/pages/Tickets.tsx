import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { generateTicketNumber } from '../demoData';
import { FileText, Download, Printer, Eye, X, QrCode, Send, Bus, MapPin, Clock, User, CreditCard, Lock, CheckCircle } from 'lucide-react';
import jsPDF from 'jspdf';
import * as QRCode from 'qrcode';

export default function Tickets() {
  const { reservations, trips, companies, settings, updateReservation, currentUser, addLog } = useData();
  const [previewRes, setPreviewRes] = useState<string | null>(null);
  const [showPreview, setShowPreview] = useState(false);
  const [sendingWhatsApp, setSendingWhatsApp] = useState<string | null>(null);

  const eligibleReservations = reservations.filter(r => r.status === 'paga' || r.status === 'emitida');
  const previewReservation = reservations.find(r => r.id === previewRes);

  const generatePDF = async (resId: string) => {
    const res = reservations.find(r => r.id === resId);
    if (!res) return;
    const trip = trips.find(t => t.id === res.tripId);
    const company = companies.find(c => c.id === res.companyId);
    if (!trip || !company) return;

    const doc = new jsPDF('p', 'mm', 'a4');
    const ticketNum = res.ticketCode || generateTicketNumber();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const authCode = `AUTH${Date.now().toString(36).toUpperCase().slice(-8)}`;

    // Gerar QR Code real baseado no código do bilhete (único e permanente)
    const qrCodeData = `BPE:${ticketNum}|RES:${res.codigo}|LOC:${res.localizador}|PAS:${res.passengers[0]?.cpf}|VAL:${res.valorTotal}`;
    const qrCodeBase64 = await QRCode.toDataURL(qrCodeData, {
      width: 300,
      margin: 1,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      },
      errorCorrectionLevel: 'M'
    });

    // Helper para desenhar QR Code real
    const drawQRCode = (x: number, y: number, size: number) => {
      try {
        doc.addImage(qrCodeBase64, 'PNG', x, y, size, size);
      } catch (e) {
        console.warn('Erro ao adicionar QR Code ao PDF');
      }
    };

    // Helper para desenhar código de barras (Code 128 simulado)
    const drawBarcode = (x: number, y: number, width: number, height: number, code: string) => {
      doc.setFillColor(255, 255, 255);
      doc.rect(x, y, width, height + 5, 'F');
      doc.setFillColor(0, 0, 0);
      let cursor = x;
      const barWidth = width / 60;
      for (let i = 0; i < 60; i++) {
        const charCode = code.charCodeAt(i % code.length);
        const isBar = (charCode + i) % 2 === 0;
        if (isBar) {
          const w = ((charCode % 3) + 1) * barWidth * 0.5;
          doc.rect(cursor, y, w, height, 'F');
          cursor += w;
        } else {
          cursor += barWidth * 0.5;
        }
        if (cursor > x + width) break;
      }
    };

    // Helper para marca d'água diagonal (removido)
    const drawWatermark = () => {
      // Marca d'água desativada
    };

    // ===== FUNÇÃO PARA DESENHAR UMA VIA DO BILHETE =====
    const drawTicketPage = (startY: number, isPassenger: boolean) => {
      let y = startY;
      const margin = 10;
      const contentWidth = pageWidth - (margin * 2);

      // ===== CABEÇALHO ROXO =====
      doc.setFillColor(124, 58, 237); // Roxo principal
      doc.rect(0, y - 5, pageWidth, 30, 'F');
      
      // Logo da empresa (se existir)
      if (company.logo) {
        try {
          // Verificar se é uma imagem válida antes de adicionar
          if (company.logo.startsWith('data:image/')) {
            const imgFormat = company.logo.includes('image/png') ? 'PNG' : 'JPEG';
            doc.addImage(company.logo, imgFormat, pageWidth - margin - 20, y, 20, 20);
          }
        } catch (e) {
          // Se falhar, continua sem o logo
          console.warn('Logo não pôde ser adicionado ao PDF');
        }
      }
      
      // Logo/Título da agência
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text(settings.nome.toUpperCase(), margin, y + 5);
      
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.text(`CNPJ: ${settings.cnpj}`, margin, y + 11);
      doc.text(`SAC: ${settings.sac}`, margin, y + 16);
      
      // Número do bilhete e tipo de via
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text(isPassenger ? 'VIA DO PASSAGEIRO' : 'VIA DO MOTORISTA', pageWidth - margin, y + 5, { align: 'right' });
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.text(`Bilhete nº ${ticketNum}`, pageWidth - margin, y + 11, { align: 'right' });
      doc.text(`Autorização: ${authCode}`, pageWidth - margin, y + 16, { align: 'right' });
      
      y += 30;

      // ===== BOX ORIGEM → DESTINO (destaque principal) =====
      doc.setFillColor(245, 243, 255); // Roxo claro
      doc.rect(margin, y, contentWidth, 28, 'F');
      doc.setDrawColor(124, 58, 237);
      doc.setLineWidth(0.5);
      doc.rect(margin, y, contentWidth, 28, 'S');
      
      doc.setTextColor(124, 58, 237);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text('ORIGEM', margin + 5, y + 6);
      doc.text('DESTINO', margin + contentWidth / 2 + 5, y + 6);
      
      doc.setFontSize(12);
      doc.setTextColor(30, 30, 30);
      doc.text(trip.origem.substring(0, 25), margin + 5, y + 14);
      doc.text(trip.destino.substring(0, 25), margin + contentWidth / 2 + 5, y + 14);
      
      // Seta no meio
      doc.setTextColor(124, 58, 237);
      doc.setFontSize(16);
      doc.text('→', pageWidth / 2 - 3, y + 15);
      
      doc.setFontSize(8);
      doc.setTextColor(100, 100, 100);
      doc.text(`Data: ${trip.dataSaida}`, margin + 5, y + 22);
      doc.text(`Horário: ${trip.horarioSaida}`, margin + 50, y + 22);
      doc.text(`Duração: ${trip.duracao}`, margin + contentWidth / 2 + 5, y + 22);
      doc.text(`Classe: ${trip.classe.toUpperCase()}`, margin + contentWidth / 2 + 50, y + 22);
      
      y += 32;

      // ===== GRID DE INFORMAÇÕES =====
      // Linha 1: Dados da Viação e Serviço
      doc.setFillColor(250, 250, 252);
      doc.rect(margin, y, contentWidth, 22, 'F');
      doc.setDrawColor(220, 220, 230);
      doc.setLineWidth(0.3);
      doc.rect(margin, y, contentWidth, 22, 'S');
      
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text('VIAÇÃO', margin + 3, y + 4);
      doc.text('LINHA', margin + 60, y + 4);
      doc.text('PREFIXO', margin + 100, y + 4);
      doc.text('PLATAFORMA', margin + 140, y + 4);
      
      doc.setTextColor(30, 30, 30);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.text(company.nomeFantasia.substring(0, 30), margin + 3, y + 10);
      doc.text(trip.linha, margin + 60, y + 10);
      doc.text(trip.prefixo, margin + 100, y + 10);
      doc.text(trip.plataforma, margin + 140, y + 10);
      
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(7);
      doc.text('Nº SERVIÇO', margin + 3, y + 15);
      doc.text('LOCAL EMBARQUE', margin + 60, y + 15);
      
      doc.setTextColor(30, 30, 30);
      doc.setFontSize(8);
      doc.text(trip.numeroServico, margin + 3, y + 19);
      doc.text(trip.localEmbarque.substring(0, 45), margin + 60, y + 19);
      
      y += 25;

      // Linha 2: Passageiro e Poltrona (destaque)
      doc.setFillColor(255, 255, 255);
      doc.rect(margin, y, contentWidth, 20, 'F');
      doc.setDrawColor(220, 220, 230);
      doc.rect(margin, y, contentWidth, 20, 'S');
      
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text('PASSAGEIRO', margin + 3, y + 4);
      doc.text('CPF/DOCUMENTO', margin + 100, y + 4);
      doc.text('POLTRONA', margin + 150, y + 4);
      
      doc.setTextColor(30, 30, 30);
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text(res.passengers[0]?.nomeCompleto.substring(0, 40) || '', margin + 3, y + 12);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.text(res.passengers[0]?.cpf || '', margin + 100, y + 12);
      
      // Poltrona em destaque
      doc.setFillColor(124, 58, 237);
      doc.rect(margin + 148, y + 6, 15, 10, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text(res.passengers[0]?.poltrona || '', margin + 155.5, y + 13, { align: 'center' });
      
      y += 23;

      // Linha 3: Horários detalhados
      doc.setFillColor(250, 250, 252);
      doc.rect(margin, y, contentWidth, 15, 'F');
      doc.setDrawColor(220, 220, 230);
      doc.rect(margin, y, contentWidth, 15, 'S');
      
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text('EMBARQUE', margin + 3, y + 4);
      doc.text('DESEMBARQUE', margin + 70, y + 4);
      
      doc.setTextColor(30, 30, 30);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.text(`${trip.dataSaida} às ${trip.horarioSaida}`, margin + 3, y + 11);
      doc.text(`${trip.dataChegada} às ${trip.horarioChegada}`, margin + 70, y + 11);
      
      y += 18;

      // ===== VALORES =====
      doc.setFillColor(255, 255, 255);
      doc.rect(margin, y, contentWidth, 25, 'F');
      doc.setDrawColor(220, 220, 230);
      doc.rect(margin, y, contentWidth, 25, 'S');
      
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text('TARIFA', margin + 3, y + 4);
      doc.text('TAXA EMBARQUE', margin + 35, y + 4);
      doc.text('PEDÁGIO', margin + 70, y + 4);
      doc.text('SEGURO', margin + 105, y + 4);
      doc.text('DESCONTO', margin + 135, y + 4);
      
      doc.setTextColor(30, 30, 30);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.text(`R$ ${res.tarifa.toFixed(2)}`, margin + 3, y + 10);
      doc.text(`R$ ${res.taxaEmbarque.toFixed(2)}`, margin + 35, y + 10);
      doc.text(`R$ ${res.pedagio.toFixed(2)}`, margin + 70, y + 10);
      doc.text(`R$ ${res.seguro.toFixed(2)}`, margin + 105, y + 10);
      doc.text(`R$ ${res.desconto.toFixed(2)}`, margin + 135, y + 10);
      
      // Valor total em destaque
      doc.setFillColor(124, 58, 237);
      doc.rect(margin + 160, y + 3, 30, 19, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text('TOTAL', margin + 175, y + 9, { align: 'center' });
      doc.setFontSize(10);
      doc.text(`R$ ${res.valorTotal.toFixed(2)}`, margin + 175, y + 17, { align: 'center' });
      
      y += 28;

      // ===== PAGAMENTO E LOCALIZADOR =====
      doc.setFillColor(250, 250, 252);
      doc.rect(margin, y, contentWidth, 12, 'F');
      doc.setDrawColor(220, 220, 230);
      doc.rect(margin, y, contentWidth, 12, 'S');
      
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text('PAGAMENTO', margin + 3, y + 4);
      doc.text('LOCALIZADOR', margin + 70, y + 4);
      doc.text('RESERVA', margin + 120, y + 4);
      
      doc.setTextColor(30, 30, 30);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.text(res.paymentMethod, margin + 3, y + 10);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(124, 58, 237);
      doc.text(res.localizador, margin + 70, y + 10);
      doc.setTextColor(30, 30, 30);
      doc.setFont('helvetica', 'normal');
      doc.text(res.codigo, margin + 120, y + 10);
      
      y += 16;

      // ===== QR CODE E CÓDIGO DE BARRAS =====
      // QR Code à esquerda
      drawQRCode(margin, y, 25);
      
      // Código de barras no centro
      drawBarcode(margin + 30, y + 3, 120, 15, ticketNum + res.localizador);
      
      // Numeração do código de barras
      doc.setTextColor(0, 0, 0);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'normal');
      const barcodeText = ticketNum + res.localizador;
      doc.text(barcodeText, margin + 90, y + 22, { align: 'center' });
      
      // Informações do código
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(6);
      doc.setFont('helvetica', 'normal');
      doc.text('Apresente este bilhete com documento oficial com foto', margin + 30, y + 28);
      
      y += 32;

      // ===== AVISO LEGAL =====
      doc.setFillColor(255, 248, 230);
      doc.rect(margin, y, contentWidth, 18, 'F');
      doc.setDrawColor(255, 200, 100);
      doc.setLineWidth(0.3);
      doc.rect(margin, y, contentWidth, 18, 'S');
      
      doc.setTextColor(150, 100, 0);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text('⚠ ORIENTAÇÕES PARA EMBARQUE:', margin + 3, y + 5);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(6);
      doc.text('Este bilhete eletrônico deverá ser apresentado no guichê da rodoviária, juntamente com um documento', margin + 3, y + 10);
      doc.text('oficial com foto, para conferência e liberação do embarque. A validade da passagem deverá ser confirmada', margin + 3, y + 14);
      doc.text('junto à empresa de ônibus responsável.', margin + 3, y + 18);
      
      y += 26;

      // ===== RODAPÉ =====
      doc.setTextColor(150, 150, 150);
      doc.setFontSize(6);
      doc.setFont('helvetica', 'normal');
      doc.text(`Emitido em: ${new Date().toLocaleString('pt-BR')}`, margin, y);
      doc.text(`Atendente: ${currentUser?.name || 'Sistema'}`, margin + 60, y);
      doc.text(settings.endereco.substring(0, 50), margin, y + 4);
      doc.text(`Página ${isPassenger ? '1' : '2'} de 2`, pageWidth - margin, y, { align: 'right' });
    };

    // ===== PÁGINA 1: VIA DO PASSAGEIRO =====
    drawTicketPage(10, true);

    // ===== PÁGINA 2: VIA DO MOTORISTA =====
    doc.addPage();
    drawTicketPage(10, false);

    // ===== MARCA D'ÁGUA EM TODAS AS PÁGINAS =====
    for (let i = 1; i <= doc.getNumberOfPages(); i++) {
      doc.setPage(i);
      drawWatermark();
    }

    // Salvar
    doc.save(`BPE-${res.codigo}-${res.localizador}.pdf`);
    addLog('Bilhete BPE gerado', res.codigo);
    
    // Update status (código do bilhete já foi gerado na confirmação da reserva)
    if (res.status === 'paga') {
      updateReservation({ 
        ...res, 
        status: 'emitida',
        updatedAt: new Date().toISOString(), 
        history: [...res.history, { 
          date: new Date().toISOString(), 
          action: `BPE emitido - Código: ${res.ticketCode || 'N/A'}`, 
          user: currentUser?.name || '' 
        }] 
      });
    }
  };

  // Enviar por WhatsApp
  const sendWhatsApp = (resId: string) => {
    const res = reservations.find(r => r.id === resId);
    if (!res) return;
    
    const trip = trips.find(t => t.id === res.tripId);
    const company = companies.find(c => c.id === res.companyId);
    if (!trip || !company) return;

    setSendingWhatsApp(resId);

    // Pegar telefone do primeiro passageiro
    const passengerPhone = res.passengers[0]?.telefone?.replace(/\D/g, '') || '';
    
    // Montar mensagem completa
    const message = `🚌 *BILHETE DE PASSAGEM ELETRÔNICO*
━━━━━━━━━━━━━━━━━━━━

📋 *DADOS DA RESERVA*
• Código: ${res.codigo}
• Localizador: ${res.localizador}
${res.ticketCode ? `• Código do Bilhete: ${res.ticketCode}` : ''}

🏢 *EMPRESA*
• ${company.nomeFantasia}
• Linha: ${trip.linha}

📍 *VIAGEM*
• Origem: ${trip.origem}
• Destino: ${trip.destino}
• Data: ${trip.dataSaida}
• Horário: ${trip.horarioSaida}
• Classe: ${trip.classe.toUpperCase()}
• Plataforma: ${trip.plataforma}

👤 *PASSAGEIRO*
• Nome: ${res.passengers[0]?.nomeCompleto}
• CPF: ${res.passengers[0]?.cpf}
• Poltrona: ${res.passengers[0]?.poltrona}

💰 *VALOR*
• Total: R$ ${res.valorTotal.toFixed(2)}

⚠️ *ORIENTAÇÕES*
• Apresente este bilhete no guichê da rodoviária
• Traga documento oficial com foto
• Chegue com 30 minutos de antecedência

━━━━━━━━━━━━━━━━━━━━
${settings.nome}
SAC: ${settings.sac}`;

    // Abrir WhatsApp
    const encodedMessage = encodeURIComponent(message);
    const whatsappUrl = passengerPhone 
      ? `https://wa.me/55${passengerPhone}?text=${encodedMessage}`
      : `https://wa.me/?text=${encodedMessage}`;
    
    window.open(whatsappUrl, '_blank');
    
    setTimeout(() => setSendingWhatsApp(null), 1000);
    addLog('Bilhete enviado por WhatsApp', res.codigo);
  };

  // Função de Impressão
  const printTicket = async (resId: string) => {
    const res = reservations.find(r => r.id === resId);
    if (!res) return;
    
    const trip = trips.find(t => t.id === res.tripId);
    const company = companies.find(c => c.id === res.companyId);
    if (!trip || !company) return;

    // Gerar PDF e abrir para impressão
    const doc = new jsPDF('p', 'mm', 'a4');
    const ticketNum = res.ticketCode || generateTicketNumber();
    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const authCode = `AUTH${Date.now().toString(36).toUpperCase().slice(-8)}`;

    // Gerar QR Code real baseado no código do bilhete (único e permanente)
    const qrCodeData = `BPE:${ticketNum}|RES:${res.codigo}|LOC:${res.localizador}|PAS:${res.passengers[0]?.cpf}|VAL:${res.valorTotal}`;
    const qrCodeBase64 = await QRCode.toDataURL(qrCodeData, {
      width: 300,
      margin: 1,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      },
      errorCorrectionLevel: 'M'
    });

    // Função auxiliar para desenhar QR Code real
    const drawQRCode = (x: number, y: number, size: number) => {
      try {
        doc.addImage(qrCodeBase64, 'PNG', x, y, size, size);
      } catch (e) {
        console.warn('Erro ao adicionar QR Code ao PDF');
      }
    };

    // Função auxiliar para código de barras
    const drawBarcode = (x: number, y: number, width: number, height: number, code: string) => {
      doc.setFillColor(255, 255, 255);
      doc.rect(x, y, width, height + 5, 'F');
      doc.setFillColor(0, 0, 0);
      let cursor = x;
      const barWidth = width / 60;
      for (let i = 0; i < 60; i++) {
        const charCode = code.charCodeAt(i % code.length);
        const isBar = (charCode + i) % 2 === 0;
        if (isBar) {
          const w = ((charCode % 3) + 1) * barWidth * 0.5;
          doc.rect(cursor, y, w, height, 'F');
          cursor += w;
        } else {
          cursor += barWidth * 0.5;
        }
        if (cursor > x + width) break;
      }
    };

    // Marca d'água (removida)
    const drawWatermark = () => {
      // Marca d'água desativada
    };

    // Desenhar página do bilhete
    const drawTicketPage = (startY: number, isPassenger: boolean) => {
      let y = startY;
      const margin = 10;
      const contentWidth = pageWidth - (margin * 2);

      // Cabeçalho roxo
      doc.setFillColor(124, 58, 237);
      doc.rect(0, y - 5, pageWidth, 30, 'F');
      
      // Logo da empresa
      if (company.logo) {
        try {
          if (company.logo.startsWith('data:image')) {
            const imgFormat = company.logo.includes('image/png') ? 'PNG' : 'JPEG';
            doc.addImage(company.logo, imgFormat, pageWidth - margin - 20, y, 20, 20);
          }
        } catch (e) {
          console.warn('Logo não pôde ser adicionado ao PDF');
        }
      }
      
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(14);
      doc.setFont('helvetica', 'bold');
      doc.text(settings.nome.toUpperCase(), margin, y + 5);
      
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.text(`CNPJ: ${settings.cnpj}`, margin, y + 11);
      doc.text(`SAC: ${settings.sac}`, margin, y + 16);
      
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text(isPassenger ? 'VIA DO PASSAGEIRO' : 'VIA DO MOTORISTA', pageWidth - margin, y + 5, { align: 'right' });
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.text(`Bilhete nº ${ticketNum}`, pageWidth - margin, y + 11, { align: 'right' });
      doc.text(`Autorização: ${authCode}`, pageWidth - margin, y + 16, { align: 'right' });
      
      y += 30;

      // Box Origem → Destino
      doc.setFillColor(245, 243, 255);
      doc.rect(margin, y, contentWidth, 28, 'F');
      doc.setDrawColor(124, 58, 237);
      doc.setLineWidth(0.5);
      doc.rect(margin, y, contentWidth, 28, 'S');
      
      doc.setTextColor(124, 58, 237);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'bold');
      doc.text('ORIGEM', margin + 5, y + 6);
      doc.text('DESTINO', margin + contentWidth / 2 + 5, y + 6);
      
      doc.setFontSize(12);
      doc.setTextColor(30, 30, 30);
      doc.text(trip.origem.substring(0, 25), margin + 5, y + 14);
      doc.text(trip.destino.substring(0, 25), margin + contentWidth / 2 + 5, y + 14);
      
      doc.setTextColor(124, 58, 237);
      doc.setFontSize(16);
      doc.text('→', pageWidth / 2 - 3, y + 15);
      
      doc.setFontSize(8);
      doc.setTextColor(100, 100, 100);
      doc.text(`Data: ${trip.dataSaida}`, margin + 5, y + 22);
      doc.text(`Horário: ${trip.horarioSaida}`, margin + 50, y + 22);
      doc.text(`Duração: ${trip.duracao}`, margin + contentWidth / 2 + 5, y + 22);
      doc.text(`Classe: ${trip.classe.toUpperCase()}`, margin + contentWidth / 2 + 50, y + 22);
      
      y += 32;

      // Dados da Viação
      doc.setFillColor(250, 250, 252);
      doc.rect(margin, y, contentWidth, 22, 'F');
      doc.setDrawColor(220, 220, 230);
      doc.setLineWidth(0.3);
      doc.rect(margin, y, contentWidth, 22, 'S');
      
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text('VIAÇÃO', margin + 3, y + 4);
      doc.text('LINHA', margin + 60, y + 4);
      doc.text('PREFIXO', margin + 100, y + 4);
      doc.text('PLATAFORMA', margin + 140, y + 4);
      
      doc.setTextColor(30, 30, 30);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.text(company.nomeFantasia.substring(0, 30), margin + 3, y + 10);
      doc.text(trip.linha, margin + 60, y + 10);
      doc.text(trip.prefixo, margin + 100, y + 10);
      doc.text(trip.plataforma, margin + 140, y + 10);
      
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(7);
      doc.text('Nº SERVIÇO', margin + 3, y + 15);
      doc.text('LOCAL EMBARQUE', margin + 60, y + 15);
      
      doc.setTextColor(30, 30, 30);
      doc.setFontSize(8);
      doc.text(trip.numeroServico, margin + 3, y + 19);
      doc.text(trip.localEmbarque.substring(0, 45), margin + 60, y + 19);
      
      y += 25;

      // Passageiro e Poltrona
      doc.setFillColor(255, 255, 255);
      doc.rect(margin, y, contentWidth, 20, 'F');
      doc.setDrawColor(220, 220, 230);
      doc.rect(margin, y, contentWidth, 20, 'S');
      
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text('PASSAGEIRO', margin + 3, y + 4);
      doc.text('CPF/DOCUMENTO', margin + 100, y + 4);
      doc.text('POLTRONA', margin + 150, y + 4);
      
      doc.setTextColor(30, 30, 30);
      doc.setFontSize(10);
      doc.setFont('helvetica', 'bold');
      doc.text(res.passengers[0]?.nomeCompleto.substring(0, 40) || '', margin + 3, y + 12);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(9);
      doc.text(res.passengers[0]?.cpf || '', margin + 100, y + 12);
      
      doc.setFillColor(124, 58, 237);
      doc.rect(margin + 148, y + 6, 15, 10, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(12);
      doc.setFont('helvetica', 'bold');
      doc.text(res.passengers[0]?.poltrona || '', margin + 155.5, y + 13, { align: 'center' });
      
      y += 23;

      // Horários
      doc.setFillColor(250, 250, 252);
      doc.rect(margin, y, contentWidth, 15, 'F');
      doc.setDrawColor(220, 220, 230);
      doc.rect(margin, y, contentWidth, 15, 'S');
      
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text('EMBARQUE', margin + 3, y + 4);
      doc.text('DESEMBARQUE', margin + 70, y + 4);
      
      doc.setTextColor(30, 30, 30);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.text(`${trip.dataSaida} às ${trip.horarioSaida}`, margin + 3, y + 11);
      doc.text(`${trip.dataChegada} às ${trip.horarioChegada}`, margin + 70, y + 11);
      
      y += 18;

      // Valores
      doc.setFillColor(255, 255, 255);
      doc.rect(margin, y, contentWidth, 25, 'F');
      doc.setDrawColor(220, 220, 230);
      doc.rect(margin, y, contentWidth, 25, 'S');
      
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text('TARIFA', margin + 3, y + 4);
      doc.text('TAXA EMBARQUE', margin + 35, y + 4);
      doc.text('PEDÁGIO', margin + 70, y + 4);
      doc.text('SEGURO', margin + 105, y + 4);
      doc.text('DESCONTO', margin + 135, y + 4);
      
      doc.setTextColor(30, 30, 30);
      doc.setFontSize(8);
      doc.setFont('helvetica', 'normal');
      doc.text(`R$ ${res.tarifa.toFixed(2)}`, margin + 3, y + 10);
      doc.text(`R$ ${res.taxaEmbarque.toFixed(2)}`, margin + 35, y + 10);
      doc.text(`R$ ${res.pedagio.toFixed(2)}`, margin + 70, y + 10);
      doc.text(`R$ ${res.seguro.toFixed(2)}`, margin + 105, y + 10);
      doc.text(`R$ ${res.desconto.toFixed(2)}`, margin + 135, y + 10);
      
      doc.setFillColor(124, 58, 237);
      doc.rect(margin + 160, y + 3, 30, 19, 'F');
      doc.setTextColor(255, 255, 255);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text('TOTAL', margin + 175, y + 9, { align: 'center' });
      doc.setFontSize(10);
      doc.text(`R$ ${res.valorTotal.toFixed(2)}`, margin + 175, y + 17, { align: 'center' });
      
      y += 28;

      // Pagamento e Localizador
      doc.setFillColor(250, 250, 252);
      doc.rect(margin, y, contentWidth, 12, 'F');
      doc.setDrawColor(220, 220, 230);
      doc.rect(margin, y, contentWidth, 12, 'S');
      
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text('PAGAMENTO', margin + 3, y + 4);
      doc.text('LOCALIZADOR', margin + 70, y + 4);
      doc.text('RESERVA', margin + 120, y + 4);
      
      doc.setTextColor(30, 30, 30);
      doc.setFontSize(9);
      doc.setFont('helvetica', 'normal');
      doc.text(res.paymentMethod, margin + 3, y + 10);
      doc.setFont('helvetica', 'bold');
      doc.setTextColor(124, 58, 237);
      doc.text(res.localizador, margin + 70, y + 10);
      doc.setTextColor(30, 30, 30);
      doc.setFont('helvetica', 'normal');
      doc.text(res.codigo, margin + 120, y + 10);
      
      y += 16;

      // QR Code e Código de Barras
      drawQRCode(margin, y, 25);
      drawBarcode(margin + 30, y + 3, 120, 15, ticketNum + res.localizador);
      
      // Numeração do código de barras
      doc.setTextColor(0, 0, 0);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'normal');
      const barcodeText = ticketNum + res.localizador;
      doc.text(barcodeText, margin + 90, y + 22, { align: 'center' });
      
      doc.setTextColor(100, 100, 100);
      doc.setFontSize(6);
      doc.setFont('helvetica', 'normal');
      doc.text('Apresente este bilhete com documento oficial com foto', margin + 30, y + 28);
      
      y += 32;

      // Aviso legal
      doc.setFillColor(255, 248, 230);
      doc.rect(margin, y, contentWidth, 18, 'F');
      doc.setDrawColor(255, 200, 100);
      doc.setLineWidth(0.3);
      doc.rect(margin, y, contentWidth, 18, 'S');
      
      doc.setTextColor(150, 100, 0);
      doc.setFontSize(7);
      doc.setFont('helvetica', 'bold');
      doc.text('⚠ ORIENTAÇÕES PARA EMBARQUE:', margin + 3, y + 5);
      doc.setFont('helvetica', 'normal');
      doc.setFontSize(6);
      doc.text('Este bilhete eletrônico deverá ser apresentado no guichê da rodoviária, juntamente com um documento', margin + 3, y + 10);
      doc.text('oficial com foto, para conferência e liberação do embarque. A validade da passagem deverá ser confirmada', margin + 3, y + 14);
      doc.text('junto à empresa de ônibus responsável.', margin + 3, y + 18);
      
      y += 26;

      // Rodapé
      doc.setTextColor(150, 150, 150);
      doc.setFontSize(6);
      doc.setFont('helvetica', 'normal');
      doc.text(`Emitido em: ${new Date().toLocaleString('pt-BR')}`, margin, y);
      doc.text(`Atendente: ${currentUser?.name || 'Sistema'}`, margin + 60, y);
      doc.text(settings.endereco.substring(0, 50), margin, y + 4);
      doc.text(`Página ${isPassenger ? '1' : '2'} de 2`, pageWidth - margin, y, { align: 'right' });
    };

    // Página 1: Via do Passageiro
    drawTicketPage(10, true);

    // Página 2: Via do Motorista
    doc.addPage();
    drawTicketPage(10, false);

    // Marca d'água em todas as páginas
    for (let i = 1; i <= doc.getNumberOfPages(); i++) {
      doc.setPage(i);
      drawWatermark();
    }

    // Abrir PDF para impressão
    const pdfBlob = doc.output('blob');
    const pdfUrl = URL.createObjectURL(pdfBlob);
    const printWindow = window.open(pdfUrl, '_blank');
    
    if (printWindow) {
      printWindow.onload = () => {
        setTimeout(() => {
          printWindow.print();
        }, 500);
      };
    }

    addLog('Bilhete impresso', res.codigo);
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-xl font-bold text-gray-800">Bilhetes Eletrônicos (BPE)</h2>
        <p className="text-sm text-gray-500">Gere bilhetes de passagem no padrão ClickBus/BPE</p>
      </div>



      <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50 border-b border-gray-200">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Reserva</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Código do Bilhete</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Passageiro</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Viagem</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Data</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Valor</th>
                <th className="px-4 py-3 text-left text-xs font-semibold text-gray-600 uppercase tracking-wider">Status</th>
                <th className="px-4 py-3 text-center text-xs font-semibold text-gray-600 uppercase tracking-wider">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {eligibleReservations.map(r => {
                const trip = trips.find(t => t.id === r.tripId);
                const isEmitido = r.status === 'emitida';
                return (
                  <tr key={r.id} className={`transition-colors ${isEmitido ? 'bg-green-50/30' : 'hover:bg-gray-50'}`}>
                    <td className="px-4 py-3">
                      <p className="text-sm font-semibold text-gray-800">{r.codigo}</p>
                      <p className="text-xs text-gray-500 font-mono">{r.localizador}</p>
                    </td>
                    <td className="px-4 py-3">
                      {r.ticketCode ? (
                        <div className="flex items-center gap-1">
                          <Lock className="w-3 h-3 text-green-600" />
                          <p className="text-xs font-mono font-semibold text-green-700">{r.ticketCode}</p>
                        </div>
                      ) : (
                        <p className="text-xs text-gray-400 italic">Não emitido</p>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm font-medium text-gray-700">{r.passengers[0]?.nomeCompleto}</p>
                      <p className="text-xs text-gray-500">CPF: {r.passengers[0]?.cpf}</p>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">
                      <div className="flex items-center gap-1">
                        <MapPin className="w-3 h-3 text-purple-600" />
                        {trip ? `${trip.origem.split(' - ')[0]} → ${trip.destino.split(' - ')[0]}` : '-'}
                      </div>
                      <p className="text-xs text-gray-500 mt-0.5">Poltrona: {r.passengers[0]?.poltrona}</p>
                    </td>
                    <td className="px-4 py-3">
                      <p className="text-sm text-gray-700">{trip?.dataSaida || '-'}</p>
                      <p className="text-xs text-gray-500">{trip?.horarioSaida || '-'}</p>
                    </td>
                    <td className="px-4 py-3 text-sm font-bold text-gray-800">R$ {r.valorTotal.toFixed(2)}</td>
                    <td className="px-4 py-3">
                      {isEmitido ? (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-green-100 text-green-700">
                          <CheckCircle className="w-3 h-3" />
                          Emitido
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-full text-xs font-medium bg-blue-100 text-blue-700">
                          <Clock className="w-3 h-3" />
                          Pronto p/ Emitir
                        </span>
                      )}
                    </td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-center gap-1">
                        {/* Visualizar */}
                        <button 
                          onClick={() => { setPreviewRes(r.id); setShowPreview(true); }} 
                          className="p-2 hover:bg-blue-50 rounded-lg transition-colors group" 
                          title="Visualizar bilhete"
                        >
                          <Eye className="w-4 h-4 text-gray-400 group-hover:text-blue-600" />
                        </button>

                        {/* Gerar/Baixar PDF */}
                        <button 
                          onClick={async () => await generatePDF(r.id)} 
                          className="p-2 hover:bg-purple-50 rounded-lg transition-colors group" 
                          title={isEmitido ? "Baixar PDF" : "Gerar e Emitir PDF"}
                        >
                          <Download className="w-4 h-4 text-gray-400 group-hover:text-purple-600" />
                        </button>

                        {/* Enviar WhatsApp */}
                        <button 
                          onClick={() => sendWhatsApp(r.id)} 
                          disabled={sendingWhatsApp === r.id}
                          className="p-2 hover:bg-green-50 rounded-lg transition-colors group disabled:opacity-50" 
                          title="Enviar por WhatsApp"
                        >
                          {sendingWhatsApp === r.id ? (
                            <div className="w-4 h-4 border-2 border-green-600 border-t-transparent rounded-full animate-spin" />
                          ) : (
                            <svg className="w-4 h-4 text-gray-400 group-hover:text-green-600" fill="currentColor" viewBox="0 0 24 24">
                              <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.334.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.334 11.893-11.892a11.821 11.821 0 00-3.48-8.413z"/>
                            </svg>
                          )}
                        </button>

                        {/* Indicador de bloqueio após emissão */}
                        {isEmitido && (
                          <div className="p-2" title="Bilhete emitido - não pode ser alterado">
                            <Lock className="w-4 h-4 text-green-600" />
                          </div>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {eligibleReservations.length === 0 && (
                <tr>
                  <td colSpan={8} className="px-4 py-12 text-center">
                    <div className="flex flex-col items-center gap-2">
                      <FileText className="w-12 h-12 text-gray-300" />
                      <p className="text-gray-500 font-medium">Nenhuma reserva pronta para emissão</p>
                      <p className="text-sm text-gray-400">Aguarde o pagamento ser aprovado</p>
                    </div>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Preview Modal - Modelo ClickBus/BPE */}
      {showPreview && previewReservation && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-4 border-b border-gray-100 flex items-center justify-between sticky top-0 bg-white z-10">
              <h3 className="text-lg font-semibold">Visualização do BPE</h3>
              <div className="flex gap-2">
                <button 
                  onClick={() => sendWhatsApp(previewReservation.id)} 
                  disabled={sendingWhatsApp === previewReservation.id}
                  className="px-3 py-1.5 bg-green-600 text-white rounded-lg text-sm flex items-center gap-1 hover:bg-green-700 transition disabled:opacity-50"
                >
                  {sendingWhatsApp === previewReservation.id ? (
                    <div className="w-3.5 h-3.5 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  ) : (
                    <svg className="w-3.5 h-3.5" fill="currentColor" viewBox="0 0 24 24">
                      <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.334.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.334 11.893-11.892a11.821 11.821 0 00-3.48-8.413z"/>
                    </svg>
                  )}
                  WhatsApp
                </button>
                <button 
                  onClick={async () => await generatePDF(previewReservation.id)} 
                  className="px-3 py-1.5 bg-purple-600 text-white rounded-lg text-sm flex items-center gap-1 hover:bg-purple-700 transition"
                >
                  <Download className="w-3.5 h-3.5" /> PDF
                </button>
                <button 
                  onClick={async () => await printTicket(previewReservation.id)} 
                  className="px-3 py-1.5 bg-gray-600 text-white rounded-lg text-sm flex items-center gap-1 hover:bg-gray-700 transition"
                >
                  <Printer className="w-3.5 h-3.5" /> Imprimir
                </button>
                <button onClick={() => setShowPreview(false)} className="p-1 hover:bg-gray-100 rounded">
                  <X className="w-5 h-5" />
                </button>
              </div>
            </div>
            <div className="p-6">
              {/* Ticket preview - Modelo ClickBus/BPE */}
              <div className="bg-white border-2 border-purple-300 rounded-lg overflow-hidden shadow-xl">
                {/* Header roxo */}
                <div className="bg-purple-600 text-white p-4">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-bold text-lg">{settings.nome.toUpperCase()}</p>
                      <p className="text-xs opacity-90">CNPJ: {settings.cnpj} | SAC: {settings.sac}</p>
                    </div>
                    <div className="text-right">
                      <p className="font-bold text-sm">VIA DO PASSAGEIRO</p>
                      <p className="text-xs opacity-90">Bilhete nº {generateTicketNumber()}</p>
                      {previewReservation.ticketCode && (
                        <p className="text-xs font-mono bg-white/20 px-2 py-0.5 rounded mt-1">
                          {previewReservation.ticketCode}
                        </p>
                      )}
                    </div>
                  </div>
                </div>

                {/* Box Origem → Destino */}
                <div className="bg-purple-50 border-b border-purple-200 p-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <p className="text-xs font-bold text-purple-600 uppercase">Origem</p>
                      {(() => {
                        const trip = trips.find(t => t.id === previewReservation.tripId);
                        return trip ? (
                          <>
                            <p className="text-xl font-bold text-gray-800">{trip.origem}</p>
                            <p className="text-xs text-gray-600 mt-1">Data: {trip.dataSaida}</p>
                            <p className="text-xs text-gray-600">Horário: {trip.horarioSaida}</p>
                          </>
                        ) : null;
                      })()}
                    </div>
                    <div>
                      <p className="text-xs font-bold text-purple-600 uppercase">Destino</p>
                      {(() => {
                        const trip = trips.find(t => t.id === previewReservation.tripId);
                        return trip ? (
                          <>
                            <p className="text-xl font-bold text-gray-800">{trip.destino}</p>
                            <p className="text-xs text-gray-600 mt-1">Duração: {trip.duracao}</p>
                            <p className="text-xs text-gray-600">Classe: {trip.classe.toUpperCase()}</p>
                          </>
                        ) : null;
                      })()}
                    </div>
                  </div>
                </div>

                {/* Dados da Viação */}
                <div className="bg-gray-50 border-b border-gray-200 p-4">
                  <div className="grid grid-cols-4 gap-3 text-xs">
                    <div>
                      <p className="font-bold text-gray-500 uppercase text-[10px]">Viação</p>
                      {(() => {
                        const company = companies.find(c => c.id === previewReservation.companyId);
                        const trip = trips.find(t => t.id === previewReservation.tripId);
                        return (
                          <div className="flex items-start gap-2">
                            {company?.logo && (
                              <img src={company.logo} alt={company.nomeFantasia} className="w-8 h-8 rounded object-cover border border-gray-200 flex-shrink-0" />
                            )}
                            <div>
                              <p className="font-semibold text-gray-800">{company?.nomeFantasia}</p>
                              <p className="text-gray-600">Linha: {trip?.linha}</p>
                            </div>
                          </div>
                        );
                      })()}
                    </div>
                    <div>
                      <p className="font-bold text-gray-500 uppercase text-[10px]">Prefixo</p>
                      {(() => {
                        const trip = trips.find(t => t.id === previewReservation.tripId);
                        return <p className="font-semibold text-gray-800">{trip?.prefixo}</p>;
                      })()}
                    </div>
                    <div>
                      <p className="font-bold text-gray-500 uppercase text-[10px]">Plataforma</p>
                      {(() => {
                        const trip = trips.find(t => t.id === previewReservation.tripId);
                        return <p className="font-semibold text-gray-800">{trip?.plataforma}</p>;
                      })()}
                    </div>
                    <div>
                      <p className="font-bold text-gray-500 uppercase text-[10px]">Nº Serviço</p>
                      {(() => {
                        const trip = trips.find(t => t.id === previewReservation.tripId);
                        return <p className="font-semibold text-gray-800">{trip?.numeroServico}</p>;
                      })()}
                    </div>
                  </div>
                </div>

                {/* Passageiro e Poltrona */}
                <div className="border-b border-gray-200 p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex-1">
                      <p className="text-[10px] font-bold text-gray-500 uppercase">Passageiro</p>
                      <p className="text-base font-bold text-gray-800">{previewReservation.passengers[0]?.nomeCompleto}</p>
                      <p className="text-xs text-gray-600">CPF: {previewReservation.passengers[0]?.cpf}</p>
                    </div>
                    <div className="bg-purple-600 text-white px-6 py-3 rounded-lg text-center">
                      <p className="text-[10px] font-bold uppercase">Poltrona</p>
                      <p className="text-3xl font-bold">{previewReservation.passengers[0]?.poltrona}</p>
                    </div>
                  </div>
                </div>

                {/* Horários */}
                <div className="bg-gray-50 border-b border-gray-200 p-4">
                  <div className="grid grid-cols-2 gap-4 text-xs">
                    <div>
                      <p className="font-bold text-gray-500 uppercase text-[10px]">Embarque</p>
                      {(() => {
                        const trip = trips.find(t => t.id === previewReservation.tripId);
                        return <p className="font-semibold text-gray-800">{trip?.dataSaida} às {trip?.horarioSaida}</p>;
                      })()}
                    </div>
                    <div>
                      <p className="font-bold text-gray-500 uppercase text-[10px]">Desembarque</p>
                      {(() => {
                        const trip = trips.find(t => t.id === previewReservation.tripId);
                        return <p className="font-semibold text-gray-800">{trip?.dataChegada} às {trip?.horarioChegada}</p>;
                      })()}
                    </div>
                  </div>
                </div>

                {/* Valores */}
                <div className="border-b border-gray-200 p-4">
                  <div className="grid grid-cols-5 gap-2 text-xs">
                    <div>
                      <p className="font-bold text-gray-500 uppercase text-[10px]">Tarifa</p>
                      <p className="text-gray-800">R$ {previewReservation.tarifa.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="font-bold text-gray-500 uppercase text-[10px]">Taxa Emb.</p>
                      <p className="text-gray-800">R$ {previewReservation.taxaEmbarque.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="font-bold text-gray-500 uppercase text-[10px]">Pedágio</p>
                      <p className="text-gray-800">R$ {previewReservation.pedagio.toFixed(2)}</p>
                    </div>
                    <div>
                      <p className="font-bold text-gray-500 uppercase text-[10px]">Seguro</p>
                      <p className="text-gray-800">R$ {previewReservation.seguro.toFixed(2)}</p>
                    </div>
                    <div className="bg-purple-600 text-white p-2 rounded text-center">
                      <p className="font-bold uppercase text-[10px]">Total</p>
                      <p className="text-lg font-bold">R$ {previewReservation.valorTotal.toFixed(2)}</p>
                    </div>
                  </div>
                </div>

                {/* Pagamento e Localizador */}
                <div className="bg-gray-50 border-b border-gray-200 p-4">
                  <div className="grid grid-cols-3 gap-3 text-xs">
                    <div>
                      <p className="font-bold text-gray-500 uppercase text-[10px]">Pagamento</p>
                      <p className="font-semibold text-gray-800">{previewReservation.paymentMethod}</p>
                    </div>
                    <div>
                      <p className="font-bold text-gray-500 uppercase text-[10px]">Localizador</p>
                      <p className="font-bold text-purple-600 text-base">{previewReservation.localizador}</p>
                    </div>
                    <div>
                      <p className="font-bold text-gray-500 uppercase text-[10px]">Reserva</p>
                      <p className="font-semibold text-gray-800">{previewReservation.codigo}</p>
                    </div>
                  </div>
                  
                  {/* Código do Bilhete (se emitido) */}
                  {previewReservation.ticketCode && (
                    <div className="mt-3 pt-3 border-t border-gray-200">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Lock className="w-4 h-4 text-green-600" />
                          <div>
                            <p className="text-[10px] font-bold text-gray-500 uppercase">Código do Bilhete</p>
                            <p className="text-xs font-mono font-bold text-green-700">{previewReservation.ticketCode}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-1 px-2 py-1 bg-green-100 rounded-full">
                          <CheckCircle className="w-3 h-3 text-green-600" />
                          <span className="text-[10px] font-bold text-green-700">EMITIDO</span>
                        </div>
                      </div>
                    </div>
                  )}
                </div>

                {/* QR Code e Código de Barras */}
                <div className="p-4 flex items-center gap-4 justify-center">
                  <div className="text-center">
                    <div className="w-24 h-24 bg-white border-2 border-gray-300 flex items-center justify-center">
                      <QrCode className="w-16 h-16 text-gray-800" />
                    </div>
                    <p className="text-[10px] text-gray-500 mt-1">QR Code</p>
                  </div>
                  <div className="flex-1 text-center">
                    <div className="w-full h-16 bg-white border-2 border-gray-300 flex items-center justify-center">
                      <div className="flex gap-0.5">
                        {Array.from({ length: 50 }).map((_, i) => (
                          <div key={i} className="bg-black" style={{ width: Math.random() > 0.5 ? '2px' : '1px', height: '50px' }} />
                        ))}
                      </div>
                    </div>
                    <p className="text-[10px] text-gray-500 mt-1">Código de Barras</p>
                  </div>
                </div>

                {/* Aviso */}
                <div className="bg-yellow-50 border-t-2 border-yellow-300 p-3 text-center">
                  <p className="text-xs text-yellow-800 font-bold">⚠️ ORIENTAÇÕES PARA EMBARQUE</p>
                  <p className="text-[10px] text-yellow-700 mt-1">Este bilhete eletrônico deverá ser apresentado no guichê da rodoviária, juntamente com um documento oficial com foto, para conferência e liberação do embarque.</p>
                  <p className="text-[10px] text-yellow-700 mt-1">A validade da passagem deverá ser confirmada junto à empresa de ônibus responsável.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
