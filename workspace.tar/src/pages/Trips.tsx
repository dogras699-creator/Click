import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { Trip } from '../types';
import { v4 as uuidv4 } from 'uuid';
import { Plus, Edit2, Trash2, X, Copy, Bus, Search } from 'lucide-react';

export default function Trips() {
  const { trips, companies, addTrip, updateTrip, deleteTrip, currentUser, addLog } = useData();
  const [showModal, setShowModal] = useState(false);
  const [editing, setEditing] = useState<Trip | null>(null);
  const [filter, setFilter] = useState('');
  const isAdmin = currentUser?.role === 'admin';

  type FormType = {
    companyId: string; nome: string; origem: string; destino: string;
    dataSaida: string; horarioSaida: string; dataChegada: string; horarioChegada: string;
    duracao: string; classe: 'convencional' | 'executivo' | 'semi-leito' | 'leito';
    linha: string; prefixo: string; numeroServico: string; plataforma: string;
    localEmbarque: string; tarifa: number; pedagio: number; taxaEmbarque: number;
    seguro: number; outrasTaxas: number; desconto: number; valorTotal: number;
    andares: number; poltronas: number; poltronasOcupadas: string[]; poltronasBloqueadas: string[]; active: boolean;
  };
  const emptyForm: FormType = {
    companyId: companies[0]?.id || '', nome: '', origem: '', destino: '',
    dataSaida: new Date().toISOString().split('T')[0], horarioSaida: '08:00',
    dataChegada: new Date().toISOString().split('T')[0], horarioChegada: '18:00',
    duracao: '10h00min', classe: 'convencional', linha: '', prefixo: '',
    numeroServico: '', plataforma: '', localEmbarque: '', tarifa: 0, pedagio: 0,
    taxaEmbarque: 0, seguro: 0, outrasTaxas: 0, desconto: 0, valorTotal: 0,
    andares: 1, poltronas: 44, poltronasOcupadas: [], poltronasBloqueadas: [], active: true
  };
  const [form, setForm] = useState<FormType>(emptyForm);

  const openNew = () => { setForm(emptyForm); setEditing(null); setShowModal(true); };
  const openEdit = (t: Trip) => {
    setForm({ ...emptyForm, ...t, poltronasOcupadas: t.poltronasOcupadas || [], poltronasBloqueadas: t.poltronasBloqueadas || [] });
    setEditing(t); setShowModal(true);
  };

  const calcTotal = (f: typeof form) => f.tarifa + f.pedagio + f.taxaEmbarque + f.seguro + f.outrasTaxas - f.desconto;

  const handleSave = () => {
    if (!form.nome || !form.origem || !form.destino || !form.companyId) return;
    const valorTotal = calcTotal(form);
    if (editing) {
      updateTrip({ ...editing, ...form, valorTotal });
      addLog('Viagem atualizada', form.nome);
    } else {
      addTrip({ id: uuidv4(), ...form, valorTotal });
      addLog('Viagem cadastrada', form.nome);
    }
    setShowModal(false);
  };

  const handleDelete = (id: string) => {
    if (confirm('Excluir esta viagem?')) { deleteTrip(id); addLog('Viagem excluída', id); }
  };

  const handleDuplicate = (t: Trip) => {
    const newTrip = { ...t, id: uuidv4(), nome: t.nome + ' (cópia)', poltronasOcupadas: [], poltronasBloqueadas: t.poltronasBloqueadas || [] };
    addTrip(newTrip);
    addLog('Viagem duplicada', t.nome);
  };

  const filtered = trips.filter(t => t.nome.toLowerCase().includes(filter.toLowerCase()) || t.origem.toLowerCase().includes(filter.toLowerCase()) || t.destino.toLowerCase().includes(filter.toLowerCase()));

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-gray-800">Viagens Cadastradas</h2>
          <p className="text-sm text-gray-500">{trips.length} viagens no sistema</p>
        </div>
        {isAdmin && (
          <button onClick={openNew} className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700 transition flex items-center gap-2">
            <Plus className="w-4 h-4" /> Nova Viagem
          </button>
        )}
      </div>

      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
        <input value={filter} onChange={e => setFilter(e.target.value)} placeholder="Buscar por nome, origem ou destino..." className="w-full pl-10 pr-4 py-2.5 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
      </div>

      <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Viagem</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Empresa</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Origem → Destino</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Data/Hora</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Classe</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Valor</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Disp.</th>
                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filtered.map(t => {
                const company = companies.find(c => c.id === t.companyId);
                const disponivel = t.poltronas - (t.poltronasOcupadas?.length || 0) - (t.poltronasBloqueadas?.length || 0);
                return (
                  <tr key={t.id} className="hover:bg-gray-50">
                    <td className="px-4 py-3">
                      <p className="text-sm font-medium text-gray-800">{t.nome}</p>
                      <p className="text-xs text-gray-500">{t.linha}</p>
                    </td>
                    <td className="px-4 py-3 text-sm text-gray-600">{company?.nomeFantasia || '-'}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{t.origem} → {t.destino}</td>
                    <td className="px-4 py-3 text-sm text-gray-600">{t.dataSaida} {t.horarioSaida}</td>
                    <td className="px-4 py-3"><span className="px-2 py-0.5 bg-purple-100 text-purple-700 rounded-full text-xs capitalize">{t.classe}</span></td>
                    <td className="px-4 py-3 text-sm font-medium text-gray-800">R$ {t.valorTotal.toFixed(2)}</td>
                    <td className="px-4 py-3 text-sm"><span className={`font-medium ${disponivel > 10 ? 'text-green-600' : disponivel > 0 ? 'text-orange-600' : 'text-red-600'}`}>{disponivel}/{t.poltronas}</span></td>
                    <td className="px-4 py-3">
                      <div className="flex gap-1">
                        {isAdmin && <button onClick={() => openEdit(t)} className="p-1.5 hover:bg-gray-100 rounded"><Edit2 className="w-3.5 h-3.5 text-gray-500" /></button>}
                        {isAdmin && <button onClick={() => handleDuplicate(t)} className="p-1.5 hover:bg-gray-100 rounded"><Copy className="w-3.5 h-3.5 text-blue-500" /></button>}
                        {isAdmin && <button onClick={() => handleDelete(t.id)} className="p-1.5 hover:bg-red-50 rounded"><Trash2 className="w-3.5 h-3.5 text-red-500" /></button>}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100 flex items-center justify-between sticky top-0 bg-white z-10">
              <h3 className="text-lg font-semibold">{editing ? 'Editar Viagem' : 'Nova Viagem'}</h3>
              <button onClick={() => setShowModal(false)}><X className="w-5 h-5" /></button>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Empresa *</label>
                  <select value={form.companyId} onChange={e => setForm({...form, companyId: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none">
                    {companies.map(c => <option key={c.id} value={c.id}>{c.nomeFantasia}</option>)}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nome da Viagem *</label>
                  <input value={form.nome} onChange={e => setForm({...form, nome: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Origem *</label>
                  <input value={form.origem} onChange={e => setForm({...form, origem: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Destino *</label>
                  <input value={form.destino} onChange={e => setForm({...form, destino: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Data Saída</label>
                  <input type="date" value={form.dataSaida} onChange={e => setForm({...form, dataSaida: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Horário Saída</label>
                  <input type="time" value={form.horarioSaida} onChange={e => setForm({...form, horarioSaida: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Data Chegada</label>
                  <input type="date" value={form.dataChegada} onChange={e => setForm({...form, dataChegada: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Horário Chegada</label>
                  <input type="time" value={form.horarioChegada} onChange={e => setForm({...form, horarioChegada: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Classe</label>
                  <select value={form.classe} onChange={e => setForm({...form, classe: e.target.value as any})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none">
                    <option value="convencional">Convencional</option>
                    <option value="executivo">Executivo</option>
                    <option value="semi-leito">Semi-Leito</option>
                    <option value="leito">Leito</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Duração</label>
                  <input value={form.duracao} onChange={e => setForm({...form, duracao: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Linha</label>
                  <input value={form.linha} onChange={e => setForm({...form, linha: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Prefixo</label>
                  <input value={form.prefixo} onChange={e => setForm({...form, prefixo: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Nº Serviço</label>
                  <input value={form.numeroServico} onChange={e => setForm({...form, numeroServico: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Plataforma</label>
                  <input value={form.plataforma} onChange={e => setForm({...form, plataforma: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-gray-700 mb-1">Local de Embarque</label>
                  <input value={form.localEmbarque} onChange={e => setForm({...form, localEmbarque: e.target.value})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
              </div>
              <div className="border-t pt-4">
                <h4 className="font-medium text-gray-700 mb-3">Valores</h4>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Tarifa (R$)</label>
                    <input type="number" step="0.01" value={form.tarifa} onChange={e => setForm({...form, tarifa: parseFloat(e.target.value) || 0})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Pedágio (R$)</label>
                    <input type="number" step="0.01" value={form.pedagio} onChange={e => setForm({...form, pedagio: parseFloat(e.target.value) || 0})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Taxa Embarque (R$)</label>
                    <input type="number" step="0.01" value={form.taxaEmbarque} onChange={e => setForm({...form, taxaEmbarque: parseFloat(e.target.value) || 0})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Seguro (R$)</label>
                    <input type="number" step="0.01" value={form.seguro} onChange={e => setForm({...form, seguro: parseFloat(e.target.value) || 0})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Outras Taxas (R$)</label>
                    <input type="number" step="0.01" value={form.outrasTaxas} onChange={e => setForm({...form, outrasTaxas: parseFloat(e.target.value) || 0})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none text-sm" />
                  </div>
                  <div>
                    <label className="block text-xs font-medium text-gray-600 mb-1">Desconto (R$)</label>
                    <input type="number" step="0.01" value={form.desconto} onChange={e => setForm({...form, desconto: parseFloat(e.target.value) || 0})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none text-sm" />
                  </div>
                </div>
                <div className="mt-3 p-3 bg-purple-50 rounded-lg">
                  <span className="text-sm font-medium text-purple-700">Valor Total: R$ {calcTotal(form).toFixed(2)}</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Andares</label>
                  <select value={form.andares} onChange={e => setForm({...form, andares: parseInt(e.target.value)})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none">
                    <option value={1}>1 Andar</option>
                    <option value={2}>2 Andares</option>
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Qtd. Poltronas</label>
                  <input type="number" value={form.poltronas} onChange={e => setForm({...form, poltronas: parseInt(e.target.value) || 0})} className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 outline-none" />
                </div>
              </div>
            </div>
            <div className="p-6 border-t border-gray-100 flex justify-end gap-3 sticky bottom-0 bg-white">
              <button onClick={() => setShowModal(false)} className="px-4 py-2 text-gray-600 hover:bg-gray-100 rounded-lg text-sm font-medium">Cancelar</button>
              <button onClick={handleSave} className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700">Salvar</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
