export interface User {
  id: string;
  name: string;
  email: string;
  password: string;
  role: 'admin' | 'attendant';
  active: boolean;
  createdAt: string;
}

export interface Company {
  id: string;
  razaoSocial: string;
  nomeFantasia: string;
  cnpj: string;
  telefone: string;
  endereco: string;
  email: string;
  logo?: string;
  active: boolean;
}

export interface Trip {
  id: string;
  companyId: string;
  nome: string;
  origem: string;
  destino: string;
  dataSaida: string;
  horarioSaida: string;
  dataChegada: string;
  horarioChegada: string;
  duracao: string;
  classe: 'convencional' | 'executivo' | 'semi-leito' | 'leito';
  linha: string;
  prefixo: string;
  numeroServico: string;
  plataforma: string;
  localEmbarque: string;
  tarifa: number;
  pedagio: number;
  taxaEmbarque: number;
  seguro: number;
  outrasTaxas: number;
  desconto: number;
  valorTotal: number;
  andares: number;
  poltronas: number;
  poltronasOcupadas: string[];
  poltronasBloqueadas: string[];
  active: boolean;
}

export interface Passenger {
  id: string;
  nomeCompleto: string;
  cpf: string;
  dataNascimento: string;
  documento: string;
  telefone: string;
  email: string;
  poltrona: string;
  localEmbarque: string;
  localDesembarque: string;
}

export interface Reservation {
  id: string;
  codigo: string;
  localizador: string;
  tripId: string;
  companyId: string;
  passengers: Passenger[];
  status: 'pendente' | 'confirmada' | 'paga' | 'emitida' | 'cancelada';
  paymentStatus: 'aguardando' | 'aprovado' | 'expirado' | 'cancelado' | 'recusado';
  paymentMethod: string;
  observacoes: string;
  atendenteId: string;
  valorTotal: number;
  tarifa: number;
  pedagio: number;
  taxaEmbarque: number;
  seguro: number;
  outrasTaxas: number;
  desconto: number;
  createdAt: string;
  updatedAt: string;
  history: { date: string; action: string; user: string }[];
  ticketCode?: string; // Código único do bilhete (gerado na emissão)
}

export interface Payment {
  id: string;
  reservationId: string;
  amount: number;
  method: string;
  status: 'aguardando' | 'aprovado' | 'expirado' | 'cancelado' | 'recusado';
  pixCode: string;
  createdAt: string;
  approvedAt?: string;
}

export interface Ticket {
  id: string;
  reservationId: string;
  numero: string;
  status: 'demonstracao' | 'reservado' | 'emitido' | 'cancelado';
  createdAt: string;
}

export interface AgencySettings {
  nome: string;
  razaoSocial: string;
  cnpj: string;
  endereco: string;
  telefone: string;
  email: string;
  sac: string;
  horarioFuncionamento: string;
}

export interface LogEntry {
  id: string;
  userId: string;
  action: string;
  details: string;
  timestamp: string;
}

export interface PixKey {
  id: string;
  agencyName: string;
  keyType: 'cpf' | 'cnpj' | 'email' | 'phone' | 'random';
  key: string;
  holderName: string;
  holderDocument: string;
  bank?: string;
  isDefault: boolean;
  active: boolean;
  createdAt: string;
}

export interface PixCharge {
  id: string;
  reservationId: string;
  pixKeyId: string;
  amount: number;
  description: string;
  pixCode: string;
  qrCodeBase64: string;
  status: 'pending' | 'paid' | 'expired' | 'cancelled' | 'error';
  createdAt: string;
  paidAt?: string;
  expiresAt: string;
  attendantId: string;
  passengerName: string;
  reservationCode: string;
}
