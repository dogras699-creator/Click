import * as QRCode from 'qrcode';

/**
 * Gera código Pix no padrão EMV/BR Code
 * Baseado na especificação do Banco Central do Brasil
 */
export function generatePixCode(params: {
  pixKey: string;
  merchantName: string;
  merchantCity: string;
  amount: number;
  txid?: string;
}): string {
  const { pixKey, merchantName, merchantCity, amount, txid } = params;

  // Função auxiliar para criar campo TLV (Tag-Length-Value)
  const createTLV = (id: string, value: string): string => {
    const length = value.length.toString().padStart(2, '0');
    return `${id}${length}${value}`;
  };

  // Payload Format Indicator (Tag 00) - Obrigatório
  let pix = createTLV('00', '01');

  // Merchant Account Information (Tag 26) - Informações da conta Pix
  let merchantAccount = '';
  merchantAccount += createTLV('00', 'br.gov.bcb.pix'); // GUI
  merchantAccount += createTLV('01', pixKey); // Chave Pix
  
  pix += createTLV('26', merchantAccount);

  // Merchant Category Code (Tag 52) - Obrigatório
  pix += createTLV('52', '0000');

  // Transaction Currency (Tag 53) - 986 = BRL
  pix += createTLV('53', '986');

  // Transaction Amount (Tag 54) - Obrigatório se houver valor
  if (amount > 0) {
    pix += createTLV('54', amount.toFixed(2));
  }

  // Country Code (Tag 58) - BR
  pix += createTLV('58', 'BR');

  // Merchant Name (Tag 59) - Obrigatório
  pix += createTLV('59', merchantName.substring(0, 25));

  // Merchant City (Tag 60) - Obrigatório
  pix += createTLV('60', merchantCity.substring(0, 15));

  // Additional Data Field Template (Tag 62)
  if (txid) {
    let additionalData = '';
    additionalData += createTLV('05', txid.substring(0, 25)); // TXID
    pix += createTLV('62', additionalData);
  }

  // CRC16 (Tag 63) - Obrigatório, calculado no final
  pix += '6304';

  // Calcular CRC16
  const crc = calculateCRC16(pix);
  pix += crc;

  return pix;
}

/**
 * Calcula CRC16 conforme especificação EMV
 */
function calculateCRC16(str: string): string {
  const polynomial = 0x1021;
  let crc = 0xFFFF;

  for (let i = 0; i < str.length; i++) {
    crc ^= str.charCodeAt(i) << 8;
    for (let j = 0; j < 8; j++) {
      if (crc & 0x8000) {
        crc = (crc << 1) ^ polynomial;
      } else {
        crc <<= 1;
      }
    }
  }

  crc &= 0xFFFF;
  return crc.toString(16).toUpperCase().padStart(4, '0');
}

/**
 * Gera QR Code em formato base64
 */
export async function generateQRCodeBase64(pixCode: string): Promise<string> {
  try {
    const qrCodeDataUrl = await QRCode.toDataURL(pixCode, {
      width: 300,
      margin: 2,
      color: {
        dark: '#000000',
        light: '#FFFFFF'
      },
      errorCorrectionLevel: 'M'
    });
    return qrCodeDataUrl;
  } catch (error) {
    console.error('Erro ao gerar QR Code:', error);
    return '';
  }
}

/**
 * Valida chave Pix conforme o tipo
 */
export function validatePixKey(keyType: string, key: string): { valid: boolean; message: string } {
  switch (keyType) {
    case 'cpf':
      // Validação básica de CPF (11 dígitos)
      const cpfClean = key.replace(/\D/g, '');
      if (cpfClean.length !== 11) {
        return { valid: false, message: 'CPF deve ter 11 dígitos' };
      }
      return { valid: true, message: 'CPF válido' };

    case 'cnpj':
      // Validação básica de CNPJ (14 dígitos)
      const cnpjClean = key.replace(/\D/g, '');
      if (cnpjClean.length !== 14) {
        return { valid: false, message: 'CNPJ deve ter 14 dígitos' };
      }
      return { valid: true, message: 'CNPJ válido' };

    case 'email':
      // Validação básica de email
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(key)) {
        return { valid: false, message: 'E-mail inválido' };
      }
      return { valid: true, message: 'E-mail válido' };

    case 'phone':
      // Validação de telefone (formato brasileiro)
      const phoneClean = key.replace(/\D/g, '');
      if (phoneClean.length < 10 || phoneClean.length > 11) {
        return { valid: false, message: 'Telefone deve ter 10 ou 11 dígitos' };
      }
      return { valid: true, message: 'Telefone válido' };

    case 'random':
      // Chave aleatória (EVP) - 32 caracteres alfanuméricos
      const randomRegex = /^[a-zA-Z0-9]{32}$/;
      if (!randomRegex.test(key)) {
        return { valid: false, message: 'Chave aleatória deve ter 32 caracteres alfanuméricos' };
      }
      return { valid: true, message: 'Chave aleatória válida' };

    default:
      return { valid: false, message: 'Tipo de chave inválido' };
  }
}

/**
 * Formata chave Pix para exibição mascarada
 */
export function maskPixKey(keyType: string, key: string): string {
  if (key.length <= 4) return key;
  
  switch (keyType) {
    case 'cpf':
      return `***.${key.substring(3, 6)}.***-**`;
    case 'cnpj':
      return `**.${key.substring(3, 6)}.***/****-**`;
    case 'email':
      const [user, domain] = key.split('@');
      return `${user.substring(0, 2)}***@${domain}`;
    case 'phone':
      return `(**) ${key.substring(2, 6)}-**${key.substring(key.length - 2)}`;
    case 'random':
      return `${key.substring(0, 4)}****...****${key.substring(key.length - 4)}`;
    default:
      return `${key.substring(0, 4)}...${key.substring(key.length - 4)}`;
  }
}
